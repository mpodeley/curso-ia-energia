"""
Implementación de referencia de los diagnósticos, en Python.

NO forma parte del entregable. Cumple dos funciones:

  1. Verificar que el método recupera las respuestas analíticas conocidas de los
     casos golden. Si el método falla acá, no tiene sentido programarlo en Excel.
  2. Calibrar los umbrales del clasificador de Chan contra las firmas sintéticas,
     para congelarlos recién cuando se sabe que discriminan.

Cada función está escrita de forma deliberadamente elemental —sin numpy, sin
scipy— porque su propósito es ser traducible línea por línea a fórmulas de Excel.
Si algo acá necesitara una librería de optimización, no podría vivir en el libro.
"""

import csv
import json
import math
from collections import defaultdict
from datetime import date
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
EJEMPLOS = RAIZ / "datos" / "ejemplos"

DIAS_MES = 30.4375
MESES_ANIO = 12.0

# --- Umbrales del clasificador de Chan (se calibran acá, luego van a Excel) ---
CHAN_WOR_MIN = 0.05        # por debajo de este WOR no se clasifica: no hay agua
CHAN_VENTANA = 3           # semiancho de la ventana de derivada, en meses
CHAN_MIN_PUNTOS = 18       # mínimo de puntos con agua para clasificar
CHAN_PEND_CANAL = 0.25     # pendiente log-log de WOR' por encima -> canalización
CHAN_PEND_CONIF = -1.00    # pendiente log-log de WOR' por debajo -> conificación
#
# Sobre CHAN_PEND_CONIF = -1,00 y no un valor cercano a cero.
#
# Si WOR ~ t^m entonces WOR' ~ t^(m-1), de modo que la pendiente log-log de la
# derivada es simplemente m-1. Un pozo que se inunda despacio (m = 0,8) da una
# pendiente de -0,2: negativa, pero perfectamente normal.
#
# La conificación verdadera es otra cosa: el WOR tiende a una asíntota y su
# derivada decae EXPONENCIALMENTE, lo que produce pendientes del orden de -3.
# Discriminar por el signo confunde ambos casos y lleva a recomendar control de
# conificación en pozos sanos. Hay que discriminar por la magnitud.
#
# Calibrado contra los casos golden:
#     SINT_CONIFICACION   -3,37   (asintótico)
#     SINT_NORMAL_LENTO   -0,28   (m = 0,8)
#     SINT_NORMAL         ~ 0,00  (m = 1,0)
#     SINT_CANALIZACION   +1,37   (m = 1,8)
# El umbral -1,00 queda holgado entre -3,37 y -0,28.


# ---------------------------------------------------------------------------
# Regresión lineal simple — el equivalente de LINEST
# ---------------------------------------------------------------------------
def regresion(xs, ys):
    """Devuelve (pendiente, intercepto, r2). Equivale a LINEST/PENDIENTE/INTERSECCION."""
    n = len(xs)
    if n < 3:
        return None
    sx = sum(xs); sy = sum(ys)
    sxx = sum(x * x for x in xs); sxy = sum(x * y for x, y in zip(xs, ys))
    den = n * sxx - sx * sx
    if abs(den) < 1e-15:
        return None
    m = (n * sxy - sx * sy) / den
    b = (sy - m * sx) / n
    ymed = sy / n
    sstot = sum((y - ymed) ** 2 for y in ys)
    ssres = sum((y - (m * x + b)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 - ssres / sstot if sstot > 1e-15 else 0.0
    return m, b, r2


# ---------------------------------------------------------------------------
# Declinación de Arps
# ---------------------------------------------------------------------------
def ajuste_exponencial(ts, qs):
    """q = qi*exp(-D*t). Se linealiza como ln(q) = ln(qi) - D*t."""
    pares = [(t, math.log(q)) for t, q in zip(ts, qs) if q > 0]
    if len(pares) < 3:
        return None
    m, b, r2 = regresion([p[0] for p in pares], [p[1] for p in pares])
    return {"D": -m, "qi": math.exp(b), "r2": r2}


def ajuste_hiperbolico(ts, qs, paso=0.05):
    """
    q = qi / (1 + b*Di*t)^(1/b)

    Para un b dado se linealiza como  q^(-b) = qi^(-b) * (1 + b*Di*t),
    que es una recta en t. Se barre b en una grilla y se elige el mejor.

    Decisión importante: el R2 se evalúa sobre la escala ORIGINAL de q, no sobre
    la transformada. Comparar R2 entre distintos b sobre escalas transformadas
    distintas no es comparar lo mismo, y sesga la selección hacia b altos.
    """
    mejor = None
    b = 0.0
    while b <= 1.0 + 1e-9:
        if b < 1e-9:
            aj = ajuste_exponencial(ts, qs)
            if aj:
                pred = [aj["qi"] * math.exp(-aj["D"] * t) for t in ts]
                cand = {"b": 0.0, "Di": aj["D"], "qi": aj["qi"]}
            else:
                cand, pred = None, None
        else:
            ys = [q ** (-b) for q in qs if q > 0]
            xs = [t for t, q in zip(ts, qs) if q > 0]
            reg = regresion(xs, ys)
            if reg and reg[1] > 0 and reg[0] > 0:
                m, a, _ = reg
                qi = a ** (-1.0 / b)
                Di = m / (a * b)
                cand = {"b": b, "Di": Di, "qi": qi}
                pred = [qi / (1.0 + b * Di * t) ** (1.0 / b) for t in ts]
            else:
                cand, pred = None, None

        if cand and pred:
            qmed = sum(qs) / len(qs)
            sstot = sum((q - qmed) ** 2 for q in qs)
            ssres = sum((q - p) ** 2 for q, p in zip(qs, pred))
            cand["r2"] = 1.0 - ssres / sstot if sstot > 1e-15 else 0.0
            if mejor is None or cand["r2"] > mejor["r2"]:
                mejor = cand
        b += paso
    return mejor


def eur_exponencial(qi, D, q_lim):
    """Np = (qi - q_lim)/D, en Mbbl con qi en bpd y D en 1/año."""
    if D <= 0 or qi <= q_lim:
        return 0.0
    return (qi - q_lim) / D * 365.25 / 1000.0


# ---------------------------------------------------------------------------
# Chan — WOR, derivada y clasificación
# ---------------------------------------------------------------------------
def serie_wor(qos, qws):
    return [(qw / qo if qo > 1e-9 else None) for qo, qw in zip(qos, qws)]


def derivada_wor(ts, wors, ventana=CHAN_VENTANA):
    """
    Diferencia centrada sobre ventana de +/- `ventana` puntos.

    Se usa ventana amplia y no diferencia punto a punto porque el dato mensual
    de campo es ruidoso: una derivada de dos puntos consecutivos amplifica el
    ruido hasta hacer irreconocible la firma.
    """
    out = []
    n = len(wors)
    for i in range(n):
        j, k = i - ventana, i + ventana
        if j < 0 or k >= n or wors[j] is None or wors[k] is None:
            out.append(None)
            continue
        dt = ts[k] - ts[j]
        out.append((wors[k] - wors[j]) / dt if dt > 1e-9 else None)
    return out


def clasificar_chan(ts, wors, worp):
    """
    Devuelve (clasificacion, pendiente_WOR, pendiente_WORp, n_puntos).

    Reglas (Chan, SPE 30775):
      · canalización        -> WOR sube abrupto, derivada de pendiente POSITIVA
      · conificación        -> WOR sube y se aplana, derivada de pendiente NEGATIVA
      · desplazamiento normal -> ascenso gradual, derivada casi plana
    """
    pts = [(t, w, d) for t, w, d in zip(ts, wors, worp)
           if w is not None and w > CHAN_WOR_MIN and t > 0
           and d is not None and d > 0]
    if len(pts) < CHAN_MIN_PUNTOS:
        con_agua = [w for w in wors if w is not None and w > CHAN_WOR_MIN]
        return ("SIN AGUA" if not con_agua else "INDETERMINADO", None, None, len(pts))

    lt = [math.log(p[0]) for p in pts]
    rw = regresion(lt, [math.log(p[1]) for p in pts])
    rd = regresion(lt, [math.log(p[2]) for p in pts])
    if rw is None or rd is None:
        return "INDETERMINADO", None, None, len(pts)

    pend_w, pend_d = rw[0], rd[0]
    if pend_d >= CHAN_PEND_CANAL:
        cls = "CANALIZACION"
    elif pend_d <= CHAN_PEND_CONIF:
        cls = "CONIFICACION"
    else:
        cls = "DESPLAZAMIENTO NORMAL"
    return cls, pend_w, pend_d, len(pts)


# ---------------------------------------------------------------------------
# Balance de materia de gas — p/z vs Gp
# ---------------------------------------------------------------------------
def ogip_por_pz(gps, presiones, z=0.88):
    """
    p/z = (pi/zi)*(1 - Gp/G).  La recta corta el eje Gp exactamente en G.
    G = -intercepto/pendiente.
    """
    pares = [(g, p / z) for g, p in zip(gps, presiones) if p and p > 0]
    if len(pares) < 5:
        return None
    m, b, r2 = regresion([p[0] for p in pares], [p[1] for p in pares])
    if m >= 0:
        return None
    return {"OGIP": -b / m, "pz_inicial": b, "r2": r2}


# ---------------------------------------------------------------------------
# Verificación contra los casos golden
# ---------------------------------------------------------------------------
def cargar_csv():
    series = defaultdict(list)
    with (EJEMPLOS / "CAMPO_SINTETICO.csv").open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            y, m, d = (int(x) for x in r["Fecha"].split("-"))
            series[r["Reservorio"]].append({
                "fecha": date(y, m, d),
                "qo": float(r["Qo_bpd"]), "qw": float(r["Qw_bpd"]),
                "qg": float(r["Qg_Mpcd"]),
                "pwf": float(r["Pwf_psi"]) if r["Pwf_psi"] else None,
                "dias": float(r["Dias_operados"]),
            })
    for v in series.values():
        v.sort(key=lambda x: x["fecha"])
    return series


def dentro(obtenido, esperado, tol, relativa=True):
    if obtenido is None:
        return False
    if relativa and abs(esperado) > 1e-9:
        return abs(obtenido - esperado) / abs(esperado) <= tol
    return abs(obtenido - esperado) <= tol


def main():
    series = cargar_csv()
    golden = {c["caso"]: c for c in json.loads(
        (EJEMPLOS / "casos_golden.json").read_text(encoding="utf-8"))}

    resultados, fallos = [], 0

    for nombre, filas in sorted(series.items()):
        ts = [i / MESES_ANIO for i in range(len(filas))]
        qos = [f["qo"] for f in filas]
        qws = [f["qw"] for f in filas]
        esperado = golden[nombre]["esperado"]
        tol = golden[nombre].get("tolerancia", {})
        chequeos = []

        hip = ajuste_hiperbolico(ts, qos)
        if hip:
            if "b_arps" in esperado:
                ok = dentro(hip["b"], esperado["b_arps"],
                            tol.get("b_arps", 0.05), relativa=False)
                chequeos.append(("b de Arps", f"{hip['b']:.2f}",
                                 f"{esperado['b_arps']:.2f}", ok))
            if "Di_anual" in esperado:
                ok = dentro(hip["Di"], esperado["Di_anual"], tol.get("Di_anual", 0.05))
                chequeos.append(("Di anual", f"{hip['Di']:.4f}",
                                 f"{esperado['Di_anual']:.4f}", ok))
            if "qi_bpd" in esperado:
                ok = dentro(hip["qi"], esperado["qi_bpd"], tol.get("qi_bpd", 0.05))
                chequeos.append(("qi (bpd)", f"{hip['qi']:.1f}",
                                 f"{esperado['qi_bpd']:.1f}", ok))

        if "D_anual" in esperado:
            exp = ajuste_exponencial(ts, qos)
            ok = dentro(exp["D"], esperado["D_anual"],
                        tol.get("D_anual", 0.01), relativa=False)
            chequeos.append(("D anual", f"{exp['D']:.4f}",
                             f"{esperado['D_anual']:.4f}", ok))
            if "EUR_Mbbl" in esperado:
                eur = eur_exponencial(exp["qi"], exp["D"], 20.0)
                ok = dentro(eur, esperado["EUR_Mbbl"], tol.get("EUR_Mbbl", 0.05))
                chequeos.append(("EUR (Mbbl)", f"{eur:.1f}",
                                 f"{esperado['EUR_Mbbl']:.1f}", ok))

        if "clasificacion_chan" in esperado:
            wors = serie_wor(qos, qws)
            worp = derivada_wor(ts, wors)
            cls, pw, pd_, n = clasificar_chan(ts, wors, worp)
            ok = cls == esperado["clasificacion_chan"]
            chequeos.append(("Chan", cls, esperado["clasificacion_chan"], ok))
            if pw is not None:
                extra = f"pend WOR={pw:+.2f}  pend WOR'={pd_:+.2f}  n={n}"
                chequeos.append(("  (pendientes)", extra, "—", True))

        if "OGIP_MMpc" in esperado:
            gp, acum = [], 0.0
            for f in filas:
                acum += f["qg"] * f["dias"] / 1000.0
                gp.append(acum)
            res = ogip_por_pz(gp, [f["pwf"] for f in filas])
            ok = dentro(res["OGIP"], esperado["OGIP_MMpc"], tol.get("OGIP_MMpc", 0.03))
            chequeos.append(("OGIP (MMpc)", f"{res['OGIP']:,.0f}",
                             f"{esperado['OGIP_MMpc']:,.0f}", ok))
            ok2 = dentro(res["pz_inicial"], esperado["p_sobre_z_inicial"],
                         tol.get("p_sobre_z_inicial", 0.02))
            chequeos.append(("p/z inicial", f"{res['pz_inicial']:.1f}",
                             f"{esperado['p_sobre_z_inicial']:.1f}", ok2))

        resultados.append((nombre, chequeos))
        fallos += sum(1 for c in chequeos if not c[3])

    ancho = 76
    print("=" * ancho)
    print("VERIFICACIÓN DEL MÉTODO CONTRA LOS CASOS GOLDEN")
    print("=" * ancho)
    for nombre, chequeos in resultados:
        print(f"\n{nombre}")
        print("-" * ancho)
        print(f"  {'Magnitud':<16} {'Obtenido':>22} {'Esperado':>22}   ")
        for etiqueta, obt, esp, ok in chequeos:
            marca = "OK " if ok else "FALLA"
            print(f"  {etiqueta:<16} {obt:>22} {esp:>22}   {marca}")
    print("\n" + "=" * ancho)
    print("RESULTADO: TODO OK" if fallos == 0 else f"RESULTADO: {fallos} FALLA(S)")
    print("=" * ancho)
    return 1 if fallos else 0


if __name__ == "__main__":
    raise SystemExit(main())
