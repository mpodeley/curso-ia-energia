"""
Contrato entre el Libro A y el Libro B.

La hoja `Resumen` del Libro A y la hoja `Reservorios` del Libro B comparten esta
lista, en este orden. Es lo que permite copiar una fila de un libro al otro sin
que las columnas se desalineen.

Los dos libros se generan desde este mismo archivo a propósito: si el contrato
viviera duplicado en cada generador, bastaría con que alguien agregara una
columna en uno para que el pegado quedara corrido una posición y produjera
valores plausibles en la columna equivocada — el peor modo de falla posible,
porque no da error.

Cada entrada es (encabezado, fórmula_en_Libro_A, formato, ancho).
La fórmula es "" cuando la columna se completa a mano en el Libro B.
"""

COLUMNAS_RESUMEN = [
    # --- Identificación ---
    ("Campo", "=Campo_Nombre", None, 16),
    ("Reservorio", "=Reservorio_Sel", None, 20),
    ("Tipo", "=Act_Tipo", None, 20),
    ("Formación", "=Act_Formacion", None, 14),
    ("Fecha_análisis", "=Fecha_Analisis", "DD/MM/YYYY", 13),
    ("Versión_LibroA", None, None, 13),
    ("Analista", "=Analista", None, 16),

    # --- Producción ---
    ("Np_Mbbl", "=Diag_Np", "#,##0.0", 12),
    ("Wp_Mbbl", "=Diag_Wp", "#,##0.0", 12),
    ("Gp_MMpc", "=Diag_Gp", "#,##0.0", 12),
    ("Wi_Mbbl", "=Diag_Wi", "#,##0.0", 12),
    ("Qo_ult_bpd", "=Diag_QoUlt", "#,##0.0", 12),
    ("WOR_ult", "=Diag_WORUlt", "0.00", 10),
    ("fw_ult", "=Diag_fwUlt", "0.0%", 10),
    ("GOR_ult", "=Diag_GORUlt", "#,##0", 11),

    # --- Declinación ---
    ("Arps_b", "=Fit_b", "0.00", 9),
    ("Arps_Di", "=Fit_Di", "0.0000", 10),
    ("Arps_R2", "=Fit_R2", "0.000", 9),
    ("EUR_Mbbl", "=Diag_EUR", "#,##0.0", 12),
    ("Reservas_rem_Mbbl", "=Diag_Rem", "#,##0.0", 14),

    # --- Diagnóstico de agua ---
    ("Chan_clase", "=Diag_Chan", None, 22),
    ("Chan_pend_WORd", "=Diag_PendWORd", "0.000", 13),
    ("Np_al_WOR_ec_Mbbl", "=Diag_NpWOREc", "#,##0.0", 15),

    # --- Inyección y productividad (informativo; no alimenta el IAW) ---
    ("Hall_estado", "=Diag_Hall", None, 22),
    ("Hall_var_pendiente", '=IFERROR(Diag_HallRec/Diag_HallTot-1,"")', "0.0%", 14),
    ("IP_variacion", "=Diag_IPvar", "0.0%", 12),

    # --- Volumetría ---
    ("OOIP_Mbbl", "=Diag_OOIP", "#,##0", 12),
    ("OGIP_MMpc", "=Diag_OGIP", "#,##0", 12),
    ("RF_actual", "=Diag_RF", "0.0%", 10),
    ("So", "=Diag_So", "0.000", 9),
    ("Sor", "=Act_Sor", "0.000", 9),
    ("Movil_remanente", "=Diag_Movil", "0.000", 13),

    # --- Roca y geometría ---
    ("Area_ha", "=Act_Areaha", "#,##0", 10),
    ("Espesor_neto_m", "=Act_Espesornetom", "#,##0.0", 12),
    ("Porosidad", "=Act_Porosidad", "0.000", 10),
    ("Swi", "=Act_Swi", "0.000", 9),
    ("NTG", "=Act_NTG", "0.00", 9),
    ("Perm_mD", "=Act_PermmD", "#,##0", 10),
    ("V_Dykstra_Parsons", "=Act_VDykstraParsons", "0.00", 13),
    ("Buzamiento_deg", "=Act_Buzamientodeg", "0.0", 12),
    ("Prof_m", "=Act_Profm", "#,##0", 10),

    # --- Fluidos ---
    ("API", "=Act_API", "0.0", 9),
    ("uo_cP", "=Act_uocP", "0.00", 9),
    ("uw_cP", "=Act_uwcP", "0.00", 9),
    ("Bo", "=Act_Bo", "0.000", 9),
    ("Bw", "=Act_Bw", "0.000", 9),
    ("Bg", "=Act_Bg", "0.0000", 9),
    ("Rs", "=Act_Rs", "#,##0", 9),
    ("Pb_psi", "=Act_Pbpsi", "#,##0", 10),
    ("Pi_psi", "=Act_Pipsi", "#,##0", 10),
    ("P_actual_psi", "=Act_Pactualpsi", "#,##0", 12),
    ("Temp_F", "=Act_TempF", "#,##0", 9),

    # --- Condensado con anillo ---
    ("Espesor_anillo_m", "=Act_Espesoranillom", "0.0", 13),
    ("m_casquete", "=Act_mcasquete", "0.00", 11),

    # --- Ejecutabilidad ---
    ("VRR_acum", "=Diag_VRR", "0.00", 10),
    ("Fuente_agua", "=Act_Fuenteagua", None, 14),
    ("Caudal_agua_disp_bpd", "=Act_Caudalaguadisp", "#,##0", 15),
    ("Pozos_total", "=Act_Pozostotal", "0", 11),
    ("Pozos_activos", "=Act_Pozosactivos", "0", 12),
    ("Pozos_convertibles", "=Act_Pozosconvertibles", "0", 14),
    ("Integridad_ok_pct", "=Act_Integridadokpct", "0", 14),
    ("Infraestructura", "=Act_Infraestructura", None, 16),
    ("Restriccion_amb", "=Act_Restriccionamb", None, 20),

    # --- Completitud ---
    ("Completitud_N1", "=Comp_N1", "0%", 12),
    ("Completitud_N2", "=Comp_N2", "0%", 12),
    ("Completitud_N3", "=Comp_N3", "0%", 12),
    ("Completitud_global", "=Comp_Global", "0%", 14),
]

ENCABEZADOS_RESUMEN = [c[0] for c in COLUMNAS_RESUMEN]
