"""
Verificación NUMÉRICA del Libro A contra los casos golden.

La verificación estática (`verificar_libros.py`) comprueba que el libro abra y
calcule. Esta comprueba que calcule BIEN: construye una versión reducida del
Libro A, le carga cada reservorio sintético, evalúa las fórmulas con un motor de
Excel en Python y compara contra la respuesta analítica conocida.

Es la prueba que cierra el hueco entre "el método es correcto" (que ya demostró
`referencia_diagnosticos.py`) y "las fórmulas del libro implementan ese método".
Entre ambas cosas hay un error de transcripción posible en cada celda.

Se usa un libro reducido (pocos meses, sin gráficos) porque el motor evalúa el
grafo completo de dependencias y el libro de producción tiene ~103.000 fórmulas.
Las fórmulas son las mismas; solo cambia el número de filas.
"""

import json
import sys
import warnings
from collections import defaultdict
from datetime import date
from pathlib import Path

warnings.filterwarnings("ignore")

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

import construir_libro_a as A     # noqa: E402

FILAS_TEST = 320
MESES_TEST = 320
TMP = RAIZ / "construccion" / ".tmp_verificacion"
TMP.mkdir(exist_ok=True)


def construir_reducido():
    """Mismo generador, menos filas y sin gráficos."""
    A.MAX_FILAS = FILAS_TEST
    A.FIL1 = A.FIL0 + FILAS_TEST - 1
    A.MESES = MESES_TEST
    A.SER1 = A.SER0 + MESES_TEST - 1
    # El parámetro por defecto de la ventana de ajuste se define desde MESES
    for i, p in enumerate(A.PARAMS):
        if p[0] == "Ajuste_Mes_Fin":
            A.PARAMS[i] = (p[0], p[1], MESES_TEST - 1, p[3], p[4])

    from openpyxl import Workbook
    wb = Workbook()
    wb.remove(wb.active)
    A.hoja_leeme(wb)
    A.hoja_config(wb)
    A.hoja_carga_produccion(wb)
    _ws, filas_param, fila_cab = A.hoja_estaticos(wb)
    A.hoja_calculos(wb)
    A.hoja_serie(wb)
    A.hoja_grilla_b(wb)
    A.hoja_diagnostico(wb, filas_param)
    A.hoja_completitud(wb, filas_param)
    A.hoja_resumen(wb)
    # Gráficos y bibliografía se omiten: no aportan valores y el motor los ignora.
    return wb, filas_param, fila_cab


def celda_de(wb, nombre):
    """Devuelve (hoja, coordenada) de un rango con nombre de una sola celda."""
    dn = wb.defined_names[nombre]
    destino = dn.attr_text
    hoja, coord = destino.rsplit("!", 1)
    return hoja.strip("'"), coord.replace("$", "")


def cargar_datos():
    import csv
    series = defaultdict(list)
    with (RAIZ / "datos/ejemplos/CAMPO_SINTETICO.csv").open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            y, m, d = (int(x) for x in r["Fecha"].split("-"))
            series[r["Reservorio"]].append(dict(
                pozo=r["Pozo"], fecha=date(y, m, d),
                dias=float(r["Dias_operados"]),
                qo=float(r["Qo_bpd"]), qw=float(r["Qw_bpd"]),
                qg=float(r["Qg_Mpcd"]),
                pwf=float(r["Pwf_psi"]) if r["Pwf_psi"] else None,
                winy=float(r["Winy_bpd"]) if r.get("Winy_bpd") else None,
                piny=float(r["Piny_psi"]) if r.get("Piny_psi") else None))
    for v in series.values():
        # Orden por pozo y luego por fecha: es lo que exigen las sumas corridas
        # del libro, y un caso con dos pozos lo pondría a prueba si no se hiciera.
        v.sort(key=lambda x: (x["pozo"], x["fecha"]))
    return series


SALIDAS = ["Fit_b", "Fit_Di", "Fit_qi", "Fit_R2", "Diag_EUR", "Diag_Np",
           "Diag_Chan", "Diag_PendWOR", "Diag_PendWORd", "Diag_ChanN",
           "Diag_OGIP", "Diag_pzInter", "Diag_Desorden",
           "Diag_HallTot", "Diag_HallRec", "Diag_Hall", "Diag_HallN",
           "Diag_IPini", "Diag_IPact", "Diag_IPvar"]


def evaluar(nombre_res, filas, wb_plantilla, filas_param, fila_cab,
            estaticos=None):
    import formulas
    from openpyxl import load_workbook

    base = TMP / "plantilla.xlsx"
    wb_plantilla.save(base)
    wb = load_workbook(base)

    ws = wb["Carga_Producción"]
    for i, f in enumerate(filas):
        r = A.FIL0 + i
        ws.cell(r, 1, f["pozo"]); ws.cell(r, 2, nombre_res)
        ws.cell(r, 3, f["fecha"]); ws.cell(r, 4, f["dias"])
        ws.cell(r, 5, f["qo"]); ws.cell(r, 6, f["qw"]); ws.cell(r, 7, f["qg"])
        if f["pwf"] is not None:
            ws.cell(r, 8, f["pwf"])
        if f.get("winy") is not None:
            ws.cell(r, 10, f["winy"])
        if f.get("piny") is not None:
            ws.cell(r, 11, f["piny"])

    ws_est = wb["Carga_Estáticos"]
    ws_est.cell(fila_cab, A.EST_C0, nombre_res)
    for nombre, valor in (estaticos or {}).items():
        ws_est.cell(filas_param[nombre], A.EST_C0, valor)

    hoja_cfg, coord = celda_de(wb, "Reservorio_Sel")
    wb[hoja_cfg][coord] = nombre_res
    hoja_cfg, coord = celda_de(wb, "Campo_Nombre")
    wb[hoja_cfg][coord] = "CAMPO_SINTETICO"

    ubic = {n: celda_de(wb, n) for n in SALIDAS}
    ruta = TMP / f"test_{nombre_res}.xlsx"
    wb.save(ruta)

    xl = formulas.ExcelModel().loads(str(ruta)).finish()
    sol = xl.calculate()

    fuera = {}
    for n, (hoja, coord) in ubic.items():
        clave = f"'[{ruta.name}]{hoja.upper()}'!{coord}"
        v = sol.get(clave)
        if v is None:
            v = sol.get(f"'[{ruta.name}]{hoja}'!{coord}")
        try:
            v = v.value[0, 0]
        except Exception:
            pass
        fuera[n] = v
    return fuera


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def cargar_golden():
    return {c["caso"]: c for c in json.loads(
        (RAIZ / "datos/ejemplos/casos_golden.json").read_text(encoding="utf-8"))}


def comparar(got, caso):
    """Contrasta los valores leídos del libro contra un caso golden.

    Devuelve una lista de (etiqueta, obtenido, esperado, ok). Vive acá y no en
    cada verificador porque una segunda copia de estas reglas sería una segunda
    definición de qué está bien, y las dos podrían divergir sin que nadie lo
    note. `got` es un dict {nombre de rango: valor}, venga de donde venga: del
    motor de fórmulas en Python o de LibreOffice.
    """
    esp = caso["esperado"]
    tol = caso.get("tolerancia", {})
    chk = []

    def cmp(etiqueta, obtenido, esperado, tolerancia, relativa=True):
        o = num(obtenido)
        if o is None:
            chk.append((etiqueta, str(obtenido), str(esperado), False))
            return
        if relativa and abs(esperado) > 1e-9:
            ok = abs(o - esperado) / abs(esperado) <= tolerancia
        else:
            ok = abs(o - esperado) <= tolerancia
        chk.append((etiqueta, f"{o:,.4f}", f"{esperado:,.4f}", ok))

    if "b_arps" in esp:
        cmp("b de Arps", got["Fit_b"], esp["b_arps"],
            tol.get("b_arps", 0.05), relativa=False)
    if "Di_anual" in esp:
        cmp("Di anual", got["Fit_Di"], esp["Di_anual"], tol.get("Di_anual", 0.05))
    if "qi_bpd" in esp:
        cmp("qi (bpd)", got["Fit_qi"], esp["qi_bpd"], tol.get("qi_bpd", 0.05))
    if "D_anual" in esp:
        cmp("Di anual (=D)", got["Fit_Di"], esp["D_anual"],
            tol.get("D_anual", 0.01), relativa=False)
    if "EUR_Mbbl" in esp:
        cmp("EUR (Mbbl)", got["Diag_EUR"], esp["EUR_Mbbl"],
            tol.get("EUR_Mbbl", 0.05))
    if "clasificacion_chan" in esp:
        obt = str(got["Diag_Chan"]).strip()
        chk.append(("Chan", obt, esp["clasificacion_chan"],
                    obt == esp["clasificacion_chan"]))
        pd_ = num(got["Diag_PendWORd"])
        chk.append(("  pend WOR'",
                    f"{pd_:+.3f}" if pd_ is not None else str(got["Diag_PendWORd"]),
                    "—", True))
    if "OGIP_MMpc" in esp:
        cmp("OGIP (MMpc)", got["Diag_OGIP"], esp["OGIP_MMpc"],
            tol.get("OGIP_MMpc", 0.03))
        cmp("p/z inicial", got["Diag_pzInter"], esp["p_sobre_z_inicial"],
            tol.get("p_sobre_z_inicial", 0.02))

    if "Hall_pendiente" in esp:
        cmp("Pendiente de Hall", got["Diag_HallTot"], esp["Hall_pendiente"],
            tol.get("Hall_pendiente", 0.01))
        obt = str(got["Diag_Hall"]).strip()
        chk.append(("Estado del inyector", obt, esp["Hall_estado"],
                    obt == esp["Hall_estado"]))
    if "IP_variacion" in esp:
        cmp("Variación del IP", got["Diag_IPvar"], esp["IP_variacion"],
            tol.get("IP_variacion", 0.005))

    d = num(got["Diag_Desorden"])
    chk.append(("filas desordenadas", str(int(d)) if d is not None else "?",
                "0", d == 0))
    return chk


def imprimir_resultados(titulo, lineas, fallos, ancho=78):
    print("\n" + "=" * ancho)
    print(titulo)
    print("=" * ancho)
    for nombre, chk in lineas:
        print(f"\n{nombre}\n" + "-" * ancho)
        for etiqueta, obt, esp_, ok in chk:
            print(f"  {etiqueta:<22} {obt:>20} {esp_:>22}   {'OK' if ok else 'FALLA'}")
    print("\n" + "=" * ancho)
    print("RESULTADO: TODO OK" if fallos == 0 else f"RESULTADO: {fallos} FALLA(S)")
    print("=" * ancho)


def main():
    golden = cargar_golden()
    series = cargar_datos()
    wb, filas_param, fila_cab = construir_reducido()

    casos = sys.argv[1:] or sorted(series)
    fallos, lineas = 0, []

    for nombre in casos:
        got = evaluar(nombre, series[nombre], wb, filas_param, fila_cab,
                      golden[nombre].get("estaticos"))
        chk = comparar(got, golden[nombre])
        lineas.append((nombre, chk))
        fallos += sum(1 for c in chk if not c[3])
        print(f"  · {nombre} evaluado", flush=True)

    imprimir_resultados(
        "VERIFICACIÓN NUMÉRICA DEL LIBRO A (fórmulas de Excel evaluadas)",
        lineas, fallos)
    return 1 if fallos else 0


if __name__ == "__main__":
    raise SystemExit(main())
