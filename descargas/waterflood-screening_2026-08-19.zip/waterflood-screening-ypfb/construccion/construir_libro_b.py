"""
Genera el Libro B — Screening de portafolio.

Un solo libro para todo el portafolio. Entra una fila por reservorio (pegada
desde el Libro A); salen killing factors con motivo, subíndices T/E/X, el IAW,
el ranking y la ficha por reservorio.

La hoja `Criterios` es la fuente de verdad: cambiar un umbral ahí recalcula todo
el libro sin volver a ejecutar este generador.

Sin macros, sin complementos, sin funciones posteriores a Excel 2016.
"""

from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import Reference, ScatterChart, Series
from openpyxl.chart.marker import Marker
from openpyxl.drawing.line import LineProperties
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation

from comun import (AMARILLO, BORDE_FINO, F_CAB, F_NOTA, R_CAB, R_IN, ROJO,
                   VERDE, anchos, cabeceras, celda_entrada, limpiar_nombre,
                   nombrar, nota, proteger, subtitulo, titulo)
from esquema_criterios import (CRITERIOS, DERIVADAS, KILLING_DUROS,
                               KILLING_MITIGABLES, PESOS_IAW, SUPUESTOS,
                               TABLAS_TEXTO)
from esquema_resumen import COLUMNAS_RESUMEN, ENCABEZADOS_RESUMEN

RAIZ = Path(__file__).resolve().parent.parent
SALIDA = RAIZ / "herramienta"
SALIDA.mkdir(parents=True, exist_ok=True)

VERSION = "0.1"

MAX_RES = 100           # reservorios en el portafolio
RES_CAB = 2             # fila de encabezados en Reservorios
RES0 = 3                # primera fila de datos
RES1 = RES0 + MAX_RES - 1

N_PRUEBAS = 6           # las primeras filas se reservan para los casos golden
PRU0, PRU1 = RES0, RES0 + N_PRUEBAS - 1

# Columna de Reservorios por encabezado
COL_RES = {h: CL(i) for i, h in enumerate(ENCABEZADOS_RESUMEN, start=1)}
# Columna que IDENTIFICA al reservorio. No se asume que sea la A: el esquema
# pone Campo primero, y dar por sentado que la primera columna es el nombre
# hacía que todo el libro leyera la columna equivocada sin dar ningún error.
C_NOM = COL_RES["Reservorio"]
# Columna de Derivadas por marcador: índice numérico y letra
IDX_DER = {m: i for i, (m, _e, _u, _f) in enumerate(DERIVADAS, start=2)}
COL_DER = {m: CL(i) for m, i in IDX_DER.items()}


def ref_valor(marcador, fila):
    """Referencia al valor de un criterio: viene de Reservorios o de Derivadas."""
    if marcador in COL_DER:
        return f"Derivadas!${COL_DER[marcador]}{fila}"
    if marcador in COL_RES:
        return f"Reservorios!${COL_RES[marcador]}{fila}"
    raise KeyError(f"origen desconocido: {marcador}")


def formula_interp(V, X10, X7, X4, X0):
    """
    Puntaje 0-10 por interpolación lineal entre cuatro puntos de quiebre.

    Funciona en ambos sentidos: si x@10 > x@0 el criterio es "más es mejor"
    (permeabilidad); si x@10 < x@0 es "menos es mejor" (viscosidad, US$/bbl).
    La rama se elige comparando los extremos, así que agregar un criterio nuevo
    no exige decidir la dirección en ningún lado: se deduce de los umbrales.
    """
    return (
        f"IFERROR(IF({X10}>{X0},"
        f"IF({V}>={X10},10,IF({V}>={X7},7+3*({V}-{X7})/({X10}-{X7}),"
        f"IF({V}>={X4},4+3*({V}-{X4})/({X7}-{X4}),"
        f"IF({V}>={X0},4*({V}-{X0})/({X4}-{X0}),0)))),"
        f"IF({V}<={X10},10,IF({V}<={X7},7+3*({X7}-{V})/({X7}-{X10}),"
        f"IF({V}<={X4},4+3*({X4}-{V})/({X4}-{X7}),"
        f"IF({V}<={X0},4*({X0}-{V})/({X0}-{X4}),0))))),0)")


# ===========================================================================
# LÉEME
# ===========================================================================
def hoja_leeme(wb):
    ws = wb.create_sheet("LÉEME")
    anchos(ws, {"A": 26, "B": 74, "C": 26})
    f = titulo(ws, 1, "LIBRO B — SCREENING DE PORTAFOLIO", 3)
    f += 1
    for k, v in (("Versión", VERSION),
                 ("Proyecto", "Screening de waterflooding — YPFB"),
                 ("Requiere", "Excel 2016 o posterior. Sin macros.")):
        ws.cell(f, 1, k).font = F_CAB
        ws.cell(f, 2, v)
        f += 1
    f += 1

    f = subtitulo(ws, f, "CÓMO SE USA", 3)
    for n, t in [
        ("1", "Para cada reservorio: abrir su Libro A, ir a la hoja Resumen, "
              "copiar la fila 4 y pegarla como VALORES en la hoja Reservorios "
              "de este libro, a partir de la fila 9."),
        ("2", "Revisar la hoja Killing_Factors: los descartes quedan con su "
              "motivo registrado."),
        ("3", "Revisar Scoring: subíndices T, E y X, y el IAW."),
        ("4", "Ver el orden en Ranking y la posición de cada reservorio en la "
              "matriz de decisión."),
        ("5", "Imprimir la Ficha de los reservorios de la shortlist."),
    ]:
        ws.cell(f, 1, n).font = F_CAB
        c = ws.cell(f, 2, t)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 32
        f += 1
    f += 1

    f = subtitulo(ws, f, "LO QUE HAY QUE ENTENDER ANTES DE USARLO", 3)
    for t, d in [
        ("El IAW no se lee solo",
         "Va siempre acompañado del porcentaje de completitud de datos. Un IAW "
         "de 72 con 40% de completitud no es el mismo número que uno con 90%. "
         "Por debajo de 50% el ranking no sirve para decidir: sirve para "
         "priorizar qué datos salir a buscar."),
        ("La media es geométrica, no aritmética",
         "IAW = T^0,40 x E^0,35 x X^0,25. Un promedio aritmético dejaría que un "
         "subíndice excelente compense uno pésimo. Un reservorio técnicamente "
         "ideal sin fuente de agua no es un proyecto bueno con un problema: no "
         "es un proyecto."),
        ("Un descarte no borra nada",
         "El reservorio queda en la lista con el motivo registrado. Si cambia "
         "el precio, aparece una fuente de agua o se recupera información, se "
         "revisa."),
        ("Las filas PRUEBA no se borran",
         "Las primeras seis filas de Reservorios son los casos golden que "
         "alimentan la hoja Pruebas. Quedan fuera del ranking automáticamente. "
         "Borrarlas deja al libro sin forma de verificarse."),
    ]:
        ws.cell(f, 1, t).font = F_CAB
        c = ws.cell(f, 2, d)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 62
        f += 1
    f += 1

    f = subtitulo(ws, f, "CHANGELOG — obligatorio en cada cambio de Criterios", 3)
    f = cabeceras(ws, f, ["Fecha", "Qué cambió y por qué", "Pruebas OK"])
    ws.cell(f, 1, "2026-08-17")
    ws.cell(f, 2, "Versión inicial 0.1 con umbrales de literatura")
    ws.cell(f, 3, "sí")
    for i in range(14):
        for c in range(1, 4):
            celda_entrada(ws, f + 1 + i, c)
    return ws


# ===========================================================================
# Criterios — la fuente de verdad
# ===========================================================================
def hoja_criterios(wb):
    ws = wb.create_sheet("Criterios")
    anchos(ws, {"A": 8, "B": 40, "C": 11, "D": 12, "E": 13, "F": 10, "G": 10,
                "H": 10, "I": 10, "J": 12, "K": 10, "L": 56})
    f = titulo(ws, 1, "CRITERIOS DE SCREENING — FUENTE DE VERDAD", 12)
    f = nota(ws, f, "Todo lo amarillo es editable y recalcula el libro entero. "
                    "Tras cualquier cambio: correr la hoja Pruebas y anotarlo en "
                    "el changelog del LÉEME.")
    f += 1

    filas = {}

    # ---- Killing factors duros ----
    f = subtitulo(ws, f, "KILLING FACTORS DUROS — descartan por sí solos", 12)
    f = cabeceras(ws, f, ["Cód.", "Factor", "Comparador", "Umbral", "Unidad",
                          "", "", "", "", "Si falta", "", "Motivo registrado"])
    for cod, nombre, comp, umbral, unidad, _col, si_falta, motivo in KILLING_DUROS:
        ws.cell(f, 1, cod).font = F_CAB
        ws.cell(f, 2, nombre)
        celda_entrada(ws, f, 3, comp).alignment = Alignment(horizontal="center")
        celda_entrada(ws, f, 4, umbral).alignment = Alignment(horizontal="center")
        ws.cell(f, 5, unidad).alignment = Alignment(horizontal="center")
        celda_entrada(ws, f, 10, si_falta).alignment = Alignment(horizontal="center")
        c = ws.cell(f, 12, motivo)
        c.font = F_NOTA
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 30
        filas[cod] = f
        f += 1
    f += 1

    # ---- Killing factors mitigables ----
    f = subtitulo(ws, f, "KILLING FACTORS MITIGABLES — penalizan y piden estudio", 12)
    f = cabeceras(ws, f, ["Cód.", "Bandera roja", "Comparador", "Umbral", "Unidad",
                          "Subíndice", "Penaliz.", "", "", "", "", "Estudio que dispara"])
    for (cod, nombre, comp, umbral, unidad, _col, sub, pen, estudio) in KILLING_MITIGABLES:
        ws.cell(f, 1, cod).font = F_CAB
        ws.cell(f, 2, nombre)
        celda_entrada(ws, f, 3, comp).alignment = Alignment(horizontal="center")
        celda_entrada(ws, f, 4, umbral).alignment = Alignment(horizontal="center")
        ws.cell(f, 5, unidad).alignment = Alignment(horizontal="center")
        celda_entrada(ws, f, 6, sub).alignment = Alignment(horizontal="center")
        c = celda_entrada(ws, f, 7, pen)
        c.number_format = "0%"
        c.alignment = Alignment(horizontal="center")
        d = ws.cell(f, 12, estudio)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 30
        filas[cod] = f
        f += 1
    f += 1

    # ---- Criterios puntuados ----
    f = subtitulo(ws, f, "CRITERIOS PUNTUADOS — pesos y puntos de quiebre", 12)
    f = cabeceras(ws, f, ["Cód.", "Criterio", "Subíndice", "Peso", "Tipo",
                          "x @ 10", "x @ 7", "x @ 4", "x @ 0", "Si falta",
                          "Pts. si penaliza", "Origen del valor"])
    for (cod, nombre, sub, peso, tipo, x10, x7, x4, x0,
         col, si_falta, pen) in CRITERIOS:
        ws.cell(f, 1, cod).font = F_CAB
        ws.cell(f, 2, nombre)
        ws.cell(f, 3, sub).alignment = Alignment(horizontal="center")
        c = celda_entrada(ws, f, 4, peso)
        c.alignment = Alignment(horizontal="center")
        ws.cell(f, 5, tipo).alignment = Alignment(horizontal="center")
        for j, v in enumerate((x10, x7, x4, x0)):
            if v is not None:
                celda_entrada(ws, f, 6 + j, v).alignment = Alignment(
                    horizontal="center")
        celda_entrada(ws, f, 10, si_falta).alignment = Alignment(horizontal="center")
        celda_entrada(ws, f, 11, pen).alignment = Alignment(horizontal="center")
        d = ws.cell(f, 12, col.strip("_").replace("_", " ").lower())
        d.font = F_NOTA
        filas[cod] = f
        f += 1

    # Control: los pesos de cada subíndice deben sumar 100
    f += 1
    ws.cell(f, 2, "Control — los pesos de cada subíndice deben sumar 100").font = F_CAB
    f += 1
    for sub, _p in PESOS_IAW:
        fs = [filas[c[0]] for c in CRITERIOS if c[2] == sub]
        suma = "+".join(f"$D${r}" for r in fs)
        ws.cell(f, 2, f"Suma de pesos de {sub}")
        c = ws.cell(f, 4, f"={suma}")
        c.alignment = Alignment(horizontal="center")
        d = ws.cell(f, 5, f'=IF($D${f}=100,"OK","REVISAR")')
        d.font = F_CAB
        ws.conditional_formatting.add(
            f"E{f}", CellIsRule(operator="equal", formula=['"REVISAR"'],
                                fill=PatternFill("solid", fgColor=ROJO)))
        ws.conditional_formatting.add(
            f"E{f}", CellIsRule(operator="equal", formula=['"OK"'],
                                fill=PatternFill("solid", fgColor=VERDE)))
        f += 1
    f += 1

    # ---- Tablas de texto ----
    f = subtitulo(ws, f, "EQUIVALENCIAS DE TEXTO A PUNTAJE", 12)
    filas_texto = {}
    for cod, tabla in TABLAS_TEXTO.items():
        nombre = next(c[1] for c in CRITERIOS if c[0] == cod)
        ws.cell(f, 1, cod).font = F_CAB
        ws.cell(f, 2, nombre).font = F_CAB
        f += 1
        r0 = f
        for texto, pts in tabla:
            celda_entrada(ws, f, 2, texto)
            celda_entrada(ws, f, 4, pts).alignment = Alignment(horizontal="center")
            f += 1
        filas_texto[cod] = (r0, f - 1)
        f += 1

    # ---- Pesos del IAW ----
    f = subtitulo(ws, f, "PESOS DEL IAW (media geométrica ponderada)", 12)
    nota(ws, f - 1, "IAW = T^peso_T x E^peso_E x X^peso_X", 6)
    for sub, peso in PESOS_IAW:
        ws.cell(f, 2, f"Peso de {sub}").font = F_CAB
        c = celda_entrada(ws, f, 4, peso)
        c.alignment = Alignment(horizontal="center")
        nombrar(wb, f"Peso_{sub}", "Criterios", f"$D${f}")
        f += 1
    ws.cell(f, 2, "Suma (debe ser 1,00)")
    ws.cell(f, 4, "=Peso_T+Peso_E+Peso_X").alignment = Alignment(horizontal="center")

    return ws, filas, filas_texto


# ===========================================================================
# Supuestos económicos
# ===========================================================================
def hoja_supuestos(wb):
    ws = wb.create_sheet("Supuestos_Económicos")
    anchos(ws, {"A": 38, "B": 16, "C": 22, "D": 66})
    f = titulo(ws, 1, "SUPUESTOS ECONÓMICOS", 4)
    f = nota(ws, f, "Estimación clase 5 (±50%). Los costos unitarios son "
                    "marcadores de posición hasta que Ingeniería de YPFB aporte "
                    "los reales.")
    f += 1
    f = cabeceras(ws, f, ["Supuesto", "Valor", "Unidad", "Nota"])
    for nombre, etiqueta, valor, unidad, desc in SUPUESTOS:
        if nombre == "SECCION":
            f = subtitulo(ws, f, etiqueta, 4)
            continue
        ws.cell(f, 1, etiqueta).font = F_CAB
        c = celda_entrada(ws, f, 2, valor)
        c.alignment = Alignment(horizontal="center")
        if isinstance(valor, float) and valor < 1:
            c.number_format = "0.00"
        elif isinstance(valor, float) and valor > 1000:
            c.number_format = "#,##0"
        ws.cell(f, 3, unidad)
        d = ws.cell(f, 4, desc)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        if desc and len(desc) > 80:
            ws.row_dimensions[f].height = 30
        nombrar(wb, nombre, "Supuestos_Económicos", f"$B${f}")
        f += 1
    f += 1
    ws.cell(f, 1, "Factor de anualidad").font = F_CAB
    c = ws.cell(f, 2, "=IFERROR((1-(1+Tasa_Descuento)^-Vida_Proyecto)"
                      "/Tasa_Descuento,0)")
    c.number_format = "0.000"
    c.fill = R_CAB
    nombrar(wb, "Factor_Anualidad", "Supuestos_Económicos", f"$B${f}")
    ws.cell(f, 4, "Valor presente de un flujo constante. Se usa un perfil de "
                  "producción plano: es una aproximación de screening, no un "
                  "perfil de declinación.").font = F_NOTA
    return ws


# ===========================================================================
# Reservorios — destino del pegado, con los casos golden pre-cargados
# ===========================================================================
# Cada caso está construido para tener una respuesta exacta y verificable dentro
# del propio libro. Viven en la hoja de datos, y no en una hoja aparte, para que
# las Pruebas ejerciten las MISMAS fórmulas que usa un reservorio real: un test
# sobre una copia de las fórmulas no prueba lo que se entrega.
CASOS_PRUEBA = [
    # PRUEBA-K1: móvil remanente por debajo del umbral -> K1 descarta
    {"Reservorio": "PRUEBA-K1", "Tipo": "Petróleo negro", "Movil_remanente": 0.02,
     "So": 0.30, "Sor": 0.28, "uo_cP": 2.0, "uw_cP": 1.0, "OOIP_Mbbl": 50000,
     "Pozos_activos": 10, "Pozos_convertibles": 4, "Integridad_ok_pct": 80},

    # PRUEBA-K2: condensado seco -> K2 descarta
    {"Reservorio": "PRUEBA-K2", "Tipo": "Condensado seco", "Movil_remanente": 0.25,
     "uo_cP": 1.0, "uw_cP": 1.0, "OOIP_Mbbl": 50000,
     "Pozos_activos": 10, "Pozos_convertibles": 4, "Integridad_ok_pct": 80},

    # PRUEBA-T10: todos los criterios T en su punto de 10 -> T = 100,0 exacto
    {"Reservorio": "PRUEBA-T10", "Tipo": "Petróleo negro", "Movil_remanente": 0.30,
     "uo_cP": 0.8, "uw_cP": 1.0, "V_Dykstra_Parsons": 0.45, "Perm_mD": 200,
     "P_actual_psi": 3000, "Pb_psi": 3000, "NTG": 0.70, "Espesor_neto_m": 15,
     "Porosidad": 0.20, "Buzamiento_deg": 12, "m_casquete": 0.10,
     "OOIP_Mbbl": 50000, "Pozos_activos": 10, "Pozos_convertibles": 5,
     "Integridad_ok_pct": 85, "Fuente_agua": "Sí", "Infraestructura": "Completa",
     "Restriccion_amb": "Ninguna", "Completitud_global": 0.85},

    # PRUEBA-T04: todos los criterios T en su punto de 4 -> T = 40,0 exacto
    {"Reservorio": "PRUEBA-T04", "Tipo": "Petróleo negro", "Movil_remanente": 0.12,
     "uo_cP": 5.0, "uw_cP": 1.0, "V_Dykstra_Parsons": 0.75, "Perm_mD": 10,
     "P_actual_psi": 1800, "Pb_psi": 3000, "NTG": 0.30, "Espesor_neto_m": 4,
     "Porosidad": 0.10, "Buzamiento_deg": 2, "m_casquete": 0.10,
     "OOIP_Mbbl": 50000, "Pozos_activos": 10, "Pozos_convertibles": 5,
     "Integridad_ok_pct": 85, "Fuente_agua": "Sí", "Infraestructura": "Completa",
     "Restriccion_amb": "Ninguna", "Completitud_global": 0.85},

    # PRUEBA-OMIT: igual a T10 pero SIN Dykstra-Parsons ni NTG, ambos en modo
    # OMITE. Si la renormalización de pesos funciona, T sigue dando 100,0.
    {"Reservorio": "PRUEBA-OMIT", "Tipo": "Petróleo negro", "Movil_remanente": 0.30,
     "uo_cP": 0.8, "uw_cP": 1.0, "Perm_mD": 200,
     "P_actual_psi": 3000, "Pb_psi": 3000, "Espesor_neto_m": 15,
     "Porosidad": 0.20, "Buzamiento_deg": 12, "m_casquete": 0.10,
     "OOIP_Mbbl": 50000, "Pozos_activos": 10, "Pozos_convertibles": 5,
     "Integridad_ok_pct": 85, "Fuente_agua": "Sí", "Infraestructura": "Completa",
     "Restriccion_amb": "Ninguna", "Completitud_global": 0.85},

    # PRUEBA-X10: todos los criterios X en su máximo -> X = 100,0 exacto
    {"Reservorio": "PRUEBA-X10", "Tipo": "Petróleo negro", "Movil_remanente": 0.30,
     "uo_cP": 1.0, "uw_cP": 1.0, "OOIP_Mbbl": 50000,
     "Pozos_activos": 10, "Pozos_convertibles": 5, "Integridad_ok_pct": 85,
     "Fuente_agua": "Sí", "Infraestructura": "Completa",
     "Restriccion_amb": "Ninguna", "Completitud_global": 0.85},
]


def hoja_reservorios(wb):
    ws = wb.create_sheet("Reservorios")
    f = titulo(ws, 1, "PORTAFOLIO — una fila por reservorio, pegada desde el "
                      "Libro A", 12)
    for j, (h, _fml, fmt, ancho) in enumerate(COLUMNAS_RESUMEN, start=1):
        c = ws.cell(RES_CAB, j, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[CL(j)].width = ancho
        for r in range(RES0, RES1 + 1):
            cel = ws.cell(r, j)
            if fmt:
                cel.number_format = fmt
            if r > PRU1:
                cel.fill = R_IN
    ws.row_dimensions[RES_CAB].height = 34

    gris = PatternFill("solid", fgColor="E4DFEC")
    for i, caso in enumerate(CASOS_PRUEBA):
        r = PRU0 + i
        for j, h in enumerate(ENCABEZADOS_RESUMEN, start=1):
            ws.cell(r, j).fill = gris
            if h in caso:
                ws.cell(r, j, caso[h])
    ws.freeze_panes = "B3"
    ws.auto_filter.ref = f"A{RES_CAB}:{CL(len(COLUMNAS_RESUMEN))}{RES1}"
    return ws


# ===========================================================================
# Derivadas — todo lo que se calcula a partir de la fila de resumen
# ===========================================================================
def hoja_derivadas(wb):
    ws = wb.create_sheet("Derivadas")
    f = titulo(ws, 1, "VALORES DERIVADOS — hoja calculada", len(DERIVADAS) + 1)
    nota(ws, f, "Economía de clase 5 con perfil de producción plano. Sirve para "
                "ORDENAR candidatos con el mismo criterio, no para comprometer "
                "capital.")
    ws.cell(RES_CAB, 1, "Reservorio").font = F_CAB
    ws.cell(RES_CAB, 1).fill = R_CAB
    ws.column_dimensions["A"].width = 22
    for j, (marc, etiqueta, unidad, fmt) in enumerate(DERIVADAS, start=2):
        c = ws.cell(RES_CAB, j, f"{etiqueta}\n({unidad})")
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[CL(j)].width = 15
    ws.row_dimensions[RES_CAB].height = 40

    R = "Reservorios"
    for r in range(RES0, RES1 + 1):
        vacio = f'{R}!${C_NOM}{r}=""'
        ws.cell(r, 1, f'=IF({vacio},"",{R}!${C_NOM}{r})')

        def v(h):
            return f"{R}!${COL_RES[h]}{r}"

        def d(marc):
            return f"${COL_DER[marc]}{r}"

        formulas = {
            "__MOVILIDAD__": f'IFERROR({v("uo_cP")}/{v("uw_cP")},"")',
            "__P_SOBRE_PB__": f'IFERROR({v("P_actual_psi")}/{v("Pb_psi")},"")',
            "__RATIO_CONV__":
                f'IFERROR({v("Pozos_convertibles")}/{v("Pozos_activos")},"")',
            "__INCREMENTAL__": f'IFERROR({v("OOIP_Mbbl")}*Delta_RF,"")',
            "__INYECTORES__":
                f'IFERROR(MAX(1,ROUND({v("Pozos_activos")}*Rel_Iny_Pozos,0)),"")',
            "__CONVERSIONES__":
                f'IFERROR(MIN({v("Pozos_convertibles")},{d("__INYECTORES__")}),"")',
            "__NUEVOS__":
                f'IFERROR(MAX(0,{d("__INYECTORES__")}-{d("__CONVERSIONES__")}),"")',
            "__WINY__":
                f'IFERROR({d("__INCREMENTAL__")}*1000*Rel_Iny_Prod'
                f'/(Vida_Proyecto*365),"")',
            "__CAPEX__":
                f'IFERROR(({d("__CONVERSIONES__")}*C_Conversion'
                f'+{d("__NUEVOS__")}*C_Inyector_Nuevo'
                f'+{d("__WINY__")}*C_Planta_bpd+C_Fijo)/1000000,"")',
            "__OPEX_ANUAL__":
                f'IFERROR({d("__WINY__")}*365*Opex_Agua/1000000'
                f'+{d("__CAPEX__")}*Opex_Fijo_Pct,"")',
            "__PROD_ANUAL__": f'IFERROR({d("__INCREMENTAL__")}/Vida_Proyecto,"")',
            "__FLUJO_ANUAL__":
                f'IFERROR({d("__PROD_ANUAL__")}*1000*Precio_Base'
                f'*(1-Regalias_Part)/1000000-{d("__OPEX_ANUAL__")},"")',
            "__VAN__":
                f'IFERROR(-{d("__CAPEX__")}+{d("__FLUJO_ANUAL__")}'
                f'*Factor_Anualidad,"")',
            "__VAN_BAJO__":
                f'IFERROR(-{d("__CAPEX__")}+({d("__PROD_ANUAL__")}*1000*Precio_Bajo'
                f'*(1-Regalias_Part)/1000000-{d("__OPEX_ANUAL__")})'
                f'*Factor_Anualidad,"")',
            "__ROBUSTEZ__":
                f'IF(NOT(ISNUMBER({d("__VAN_BAJO__")})),"",'
                f'IF({d("__VAN_BAJO__")}>0,1,0))',
            "__COSTO_BBL__":
                f'IFERROR({d("__CAPEX__")}*1000000'
                f'/({d("__INCREMENTAL__")}*1000),"")',
            "__PAYBACK__":
                f'IFERROR(IF({d("__FLUJO_ANUAL__")}<=0,"",'
                f'{d("__CAPEX__")}/{d("__FLUJO_ANUAL__")}),"")',
        }
        for marc, _e, _u, fmt in DERIVADAS:
            c = ws.cell(r, IDX_DER[marc], f'=IF({vacio},"",{formulas[marc]})')
            c.number_format = fmt

    ws.freeze_panes = "B3"
    proteger(ws)
    return ws


# ===========================================================================
# Killing_Factors
# ===========================================================================
def _comparador(comp, V, umb, si_cumple, si_no):
    """
    Comparación cuyo operador vive en una celda editable.

    El comparador no se fija al generar el libro: se lee de la hoja Criterios,
    de modo que un ingeniero puede cambiar un factor de "menor que" a "mayor
    que" sin tocar código.
    """
    return (f'IF({comp}="<",IF({V}<{umb},{si_cumple},{si_no}),'
            f'IF({comp}=">",IF({V}>{umb},{si_cumple},{si_no}),'
            f'IF({V}={umb},{si_cumple},{si_no})))')


def hoja_killing(wb, filas_crit):
    ws = wb.create_sheet("Killing_Factors")
    nd, nm = len(KILLING_DUROS), len(KILLING_MITIGABLES)
    C_KF0 = 3
    C_MOTIVO = C_KF0 + nd
    C_DESC = C_MOTIVO + 1
    C_M0 = C_DESC + 1
    C_PEN = {s: C_M0 + nm + i for i, (s, _p) in enumerate(PESOS_IAW)}
    C_EST = C_M0 + nm + len(PESOS_IAW)
    ancho_tot = C_EST

    f = titulo(ws, 1, "KILLING FACTORS — descartes con motivo registrado", ancho_tot)
    enc = ["Reservorio", "Es prueba"]
    enc += [c[0] for c in KILLING_DUROS]
    enc += ["Motivo del descarte", "¿Descartado?"]
    enc += [c[0] for c in KILLING_MITIGABLES]
    enc += [f"Penaliz. {s}" for s, _p in PESOS_IAW]
    enc += ["Estudios que se disparan"]
    cabeceras(ws, RES_CAB, enc)
    anchos(ws, {"A": 22, "B": 9, CL(C_MOTIVO): 26, CL(C_DESC): 12,
                CL(C_EST): 70})
    for j in range(C_KF0, C_KF0 + nd):
        ws.column_dimensions[CL(j)].width = 9
    for j in range(C_M0, C_M0 + nm):
        ws.column_dimensions[CL(j)].width = 9
    for j in C_PEN.values():
        ws.column_dimensions[CL(j)].width = 11

    for r in range(RES0, RES1 + 1):
        vacio = f'Reservorios!${C_NOM}{r}=""'
        ws.cell(r, 1, f'=IF({vacio},"",Reservorios!${C_NOM}{r})')
        # Las filas de verificación se marcan por su prefijo y quedan fuera del
        # ranking sin necesidad de mantener una lista aparte.
        ws.cell(r, 2, f'=IF({vacio},"",IF(LEFT(Reservorios!${C_NOM}{r},7)="PRUEBA",1,0))')

        for i, (cod, _n, _c, _u, _un, col, _sf, _m) in enumerate(KILLING_DUROS):
            fk = filas_crit[cod]
            V = ref_valor(col, r)
            comp, umb = f"Criterios!$C${fk}", f"Criterios!$D${fk}"
            ws.cell(r, C_KF0 + i,
                    f'=IF(OR({vacio},{V}=""),"",'
                    + _comparador(comp, V, umb, f'"{cod}"', '""') + ')'
                    ).alignment = Alignment(horizontal="center")

        piezas = "&\" \"&".join(f"${CL(C_KF0 + i)}{r}" for i in range(nd))
        ws.cell(r, C_MOTIVO, f'=IF({vacio},"",TRIM({piezas}))')
        ws.cell(r, C_DESC,
                f'=IF({vacio},"",IF(${CL(C_MOTIVO)}{r}="","NO","SÍ"))'
                ).alignment = Alignment(horizontal="center")

        for i, (cod, _n, _c, _u, _un, col, _s, _p, _e) in enumerate(KILLING_MITIGABLES):
            fm = filas_crit[cod]
            V = ref_valor(col, r)
            comp, umb = f"Criterios!$C${fm}", f"Criterios!$D${fm}"
            ws.cell(r, C_M0 + i,
                    f'=IF(OR({vacio},{V}=""),0,'
                    + _comparador(comp, V, umb, "1", "0") + ')'
                    ).alignment = Alignment(horizontal="center")

        for sub, _p in PESOS_IAW:
            factores = []
            for i, (cod, *_x) in enumerate(KILLING_MITIGABLES):
                fm = filas_crit[cod]
                factores.append(
                    f'(1-IF(AND(Criterios!$F${fm}="{sub}",'
                    f'${CL(C_M0 + i)}{r}=1),Criterios!$G${fm},0))')
            c = ws.cell(r, C_PEN[sub], f'=IF({vacio},"",{"*".join(factores)})')
            c.number_format = "0.00"
            c.alignment = Alignment(horizontal="center")

        est = []
        for i, (cod, *_x) in enumerate(KILLING_MITIGABLES):
            fm = filas_crit[cod]
            est.append(f'IF(${CL(C_M0 + i)}{r}=1,Criterios!$L${fm}&" ","")')
        ws.cell(r, C_EST, f'=IF({vacio},"",TRIM({"&".join(est)}))'
                ).alignment = Alignment(wrap_text=True, vertical="top")

    ws.conditional_formatting.add(
        f"{CL(C_DESC)}{RES0}:{CL(C_DESC)}{RES1}",
        CellIsRule(operator="equal", formula=['"SÍ"'],
                   fill=PatternFill("solid", fgColor=ROJO)))
    ws.conditional_formatting.add(
        f"{CL(C_DESC)}{RES0}:{CL(C_DESC)}{RES1}",
        CellIsRule(operator="equal", formula=['"NO"'],
                   fill=PatternFill("solid", fgColor=VERDE)))

    nombrar(wb, "KF_Descartado", "Killing_Factors",
            f"${CL(C_DESC)}${RES0}:${CL(C_DESC)}${RES1}")
    nombrar(wb, "KF_Motivo", "Killing_Factors",
            f"${CL(C_MOTIVO)}${RES0}:${CL(C_MOTIVO)}${RES1}")
    nombrar(wb, "KF_EsPrueba", "Killing_Factors", f"$B${RES0}:$B${RES1}")
    nombrar(wb, "KF_Estudios", "Killing_Factors",
            f"${CL(C_EST)}${RES0}:${CL(C_EST)}${RES1}")
    for sub, _p in PESOS_IAW:
        nombrar(wb, f"KF_Pen{sub}", "Killing_Factors",
                f"${CL(C_PEN[sub])}${RES0}:${CL(C_PEN[sub])}${RES1}")
    ws.freeze_panes = "C3"
    proteger(ws)
    return ws, {"desc": C_DESC, "motivo": C_MOTIVO, "prueba": 2, "pen": C_PEN}


# ===========================================================================
# Scoring
# ===========================================================================
def hoja_scoring(wb, filas_crit, filas_texto):
    ws = wb.create_sheet("Scoring")
    n = len(CRITERIOS)
    C_PTS0 = 2
    C_PES0 = C_PTS0 + n
    C_BLOQ = {s: C_PES0 + n + i for i, (s, _p) in enumerate(PESOS_IAW)}
    C_SUB = {s: C_PES0 + n + len(PESOS_IAW) + i
             for i, (s, _p) in enumerate(PESOS_IAW)}
    C_IAW = C_PES0 + n + 2 * len(PESOS_IAW)
    C_RANKV, C_ORDEN, C_CUAD, C_COMP = C_IAW + 1, C_IAW + 2, C_IAW + 3, C_IAW + 4

    f = titulo(ws, 1, "SCORING — puntajes, subíndices e IAW", C_COMP)
    enc = ["Reservorio"]
    enc += [f"{c[0]} pts" for c in CRITERIOS]
    enc += [f"{c[0]} peso" for c in CRITERIOS]
    enc += [f"Bloqueo {s}" for s, _p in PESOS_IAW]
    enc += [s for s, _p in PESOS_IAW]
    enc += ["IAW", "IAW p/ranking", "Orden", "Cuadrante", "Completitud"]
    cabeceras(ws, RES_CAB, enc)
    ws.column_dimensions["A"].width = 22
    for j in range(2, C_COMP + 1):
        ws.column_dimensions[CL(j)].width = 10
    ws.column_dimensions[CL(C_CUAD)].width = 26

    idx_sub = {s: [i for i, c in enumerate(CRITERIOS) if c[2] == s]
               for s, _p in PESOS_IAW}

    def disponible(crit, r):
        cod, _n, _s, _p, tipo, _a, _b, _c, _d, col, _sf, _pen = crit
        V = ref_valor(col, r)
        return f"ISNUMBER({V})" if tipo == "NUM" else f'({V}<>"")'

    for r in range(RES0, RES1 + 1):
        vacio = f'Reservorios!${C_NOM}{r}=""'
        ws.cell(r, 1, f'=IF({vacio},"",Reservorios!${C_NOM}{r})')

        for i, crit in enumerate(CRITERIOS):
            cod, _nom, _sub, _peso, tipo, *_resto = crit
            col = crit[9]
            cr = filas_crit[cod]
            V = ref_valor(col, r)
            disp = disponible(crit, r)
            falta = f"Criterios!$J${cr}"
            pen = f"Criterios!$K${cr}"
            peso = f"Criterios!$D${cr}"

            if tipo == "NUM":
                bruto = formula_interp(V, f"Criterios!$F${cr}", f"Criterios!$G${cr}",
                                       f"Criterios!$H${cr}", f"Criterios!$I${cr}")
            else:
                r0, r1 = filas_texto[cod]
                bruto = (f'IFERROR(INDEX(Criterios!$D${r0}:$D${r1},'
                         f'MATCH({V},Criterios!$B${r0}:$B${r1},0)),0)')
            c = ws.cell(r, C_PTS0 + i,
                        f'=IF({vacio},"",IF({disp},{bruto},'
                        f'IF({falta}="PENALIZA",{pen},0)))')
            c.number_format = "0.00"
            ws.cell(r, C_PES0 + i,
                    f'=IF({vacio},"",IF({disp},{peso},'
                    f'IF({falta}="OMITE",0,{peso})))').number_format = "0"

        for sub, _p in PESOS_IAW:
            idxs = idx_sub[sub]
            bloqueantes = []
            for i in idxs:
                cr = filas_crit[CRITERIOS[i][0]]
                bloqueantes.append(
                    f'AND(Criterios!$J${cr}="BLOQUEA",NOT({disponible(CRITERIOS[i], r)}))')
            ws.cell(r, C_BLOQ[sub],
                    f'=IF({vacio},"",IF(OR({",".join(bloqueantes)}),1,0))'
                    ).alignment = Alignment(horizontal="center")

            p0, p1 = CL(C_PTS0 + idxs[0]), CL(C_PTS0 + idxs[-1])
            w0, w1 = CL(C_PES0 + idxs[0]), CL(C_PES0 + idxs[-1])
            c = ws.cell(r, C_SUB[sub],
                        f'=IF({vacio},"",IF(${CL(C_BLOQ[sub])}{r}=1,"",'
                        f'IFERROR(SUMPRODUCT({p0}{r}:{p1}{r},{w0}{r}:{w1}{r})'
                        f'/SUM({w0}{r}:{w1}{r})*10*INDEX(KF_Pen{sub},{r - RES0 + 1}),'
                        f'"")))')
            c.number_format = "0.0"

        geo = "*".join(f"${CL(C_SUB[s])}{r}^Peso_{s}" for s, _p in PESOS_IAW)
        faltan = ",".join(f'${CL(C_SUB[s])}{r}=""' for s, _p in PESOS_IAW)
        c = ws.cell(r, C_IAW,
                    f'=IF({vacio},"",IF(OR(INDEX(KF_Descartado,{r - RES0 + 1})="SÍ",'
                    f'{faltan}),"",IFERROR({geo},"")))')
        c.number_format = "0.0"
        ws.cell(r, C_RANKV,
                f'=IF(OR(${CL(C_IAW)}{r}="",INDEX(KF_EsPrueba,{r - RES0 + 1})=1),'
                f'"",${CL(C_IAW)}{r})').number_format = "0.0"

        rk = CL(C_RANKV)
        ws.cell(r, C_ORDEN,
                f'=IF(${rk}{r}="","",RANK(${rk}{r},${rk}${RES0}:${rk}${RES1})'
                f'+COUNTIF(${rk}${RES0}:${rk}{r},${rk}{r})-1)'
                ).alignment = Alignment(horizontal="center")

        iaw, xs = f"${CL(C_IAW)}{r}", f"${CL(C_SUB['X'])}{r}"
        ws.cell(r, C_CUAD,
                f'=IF({iaw}="","",IF(AND({iaw}>=Umbral_IAW,{xs}>=Umbral_X),'
                f'"AVANZAR A FACTIBILIDAD",IF({iaw}>=Umbral_IAW,'
                f'"DESBLOQUEAR PRIMERO",IF({xs}>=Umbral_X,"CANDIDATO A PILOTO",'
                f'"DESCARTAR O DIFERIR"))))')
        ws.cell(r, C_COMP,
                f'=IF({vacio},"",Reservorios!${COL_RES["Completitud_global"]}{r})'
                ).number_format = "0%"

    for j, nom in ((C_IAW, "Sco_IAW"), (C_ORDEN, "Sco_Orden"),
                   (C_CUAD, "Sco_Cuadrante"), (C_COMP, "Sco_Completitud")):
        nombrar(wb, nom, "Scoring", f"${CL(j)}${RES0}:${CL(j)}${RES1}")
    for sub, _p in PESOS_IAW:
        nombrar(wb, f"Sco_{sub}", "Scoring",
                f"${CL(C_SUB[sub])}${RES0}:${CL(C_SUB[sub])}${RES1}")
    nombrar(wb, "Sco_Reservorio", "Scoring", f"$A${RES0}:$A${RES1}")

    ws.freeze_panes = "B3"
    proteger(ws)
    return ws, {"sub": C_SUB, "iaw": C_IAW, "orden": C_ORDEN,
                "cuad": C_CUAD, "comp": C_COMP, "bloq": C_BLOQ}


# ===========================================================================
# Ranking
# ===========================================================================
def hoja_ranking(wb, ws_scoring, cols_sco):
    ws = wb.create_sheet("Ranking")
    anchos(ws, {"A": 8, "B": 24, "C": 10, "D": 9, "E": 9, "F": 9, "G": 12,
                "H": 28, "I": 40})
    f = titulo(ws, 1, "RANKING DEL PORTAFOLIO", 9)
    f = nota(ws, f, "Solo aparecen los reservorios evaluables. Los descartados "
                    "están en la hoja Killing_Factors con su motivo; no "
                    "desaparecen del análisis.")
    f += 1

    f_res = f
    f = subtitulo(ws, f, "RESUMEN DEL PORTAFOLIO", 9)
    resumen = [
        ("Reservorios cargados",
         f'=SUMPRODUCT(--(Sco_Reservorio<>""))-SUMPRODUCT(--(KF_EsPrueba=1))'),
        ("Descartados por killing factor",
         '=SUMPRODUCT(--(KF_Descartado="SÍ"),--(KF_EsPrueba<>1))'),
        ("Evaluables con IAW", '=SUMPRODUCT(--(Sco_IAW<>""),--(KF_EsPrueba<>1))'),
        ("Avanzar a factibilidad",
         '=COUNTIF(Sco_Cuadrante,"AVANZAR A FACTIBILIDAD")'),
        ("Desbloquear primero", '=COUNTIF(Sco_Cuadrante,"DESBLOQUEAR PRIMERO")'),
        ("Candidato a piloto", '=COUNTIF(Sco_Cuadrante,"CANDIDATO A PILOTO")'),
        ("Descartar o diferir", '=COUNTIF(Sco_Cuadrante,"DESCARTAR O DIFERIR")'),
        ("Completitud media del portafolio",
         '=IFERROR(SUMPRODUCT(Sco_Completitud,--(Sco_IAW<>""))'
         '/SUMPRODUCT(--(Sco_IAW<>"")),"")'),
    ]
    for etiqueta, formula in resumen:
        ws.cell(f, 1, etiqueta).font = F_CAB
        ws.merge_cells(start_row=f, start_column=1, end_row=f, end_column=2)
        c = ws.cell(f, 3, formula)
        c.fill = R_CAB
        c.alignment = Alignment(horizontal="center")
        if "Completitud" in etiqueta:
            c.number_format = "0%"
        f += 1
    _ = f_res
    f += 1

    f = subtitulo(ws, f, "ORDEN POR ÍNDICE DE ATRACTIVO", 9)
    f = cabeceras(ws, f, ["Puesto", "Reservorio", "IAW", "T", "E", "X",
                          "Completitud", "Cuadrante", "Estudios que se disparan"])
    f0 = f
    for k in range(1, MAX_RES + 1):
        r = f0 + k - 1
        ws.cell(r, 1, k).alignment = Alignment(horizontal="center")
        base = f'MATCH($A{r},Sco_Orden,0)'
        ws.cell(r, 2, f'=IFERROR(INDEX(Sco_Reservorio,{base}),"")')
        for j, rng in ((3, "Sco_IAW"), (4, "Sco_T"), (5, "Sco_E"), (6, "Sco_X")):
            c = ws.cell(r, j, f'=IFERROR(INDEX({rng},{base}),"")')
            c.number_format = "0.0"
        ws.cell(r, 7, f'=IFERROR(INDEX(Sco_Completitud,{base}),"")'
                ).number_format = "0%"
        ws.cell(r, 8, f'=IFERROR(INDEX(Sco_Cuadrante,{base}),"")')
        ws.cell(r, 9, f'=IFERROR(INDEX(KF_Estudios,{base}),"")'
                ).alignment = Alignment(wrap_text=True, vertical="top")
    f1 = f0 + MAX_RES - 1

    ws.conditional_formatting.add(
        f"C{f0}:C{f1}",
        ColorScaleRule(start_type="num", start_value=0, start_color="F8696B",
                       mid_type="num", mid_value=50, mid_color="FFEB84",
                       end_type="num", end_value=100, end_color="63BE7B"))
    for texto, color in (("AVANZAR A FACTIBILIDAD", VERDE),
                         ("DESBLOQUEAR PRIMERO", AMARILLO),
                         ("CANDIDATO A PILOTO", "DDEBF7"),
                         ("DESCARTAR O DIFERIR", ROJO)):
        ws.conditional_formatting.add(
            f"H{f0}:H{f1}",
            CellIsRule(operator="equal", formula=[f'"{texto}"'],
                       fill=PatternFill("solid", fgColor=color)))

    # Matriz de decisión: ejecutabilidad contra atractivo
    ch = ScatterChart()
    ch.title = "Matriz de decisión — Ejecutabilidad (X) vs Atractivo (IAW)"
    ch.x_axis.title = "Ejecutabilidad X"
    ch.y_axis.title = "IAW"
    ch.height, ch.width = 11, 17
    xref = Reference(ws_scoring, min_col=cols_sco["sub"]["X"],
                     min_row=RES0, max_row=RES1)
    s = Series(Reference(ws_scoring, min_col=cols_sco["iaw"],
                         min_row=RES0, max_row=RES1), xref, title="Reservorios")
    s.marker = Marker(symbol="circle", size=7)
    s.graphicalProperties.line = LineProperties(noFill=True)
    ch.series.append(s)
    ch.x_axis.delete = False
    ch.y_axis.delete = False
    ws.add_chart(ch, "K4")
    ws.freeze_panes = f"A{f0}"
    return ws


# ===========================================================================
# Ficha
# ===========================================================================
def hoja_ficha(wb):
    ws = wb.create_sheet("Ficha")
    anchos(ws, {"A": 34, "B": 22, "C": 14, "D": 34, "E": 22})
    f = titulo(ws, 1, "FICHA DE RESERVORIO", 5)
    f += 1
    ws.cell(f, 1, "Reservorio").font = F_CAB
    sel = celda_entrada(ws, f, 2)
    sel.font = Font(bold=True, size=12)
    nombrar(wb, "Ficha_Sel", "Ficha", f"$B${f}")
    dv = DataValidation(type="list", formula1="=Sco_Reservorio",
                        allow_blank=True, showDropDown=False)
    ws.add_data_validation(dv)
    dv.add(sel)
    nota(ws, f + 1, "Elegir de la lista. Todo lo de abajo se actualiza solo.")
    f += 3

    P = "MATCH(Ficha_Sel,Sco_Reservorio,0)"
    PR = f"MATCH(Ficha_Sel,Reservorios!${C_NOM}$3:${C_NOM}$102,0)"

    def bloque(titulo_bloque, items, col=1):
        nonlocal f
        inicio = f
        f = subtitulo(ws, f, titulo_bloque, 5)
        for etiqueta, formula, fmt in items:
            ws.cell(f, col, etiqueta).font = F_CAB
            c = ws.cell(f, col + 1, formula)
            c.fill = R_CAB
            c.border = BORDE_FINO
            if fmt:
                c.number_format = fmt
            f += 1
        f += 1
        return inicio

    def de_res(h, fmt=None):
        return (f'=IFERROR(INDEX(Reservorios!'
                f'${COL_RES[h]}$3:${COL_RES[h]}$102,{PR}),"")', fmt)

    bloque("DECISIÓN", [
        ("Cuadrante", f'=IFERROR(INDEX(Sco_Cuadrante,{P}),"")', None),
        ("IAW", f'=IFERROR(INDEX(Sco_IAW,{P}),"")', "0.0"),
        ("Subíndice técnico (T)", f'=IFERROR(INDEX(Sco_T,{P}),"")', "0.0"),
        ("Subíndice económico (E)", f'=IFERROR(INDEX(Sco_E,{P}),"")', "0.0"),
        ("Ejecutabilidad (X)", f'=IFERROR(INDEX(Sco_X,{P}),"")', "0.0"),
        ("Completitud de datos", f'=IFERROR(INDEX(Sco_Completitud,{P}),"")', "0%"),
        ("Banda de confianza",
         f'=IFERROR(IF(INDEX(Sco_Completitud,{P})>=0.75,'
         f'"El ranking es defendible",IF(INDEX(Sco_Completitud,{P})>=0.5,'
         f'"Indicativo: verificar antes de comprometer capital",'
         f'"NO usar para decidir; usar para priorizar la recopilación")),"")', None),
        ("¿Descartado?", f'=IFERROR(INDEX(KF_Descartado,{P}),"")', None),
        ("Motivo del descarte", f'=IFERROR(INDEX(KF_Motivo,{P}),"")', None),
    ])

    bloque("RESERVORIO", [
        ("Campo", *de_res("Campo")),
        ("Tipo", *de_res("Tipo")),
        ("OOIP (Mbbl)", *de_res("OOIP_Mbbl", "#,##0")),
        ("Np (Mbbl)", *de_res("Np_Mbbl", "#,##0.0")),
        ("Factor de recobro actual", *de_res("RF_actual", "0.0%")),
        ("Petróleo móvil remanente", *de_res("Movil_remanente", "0.000")),
        ("Permeabilidad (mD)", *de_res("Perm_mD", "#,##0")),
        ("Espesor neto (m)", *de_res("Espesor_neto_m", "0.0")),
        ("Diagnóstico de agua (Chan)", *de_res("Chan_clase")),
    ])

    bloque("ECONOMÍA PRELIMINAR (clase 5)", [
        ("Incremental recuperable (Mbbl)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__INCREMENTAL__"]}$3:'
         f'${COL_DER["__INCREMENTAL__"]}$102,{PR}),"")', "#,##0"),
        ("Capex (MM US$)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__CAPEX__"]}$3:'
         f'${COL_DER["__CAPEX__"]}$102,{PR}),"")', "#,##0.0"),
        ("Costo de desarrollo (US$/bbl)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__COSTO_BBL__"]}$3:'
         f'${COL_DER["__COSTO_BBL__"]}$102,{PR}),"")', "#,##0.0"),
        ("VAN al 10% (MM US$)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__VAN__"]}$3:'
         f'${COL_DER["__VAN__"]}$102,{PR}),"")', "#,##0.0"),
        ("VAN al precio bajo (MM US$)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__VAN_BAJO__"]}$3:'
         f'${COL_DER["__VAN_BAJO__"]}$102,{PR}),"")', "#,##0.0"),
        ("Payback (años)",
         f'=IFERROR(INDEX(Derivadas!${COL_DER["__PAYBACK__"]}$3:'
         f'${COL_DER["__PAYBACK__"]}$102,{PR}),"")', "0.0"),
    ])

    inicio = bloque("ESTUDIOS QUE SE DISPARAN", [])
    _ = inicio
    c = ws.cell(f - 1, 1, f'=IFERROR(INDEX(KF_Estudios,{P}),"")')
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells(start_row=f - 1, start_column=1, end_row=f + 2, end_column=5)
    ws.print_area = f"A1:E{f + 3}"
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    return ws


# ===========================================================================
# Pruebas — los casos golden, evaluados por las mismas fórmulas del libro
# ===========================================================================
CASOS_ESPERADOS = [
    ("PRUEBA-K1", "¿Descartado?", 'INDEX(KF_Descartado,{p})', "SÍ", None,
     "Móvil remanente 0,02 por debajo del umbral de K1."),
    ("PRUEBA-K2", "¿Descartado?", 'INDEX(KF_Descartado,{p})', "SÍ", None,
     "Condensado seco: K2 descarta sin evaluar nada más."),
    ("PRUEBA-T10", "Subíndice T", 'INDEX(Sco_T,{p})', 100.0, 0.05,
     "Todos los criterios técnicos en su punto de 10."),
    ("PRUEBA-T04", "Subíndice T", 'INDEX(Sco_T,{p})', 40.0, 0.05,
     "Todos los criterios técnicos en su punto de 4."),
    ("PRUEBA-OMIT", "Subíndice T", 'INDEX(Sco_T,{p})', 100.0, 0.05,
     "Igual a T10 pero sin Dykstra-Parsons ni NTG. Verifica que los pesos se "
     "renormalicen: si no lo hicieran, T caería a 77."),
    ("PRUEBA-X10", "Ejecutabilidad X", 'INDEX(Sco_X,{p})', 100.0, 0.05,
     "Todos los criterios de ejecutabilidad en su máximo."),
]


def hoja_pruebas(wb, filas_crit):
    ws = wb.create_sheet("Pruebas")
    anchos(ws, {"A": 18, "B": 20, "C": 14, "D": 14, "E": 12, "F": 66})
    f = titulo(ws, 1, "PRUEBAS — casos con respuesta conocida", 6)
    f = nota(ws, f, "Correr esta hoja después de CUALQUIER cambio en Criterios o "
                    "en Supuestos_Económicos, y anotar el resultado en el "
                    "changelog. Si algo sale en ROJO, el cambio rompió la "
                    "metodología.")
    f += 1

    f = subtitulo(ws, f, "CASOS SOBRE LAS FÓRMULAS REALES DEL LIBRO", 6)
    f = cabeceras(ws, f, ["Caso", "Qué verifica", "Obtenido", "Esperado",
                          "Resultado", "Por qué existe este caso"])
    f_ini = f
    for nombre, que, plantilla, esperado, tol, por_que in CASOS_ESPERADOS:
        p = f'MATCH("{nombre}",Sco_Reservorio,0)'
        ws.cell(f, 1, nombre).font = F_CAB
        ws.cell(f, 2, que)
        c = ws.cell(f, 3, f'=IFERROR({plantilla.format(p=p)},"no encontrado")')
        c.alignment = Alignment(horizontal="center")
        if tol:
            c.number_format = "0.00"
        e = ws.cell(f, 4, esperado)
        e.alignment = Alignment(horizontal="center")
        if tol:
            e.number_format = "0.00"
        if tol:
            res = f'=IF(ISNUMBER($C{f}),IF(ABS($C{f}-$D{f})<={tol},"OK","FALLA"),"FALLA")'
        else:
            res = f'=IF($C{f}=$D{f},"OK","FALLA")'
        r = ws.cell(f, 5, res)
        r.font = F_CAB
        r.alignment = Alignment(horizontal="center")
        d = ws.cell(f, 6, por_que)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 30
        f += 1
    f_fin = f - 1
    f += 1

    f = subtitulo(ws, f, "CONTROLES DE LA METODOLOGÍA", 6)
    f = cabeceras(ws, f, ["Control", "Qué verifica", "Obtenido", "Esperado",
                          "Resultado", "Por qué"])
    f_ini2 = f
    controles = [
        ("Media geométrica", "IAW con T=90, E=70, X=20",
         "=90^Peso_T*70^Peso_E*20^Peso_X", 56.59, 0.02,
         "Un promedio aritmético daría 65,5 y dejaría este caso por encima de "
         "uno parejo de 60. La media geométrica lo baja a 56,6, que es el "
         "orden correcto: sin ejecutabilidad no hay proyecto."),
        ("Pesos del IAW", "Suma de los tres pesos",
         "=Peso_T+Peso_E+Peso_X", 1.0, 0.001, "Deben sumar 1,00."),
        ("Interpolación", "Punto medio entre x@7 y x@10 de T4 (permeabilidad)",
         "=" + formula_interp("125",
                              f"Criterios!$F${filas_crit['T4']}",
                              f"Criterios!$G${filas_crit['T4']}",
                              f"Criterios!$H${filas_crit['T4']}",
                              f"Criterios!$I${filas_crit['T4']}"),
         8.5, 0.01,
         "k=125 está a mitad de camino entre 50 (7 puntos) y 200 (10 puntos): "
         "debe dar 8,5. Verifica que la interpolación sea lineal y no un "
         "escalón."),
    ]
    for nombre, que, formula, esperado, tol, por_que in controles:
        ws.cell(f, 1, nombre).font = F_CAB
        ws.cell(f, 2, que)
        c = ws.cell(f, 3, formula)
        c.number_format = "0.000"
        c.alignment = Alignment(horizontal="center")
        e = ws.cell(f, 4, esperado)
        e.number_format = "0.000"
        e.alignment = Alignment(horizontal="center")
        r = ws.cell(f, 5,
                    f'=IF(ISNUMBER($C{f}),IF(ABS($C{f}-$D{f})<={tol},"OK","FALLA"),'
                    f'"FALLA")')
        r.font = F_CAB
        r.alignment = Alignment(horizontal="center")
        d = ws.cell(f, 6, por_que)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 44
        f += 1
    f_fin2 = f - 1
    f += 1

    ws.cell(f, 1, "RESULTADO GLOBAL").font = Font(bold=True, size=13)
    c = ws.cell(f, 3,
                f'=IF(COUNTIF($E${f_ini}:$E${f_fin2},"FALLA")=0,'
                f'"TODO OK","HAY FALLAS")')
    c.font = Font(bold=True, size=13)
    c.alignment = Alignment(horizontal="center")
    for rango_e in (f"E{f_ini}:E{f_fin}", f"E{f_ini2}:E{f_fin2}", f"C{f}"):
        for texto, color in (("OK", VERDE), ("TODO OK", VERDE),
                             ("FALLA", ROJO), ("HAY FALLAS", ROJO)):
            ws.conditional_formatting.add(
                rango_e, CellIsRule(operator="equal", formula=[f'"{texto}"'],
                                    fill=PatternFill("solid", fgColor=color)))
    return ws, f


# ===========================================================================
# Bibliografía
# ===========================================================================
BIBLIO_B = [
    ("Rangos de screening",
     "Taber, J.J., Martin, F.D. y Seright, R.S. — EOR Screening Criteria "
     "Revisited, Partes 1 y 2, SPE Reservoir Engineering 12(3), 1997",
     "Puntos de quiebre de los criterios técnicos"),
    ("Heterogeneidad y recobro",
     "Dykstra, H. y Parsons, R.L. — Prediction of Oil Recovery by Waterflood, "
     "JPT 8(11), 1956",
     "Criterio T3 y bandera roja M6"),
    ("Diagnóstico de agua",
     "Chan, K.S. — Water Control Diagnostic Plots, SPE 30775, 1995",
     "Columna Chan_clase, proveniente del Libro A"),
    ("Screening en campos maduros",
     "Screening Criteria for Waterflood Projects in Matured Reservoirs: Case "
     "Study of a Niger Delta Reservoir, SPE Nigeria, 2020",
     "Estructura de compuertas y factores eliminatorios"),
    ("Anillo de petróleo con casquete",
     "Development strategies of a gas condensate reservoir with a large gas "
     "cap, thin oil rim, strong bottom water and natural barriers, "
     "Petroleum Science, 2025",
     "Killing factors K2 y K2b"),
    ("Contexto boliviano",
     "YPFB — plan de campos maduros; inyección activa en Víbora, Sirari y "
     "Yapacaní",
     "PENDIENTE: tabla de analogías para reemplazar Delta_RF por defecto"),
]


def hoja_biblio(wb):
    ws = wb.create_sheet("Bibliografía")
    anchos(ws, {"A": 26, "B": 76, "C": 44})
    f = titulo(ws, 1, "BIBLIOGRAFÍA POR CRITERIO", 3)
    f += 1
    f = cabeceras(ws, f, ["Tema", "Referencia", "Dónde se usa"])
    for tema, ref, uso in BIBLIO_B:
        ws.cell(f, 1, tema).font = F_CAB
        for col, txt in ((2, ref), (3, uso)):
            c = ws.cell(f, col, txt)
            c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 42
        f += 1
    f += 1
    ws.cell(f, 1, "Estado de calibración").font = F_CAB
    c = ws.cell(f, 2,
                "Los umbrales de la versión 0.1 provienen de literatura "
                "internacional. Están PENDIENTES de calibración contra la "
                "experiencia boliviana en el taller de la Semana 8. Hasta "
                "entonces, el ranking ordena de forma consistente pero sus "
                "valores absolutos no están validados localmente.")
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[f].height = 62
    return ws


# ===========================================================================
def main():
    wb = Workbook()
    wb.remove(wb.active)

    hoja_leeme(wb)
    _ws_crit, filas_crit, filas_texto = hoja_criterios(wb)
    hoja_supuestos(wb)
    hoja_reservorios(wb)
    hoja_derivadas(wb)
    hoja_killing(wb, filas_crit)
    ws_sco, cols_sco = hoja_scoring(wb, filas_crit, filas_texto)
    hoja_ranking(wb, ws_sco, cols_sco)
    hoja_ficha(wb)
    hoja_pruebas(wb, filas_crit)
    hoja_biblio(wb)

    wb.properties.title = "Libro B — Screening de portafolio"
    wb.properties.creator = "Proyecto de screening de waterflooding — YPFB"

    destino = SALIDA / f"Libro_B_Screening_v{VERSION}.xlsx"
    wb.save(destino)
    print(f"Libro B -> {destino.relative_to(RAIZ)}")
    print(f"  hojas: {len(wb.sheetnames)}  |  nombres definidos: "
          f"{len(list(wb.defined_names))}")
    return destino


if __name__ == "__main__":
    main()
