"""
Utilidades compartidas por los generadores de los libros.

Regla que gobierna todo este módulo: cualquier fórmula que se emita acá tiene que
ser legible y modificable por un ingeniero dentro de Excel, sin macros, sin
complementos y sin funciones posteriores a Excel 2016.

Prohibido emitir: XLOOKUP, LET, LAMBDA, FILTER, SORT, UNIQUE, TEXTJOIN con
matrices, y cualquier fórmula que requiera Ctrl+Shift+Enter.

Permitido y preferido: INDEX/MATCH, SUMIFS, SUMPRODUCT, IFERROR, IF, INDIRECT
acotado. La regresión lineal se hace con SUMPRODUCT en su forma explícita —ver
`regresion_sumproduct`— porque LINEST con condiciones exige matriz CSE.
"""

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName

# --- Constantes compartidas con los generadores de datos y la referencia ------
DIAS_MES = 30.4375
MESES_ANIO = 12.0

# --- Paleta --------------------------------------------------------------
AZUL_TIT = "1F3864"
AZUL_SUB = "2E5C8A"
GRIS_CAB = "D9D9D9"
AMARILLO_IN = "FFF2CC"      # celdas de entrada: el usuario escribe acá
GRIS_CALC = "F2F2F2"        # celdas calculadas
VERDE = "C6EFCE"
AMARILLO = "FFEB9C"
ROJO = "FFC7CE"

F_TITULO = Font(bold=True, size=14, color="FFFFFF")
F_SUB = Font(bold=True, size=11, color="FFFFFF")
F_CAB = Font(bold=True, size=10)
F_NOTA = Font(italic=True, size=9, color="595959")
F_MONO = Font(name="Consolas", size=9)

R_TITULO = PatternFill("solid", fgColor=AZUL_TIT)
R_SUB = PatternFill("solid", fgColor=AZUL_SUB)
R_CAB = PatternFill("solid", fgColor=GRIS_CAB)
R_IN = PatternFill("solid", fgColor=AMARILLO_IN)
R_CALC = PatternFill("solid", fgColor=GRIS_CALC)

BORDE_FINO = Border(*[Side(style="thin", color="BFBFBF")] * 4)


def titulo(ws, fila, texto, ancho=8):
    ws.cell(fila, 1, texto).font = F_TITULO
    for c in range(1, ancho + 1):
        ws.cell(fila, c).fill = R_TITULO
    ws.row_dimensions[fila].height = 22
    return fila + 1


def subtitulo(ws, fila, texto, ancho=8):
    ws.cell(fila, 1, texto).font = F_SUB
    for c in range(1, ancho + 1):
        ws.cell(fila, c).fill = R_SUB
    return fila + 1


def nota(ws, fila, texto, col=1):
    ws.cell(fila, col, texto).font = F_NOTA
    return fila + 1


def cabeceras(ws, fila, encabezados, col0=1):
    for i, h in enumerate(encabezados):
        c = ws.cell(fila, col0 + i, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[fila].height = 30
    return fila + 1


def anchos(ws, mapa):
    for col, w in mapa.items():
        ws.column_dimensions[col].width = w


_ACENTOS = str.maketrans("áéíóúÁÉÍÓÚñÑüÜ", "aeiouAEIOUnNuU")


def limpiar_nombre(texto):
    """
    Normaliza un nombre de rango: sin acentos, sin eñes, sin guiones bajos.

    Excel acepta acentos en nombres definidos, pero se comportan mal al abrir el
    archivo en otra configuración regional o en LibreOffice. Como toda la
    metodología está en español, sanear acá es más barato que descubrirlo en la
    prueba de compatibilidad.
    """
    return "".join(ch for ch in texto.translate(_ACENTOS) if ch.isalnum())


def nombrar(wb, nombre, hoja, ref):
    """Define un rango con nombre. `ref` en formato $B$5 o $B$5:$B$100."""
    wb.defined_names.add(DefinedName(nombre, attr_text=f"'{hoja}'!{ref}"))


def celda_entrada(ws, fila, col, valor=None, fmt=None):
    c = ws.cell(fila, col, valor)
    c.fill = R_IN
    c.border = BORDE_FINO
    if fmt:
        c.number_format = fmt
    return c


def rango(hoja, col, f0, f1):
    """'Hoja'!$C$10:$C$609 — absoluto, para usar dentro de fórmulas."""
    L = col if isinstance(col, str) else get_column_letter(col)
    return f"'{hoja}'!${L}${f0}:${L}${f1}"


# ---------------------------------------------------------------------------
# Regresión lineal por SUMPRODUCT
# ---------------------------------------------------------------------------
def regresion_sumproduct(flag, x, y):
    """
    Devuelve (formula_pendiente, formula_intercepto) para una regresión lineal
    ponderada por una columna indicadora 0/1.

    Se usa la forma explícita de mínimos cuadrados

        m = (n*Sxy - Sx*Sy) / (n*Sxx - Sx^2)
        b = (Sy - m*Sx) / n

    en vez de LINEST/SLOPE porque acá hace falta filtrar filas por condición, y
    SLOPE(IF(...)) exige fórmula matricial con Ctrl+Shift+Enter: si el usuario
    edita la celda y sale con Enter, la fórmula se rompe en silencio y devuelve
    un número plausible pero incorrecto. SUMPRODUCT se comporta igual en
    cualquier versión de Excel y sobrevive a una edición accidental.

    `flag`, `x` e `y` son cadenas con referencias de rango ya absolutas.
    """
    n = f"SUMPRODUCT({flag})"
    sx = f"SUMPRODUCT({flag},{x})"
    sy = f"SUMPRODUCT({flag},{y})"
    sxy = f"SUMPRODUCT({flag},{x},{y})"
    sxx = f"SUMPRODUCT({flag},{x},{x})"
    pend = f"IFERROR(({n}*{sxy}-{sx}*{sy})/({n}*{sxx}-{sx}*{sx}),\"\")"
    inter = f"IFERROR(({sy}-(({n}*{sxy}-{sx}*{sy})/({n}*{sxx}-{sx}*{sx}))*{sx})/{n},\"\")"
    return pend, inter


def r2_sumproduct(flag, y, yhat):
    """R2 = 1 - SSres/SStot, con la media también ponderada por el indicador."""
    n = f"SUMPRODUCT({flag})"
    media = f"(SUMPRODUCT({flag},{y})/{n})"
    ssres = f"SUMPRODUCT({flag},({y}-{yhat})^2)"
    sstot = f"SUMPRODUCT({flag},({y}-{media})^2)"
    return f"IFERROR(1-{ssres}/{sstot},\"\")"


def proteger(ws):
    """Protección sin contraseña: evita borrar fórmulas por accidente, pero
    cualquiera puede desproteger desde Revisar > Desproteger hoja. La idea es
    prevenir el accidente, no impedir la edición."""
    ws.protection.sheet = True
    ws.protection.selectLockedCells = False
    ws.protection.formatCells = False
    # Sin llamar a set_password: la protección queda sin contraseña, que es
    # justamente la intención. Asignar None dispara el hasheo y falla.
