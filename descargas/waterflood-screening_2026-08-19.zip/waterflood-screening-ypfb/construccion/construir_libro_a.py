"""
Genera el Libro A — Diagnóstico de campo.

Un libro por campo. Entra la historia mensual de producción y presión; salen los
diagnósticos, los gráficos y una fila de resumen normalizada que se copia al
Libro B.

Sin macros, sin complementos, sin funciones posteriores a Excel 2016.
Ver `comun.py` para las reglas que gobiernan las fórmulas emitidas.
"""

from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference, ScatterChart, Series
from openpyxl.chart.marker import Marker
from openpyxl.drawing.line import LineProperties
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation

from comun import (AMARILLO, BORDE_FINO, DIAS_MES, F_CAB, F_NOTA, R_CAB, R_IN,
                   ROJO, VERDE, anchos, cabeceras, celda_entrada, limpiar_nombre,
                   nombrar, nota, proteger, regresion_sumproduct, subtitulo,
                   titulo)
from esquema_resumen import COLUMNAS_RESUMEN

RAIZ = Path(__file__).resolve().parent.parent
SALIDA = RAIZ / "herramienta"
SALIDA.mkdir(parents=True, exist_ok=True)

VERSION = "0.1"

MAX_FILAS = 6000        # filas de carga de producción (pozo x mes)
FIL0 = 2                # primera fila de datos en Carga_Producción
FIL1 = FIL0 + MAX_FILAS - 1

MESES = 600             # 50 años de serie mensual para el reservorio activo
SER0 = 4                # primera fila de datos en Serie
SER1 = SER0 + MESES - 1

MAX_RES = 10            # reservorios por campo en Carga_Estáticos
EST_C0 = 3              # primera columna de reservorio (C)

BS = [round(i * 0.05, 2) for i in range(21)]    # grilla de b: 0,00 a 1,00


# ===========================================================================
# Hoja LÉEME
# ===========================================================================
def hoja_leeme(wb):
    ws = wb.create_sheet("LÉEME")
    anchos(ws, {"A": 30, "B": 62, "C": 30})
    f = titulo(ws, 1, "LIBRO A — DIAGNÓSTICO DE CAMPO", 3)
    f += 1
    ws.cell(f, 1, "Versión").font = F_CAB
    ws.cell(f, 2, VERSION); f += 1
    ws.cell(f, 1, "Proyecto").font = F_CAB
    ws.cell(f, 2, "Screening de waterflooding — YPFB"); f += 1
    ws.cell(f, 1, "Requiere").font = F_CAB
    ws.cell(f, 2, "Excel 2016 o posterior. Sin macros, sin complementos.")
    f += 2

    f = subtitulo(ws, f, "CÓMO SE USA", 3)
    pasos = [
        ("1", "Copiar este archivo y renombrarlo con el nombre del campo."),
        ("2", "Pegar la historia de producción en la hoja Carga_Producción. "
              "Una fila por pozo y mes, ORDENADA por Pozo y luego por Fecha."),
        ("3", "Completar lo que se sepa en Carga_Estáticos. Lo que falte se deja "
              "vacío: NO se inventa ni se rellena con valores plausibles."),
        ("4", "Elegir el reservorio a analizar en la hoja Config, celda B5."),
        ("5", "Revisar Diagnóstico y Gráficos."),
        ("6", "Copiar la fila de la hoja Resumen y pegarla en la hoja Reservorios "
              "del Libro B. Repetir desde el paso 4 para cada reservorio."),
    ]
    for n, t in pasos:
        ws.cell(f, 1, n).font = F_CAB
        c = ws.cell(f, 2, t)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 30
        f += 1
    f += 1

    f = subtitulo(ws, f, "TRES REGLAS QUE NO SE PUEDEN VIOLAR", 3)
    reglas = [
        ("Ordenar los datos",
         "Los acumulados por pozo se calculan como suma corrida, que asume que "
         "las filas vienen ordenadas por Pozo y luego por Fecha. La columna "
         "Orden_OK de la hoja Cálculos avisa si no es así. Si marca error, los "
         "acumulados son incorrectos."),
        ("Vacío no es cero",
         "Celda vacía significa DESCONOCIDO. Cero significa CERO. Un pozo cerrado "
         "tiene Qo = 0; un pozo del que se perdió el registro tiene la celda "
         "vacía. Confundirlos deforma la declinación y el acumulado."),
        ("Cargar los eventos",
         "Un cambio de zona sin registrar se interpreta como canalización. La "
         "columna Evento es la que separa un diagnóstico correcto de uno que "
         "parece riguroso y no lo es."),
    ]
    for t, d in reglas:
        ws.cell(f, 1, t).font = F_CAB
        c = ws.cell(f, 2, d)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 58
        f += 1
    f += 1

    f = subtitulo(ws, f, "QUÉ HAY EN CADA HOJA", 3)
    hojas = [
        ("Config", "Reservorio activo y todos los parámetros de cálculo. Editable."),
        ("Carga_Producción", "Historia mensual por pozo. ENTRADA."),
        ("Carga_Estáticos", "Datos de reservorio. ENTRADA."),
        ("Cálculos", "Aritmética por fila. Calculada, no tocar."),
        ("Serie", "Serie mensual agregada del reservorio activo. Calculada."),
        ("Grilla_b", "Barrido del exponente de Arps. Calculada."),
        ("Diagnóstico", "Resultados e interpretación. Calculada."),
        ("Gráficos", "Los diez gráficos del reservorio activo."),
        ("Resumen", "La fila que se copia al Libro B."),
        ("Completitud", "Qué datos hay y cuáles faltan."),
        ("Bibliografía", "Referencia de cada método."),
    ]
    for n, d in hojas:
        ws.cell(f, 1, n).font = F_CAB
        ws.cell(f, 2, d)
        f += 1
    f += 1

    f = subtitulo(ws, f, "CHANGELOG — completar en cada cambio", 3)
    f = cabeceras(ws, f, ["Fecha", "Qué cambió y por qué", "Quién"])
    ws.cell(f, 1, "2026-08-17")
    ws.cell(f, 2, "Versión inicial 0.1")
    ws.cell(f, 3, "—")
    for i in range(12):
        for c in range(1, 4):
            celda_entrada(ws, f + 1 + i, c)
    return ws


# ===========================================================================
# Hoja Config
# ===========================================================================
PARAMS = [
    ("SECCION", "IDENTIFICACIÓN", None, None, None),
    ("Campo_Nombre", "Campo", "", "texto", "Nombre del campo"),
    ("Reservorio_Sel", "Reservorio activo", "", "lista",
     "El reservorio que se está analizando. Cambiarlo recalcula todo el libro."),
    ("Analista", "Analista", "", "texto", "Quién hizo el análisis"),
    ("Fecha_Analisis", "Fecha de análisis", "", "fecha", ""),

    ("SECCION", "CONSTANTES DE CÁLCULO", None, None, None),
    ("Dias_Mes", "Días por mes", DIAS_MES, "d",
     "Promedio 30,4375. Se usa para convertir caudal a volumen."),
    ("Limite_Economico", "Límite económico", 20.0, "bpd",
     "Caudal al que el pozo o reservorio deja de ser rentable. Define la EUR."),
    ("WOR_Economico", "WOR económico", 20.0, "bbl/bbl",
     "Relación agua-petróleo límite. Define la recuperación extrapolada."),
    ("Z_Gas", "Factor z del gas", 0.88, "—",
     "Se asume constante para el gráfico p/z. Simplificación aceptable para "
     "screening; en factibilidad se usa z(p)."),

    ("SECCION", "CLASIFICADOR DE CHAN (SPE 30775)", None, None, None),
    ("Chan_WOR_Min", "WOR mínimo", 0.05, "bbl/bbl",
     "Por debajo de este WOR no se clasifica: no hay suficiente agua."),
    ("Chan_Ventana", "Ventana de derivada", 3, "meses",
     "Semiancho de la diferencia centrada. Amplio a propósito: el dato mensual "
     "de campo es ruidoso y una derivada de dos puntos borra la firma."),
    ("Chan_Min_Puntos", "Mínimo de puntos", 18, "meses",
     "Con menos puntos válidos la clasificación no es confiable."),
    ("Chan_Pend_Canal", "Umbral de canalización", 0.25, "—",
     "Pendiente log-log de WOR' por encima de la cual se declara canalización."),
    ("Chan_Pend_Conif", "Umbral de conificación", -1.00, "—",
     "Pendiente log-log de WOR' por debajo de la cual se declara conificación. "
     "Es MUY negativo a propósito: si WOR ~ t^m entonces WOR' ~ t^(m-1), así que "
     "un pozo que se inunda despacio (m=0,8) da -0,2 sin tener patología. La "
     "conificación real asintota y da del orden de -3. Discrimina la magnitud, "
     "no el signo."),

    ("SECCION", "VENTANA DE AJUSTE DE DECLINACIÓN", None, None, None),
    ("Ajuste_Mes_Inicio", "Mes inicial", 0, "índice",
     "Índice del primer mes del ajuste (0 = primer mes con producción)."),
    ("Ajuste_Mes_Fin", "Mes final", MESES - 1, "índice",
     "Índice del último mes. Acotar la ventana al tramo representativo: ajustar "
     "sobre toda la historia mezcla períodos con mecanismos distintos."),
]


def hoja_config(wb):
    ws = wb.create_sheet("Config")
    anchos(ws, {"A": 26, "B": 16, "C": 10, "D": 74})
    f = titulo(ws, 1, "CONFIGURACIÓN", 4)
    f = nota(ws, f, "Las celdas amarillas son editables. Todo el libro depende de ellas.")
    f += 1
    f = cabeceras(ws, f, ["Parámetro", "Valor", "Unidad", "Qué es"])

    for nombre, etiqueta, valor, unidad, desc in PARAMS:
        if nombre == "SECCION":
            f = subtitulo(ws, f, etiqueta, 4)
            continue
        ws.cell(f, 1, etiqueta).font = F_CAB
        c = celda_entrada(ws, f, 2, valor)
        c.alignment = Alignment(horizontal="center")
        ws.cell(f, 3, unidad).alignment = Alignment(horizontal="center")
        d = ws.cell(f, 4, desc)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        if desc and len(desc) > 90:
            ws.row_dimensions[f].height = 58
        nombrar(wb, nombre, "Config", f"$B${f}")
        if nombre == "Reservorio_Sel":
            fila_sel = f
        f += 1

    # Lista desplegable de reservorios, tomada de las cabeceras de Carga_Estáticos
    dv = DataValidation(
        type="list",
        formula1=f"='Carga_Estáticos'!$C$3:${CL(EST_C0 + MAX_RES - 1)}$3",
        allow_blank=True, showDropDown=False)
    dv.error = "Elegí un reservorio de los cargados en Carga_Estáticos."
    dv.errorTitle = "Reservorio no válido"
    ws.add_data_validation(dv)
    dv.add(ws.cell(fila_sel, 2))
    return ws


# ===========================================================================
# Hoja Carga_Producción
# ===========================================================================
COLS_PROD = [
    ("Pozo", 14, None), ("Reservorio", 20, None), ("Fecha", 12, "DD/MM/YYYY"),
    ("Dias_operados", 11, "0.00"), ("Qo_bpd", 11, "#,##0.00"),
    ("Qw_bpd", 11, "#,##0.00"), ("Qg_Mpcd", 11, "#,##0.00"),
    ("Pwf_psi", 11, "#,##0"), ("Pwh_psi", 11, "#,##0"),
    ("Winy_bpd", 11, "#,##0.00"), ("Piny_psi", 11, "#,##0"), ("Evento", 34, None),
]


def hoja_carga_produccion(wb):
    ws = wb.create_sheet("Carga_Producción")
    for i, (h, w, fmt) in enumerate(COLS_PROD, start=1):
        c = ws.cell(1, i, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        ws.column_dimensions[CL(i)].width = w
        if fmt:
            for r in range(FIL0, FIL1 + 1):
                ws.cell(r, i).number_format = fmt
    for r in range(FIL0, min(FIL0 + 200, FIL1 + 1)):
        for i in range(1, len(COLS_PROD) + 1):
            ws.cell(r, i).fill = R_IN
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{CL(len(COLS_PROD))}{FIL1}"
    for nom, col in [("Prod_Pozo", "A"), ("Prod_Reservorio", "B"),
                     ("Prod_Fecha", "C")]:
        nombrar(wb, nom, "Carga_Producción", f"${col}${FIL0}:${col}${FIL1}")
    return ws


# ===========================================================================
# Hoja Carga_Estáticos
# ===========================================================================
ESTATICOS = [
    ("SECCION", "IDENTIFICACIÓN Y TIPO", None, None, None),
    ("Tipo", "Tipo de reservorio", "", "N1",
     "Petróleo negro / Petróleo volátil / Condensado con anillo / Condensado seco. "
     "Decide la rama metodológica y dispara el killing factor K2."),
    ("Formacion", "Formación", "", "N1", ""),
    ("Prof_m", "Profundidad media", "", "N1", "m bajo nivel del terreno"),

    ("SECCION", "VOLUMETRÍA  (Nivel 2 — desbloquea el IAW)", None, None, None),
    ("Area_ha", "Área del reservorio", "", "N2", "hectáreas"),
    ("Espesor_neto_m", "Espesor neto (net pay)", "", "N2", "m"),
    ("Porosidad", "Porosidad", "", "N2", "fracción, ej. 0,17"),
    ("Swi", "Saturación de agua inicial", "", "N2", "fracción"),
    ("NTG", "Net-to-gross", "", "N2", "fracción"),
    ("Boi", "Factor volumétrico inicial", "", "N2", "bbl/STB"),

    ("SECCION", "FLUIDOS  (Nivel 2)", None, None, None),
    ("API", "Gravedad API", "", "N2", "°API"),
    ("uo_cP", "Viscosidad del petróleo", "", "N2", "cP a condiciones de reservorio"),
    ("uw_cP", "Viscosidad del agua", "", "N2", "cP"),
    ("Bo", "Factor volumétrico actual", "", "N2", "bbl/STB"),
    ("Bw", "Factor volumétrico del agua", "", "N2", "bbl/STB"),
    ("Bg", "Factor volumétrico del gas", "", "N2", "bbl/Mpc"),
    ("Rs", "Relación gas disuelto", "", "N2", "pc/bbl"),
    ("Pb_psi", "Presión de burbuja", "", "N2", "psi"),
    ("Pi_psi", "Presión inicial", "", "N2", "psi"),
    ("P_actual_psi", "Presión actual", "", "N2", "psi"),
    ("Temp_F", "Temperatura", "", "N2", "°F"),

    ("SECCION", "ROCA  (Nivel 2 y 3)", None, None, None),
    ("Perm_mD", "Permeabilidad", "", "N2", "mD"),
    ("Sor", "Saturación residual de petróleo", "", "N3",
     "fracción. Medida en núcleo si existe; si es correlación, anotarlo."),
    ("So_actual", "Saturación actual de petróleo", "", "N3",
     "fracción. De registro de saturación o balance de materia."),
    ("V_DykstraParsons", "Coeficiente de Dykstra-Parsons", "", "N3", "0 a 1"),
    ("Buzamiento_deg", "Buzamiento", "", "N2", "grados"),

    ("SECCION", "CONDENSADO CON ANILLO  (solo si aplica)", None, None, None),
    ("Espesor_anillo_m", "Espesor del anillo de petróleo", "", "N2", "m"),
    ("m_casquete", "Relación casquete/anillo (m)", "", "N2", "V_gas / V_petróleo"),
    ("CGO_m", "Contacto gas-petróleo", "", "N2", "m bajo nivel del mar"),
    ("CAO_m", "Contacto agua-petróleo", "", "N2", "m bajo nivel del mar"),

    ("SECCION", "EJECUTABILIDAD  (lo que frena proyectos)", None, None, None),
    ("Fuente_agua", "Fuente de agua identificada", "", "N3",
     "Sí / No / Parcial. Killing factor K4."),
    ("Caudal_agua_disp", "Caudal de agua disponible", "", "N3", "bpd"),
    ("Pozos_total", "Pozos perforados", "", "N1", "cantidad"),
    ("Pozos_activos", "Pozos activos", "", "N1", "cantidad"),
    ("Pozos_convertibles", "Pozos convertibles a inyectores", "", "N3", "cantidad"),
    ("Integridad_ok_pct", "Pozos con integridad verificada", "", "N3", "%"),
    ("Infraestructura", "Infraestructura de superficie", "", "N3",
     "Completa / Parcial / Inexistente"),
    ("Restriccion_amb", "Restricción ambiental o social", "", "N3",
     "Ninguna / Permisos pendientes / Área protegida / Conflicto activo"),
]


def hoja_estaticos(wb):
    ws = wb.create_sheet("Carga_Estáticos")
    anchos(ws, {"A": 34, "B": 8, "C": 15, "D": 15, "E": 15, "F": 15, "G": 15,
                "H": 15, "I": 15, "J": 15, "K": 15, "L": 15, "M": 52})
    ancho_tot = 2 + MAX_RES + 1
    f = titulo(ws, 1, "DATOS ESTÁTICOS POR RESERVORIO", ancho_tot)
    f = nota(ws, f,
             "Un reservorio por columna. Dejar VACÍO lo que no se sepa: la herramienta "
             "distingue 'sin dato' de 'cero' y lo reporta en la hoja Completitud.")

    ws.cell(f, 1, "Parámetro").font = F_CAB
    ws.cell(f, 1).fill = R_CAB
    ws.cell(f, 2, "Nivel").font = F_CAB
    ws.cell(f, 2).fill = R_CAB
    for j in range(MAX_RES):
        c = ws.cell(f, EST_C0 + j)
        c.font = F_CAB
        c.fill = R_IN
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center")
    ws.cell(f, EST_C0 + MAX_RES, "Comentario / fuente del dato").font = F_CAB
    ws.cell(f, EST_C0 + MAX_RES).fill = R_CAB
    fila_cab = f
    f += 1

    filas_param = {}
    for nombre, etiqueta, _v, nivel, desc in ESTATICOS:
        if nombre == "SECCION":
            f = subtitulo(ws, f, etiqueta, ancho_tot)
            continue
        ws.cell(f, 1, etiqueta).font = F_CAB
        n = ws.cell(f, 2, nivel)
        n.alignment = Alignment(horizontal="center")
        n.font = Font(size=9, bold=True,
                      color={"N1": "1F7A1F", "N2": "B8860B", "N3": "9C3A3A"}[nivel])
        for j in range(MAX_RES):
            celda_entrada(ws, f, EST_C0 + j)
        d = ws.cell(f, EST_C0 + MAX_RES, desc)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        filas_param[nombre] = f
        f += 1

    ws.freeze_panes = "C4"
    nombrar(wb, "Est_Cabecera", "Carga_Estáticos",
            f"$C${fila_cab}:${CL(EST_C0 + MAX_RES - 1)}${fila_cab}")
    return ws, filas_param, fila_cab


def ref_estatico(filas_param, nombre):
    """INDEX/MATCH sobre la fila del parámetro, columna del reservorio activo."""
    fila = filas_param[nombre]
    c0, c1 = CL(EST_C0), CL(EST_C0 + MAX_RES - 1)
    return (f"INDEX('Carga_Estáticos'!${c0}${fila}:${c1}${fila},"
            f"MATCH(Reservorio_Sel,Est_Cabecera,0))")


# ===========================================================================
# Hoja Cálculos
# ===========================================================================
COLS_CALC = [
    ("Pozo", 14), ("Reservorio", 20), ("Fecha", 12), ("Mes_Clave", 10),
    ("Dias", 9), ("Vol_o_bbl", 13), ("Vol_w_bbl", 13), ("Vol_g_Mpc", 13),
    ("Vol_iny_bbl", 13), ("Orden_OK", 11), ("Np_pozo_Mbbl", 13),
    ("Wp_pozo_Mbbl", 13), ("WOR_fila", 11), ("Clave_Sel", 11),
]


def hoja_calculos(wb):
    ws = wb.create_sheet("Cálculos")
    f = titulo(ws, 1, "CÁLCULOS POR FILA — hoja calculada, no editar", len(COLS_CALC))
    _ = f
    for i, (h, w) in enumerate(COLS_CALC, start=1):
        c = ws.cell(2, i, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        ws.column_dimensions[CL(i)].width = w

    P = "'Carga_Producción'"
    for r in range(3, 3 + MAX_FILAS):
        pr = r - 1                          # fila equivalente en Carga_Producción
        vacia = f'{P}!$A{pr}=""'
        ws.cell(r, 1, f'=IF({vacia},"",{P}!$A{pr})')
        ws.cell(r, 2, f'=IF({vacia},"",{P}!$B{pr})')
        c = ws.cell(r, 3, f'=IF({vacia},"",{P}!$C{pr})')
        c.number_format = "DD/MM/YYYY"
        # Clave de mes: año*12+mes. Robusta ante fechas que no sean día 1.
        ws.cell(r, 4, f'=IF({vacia},"",YEAR({P}!$C{pr})*12+MONTH({P}!$C{pr}))')
        # Días: si no se cargó, se asume el promedio mensual
        ws.cell(r, 5, f'=IF({vacia},"",IF({P}!$D{pr}="",Dias_Mes,{P}!$D{pr}))')
        for col, src in ((6, "E"), (7, "F"), (9, "J")):
            ws.cell(r, col,
                    f'=IF({vacia},"",IF({P}!${src}{pr}="","",{P}!${src}{pr}*$E{r}))'
                    ).number_format = "#,##0"
        ws.cell(r, 8, f'=IF({vacia},"",IF({P}!$G{pr}="","",{P}!$G{pr}*$E{r}))'
                ).number_format = "#,##0"
        # Orden: el pozo no puede retroceder alfabéticamente y, dentro del pozo,
        # la fecha no puede retroceder. Es la condición que la suma corrida asume.
        if r == 3:
            ws.cell(r, 10, '=IF($A3="","","OK")')
        else:
            ws.cell(r, 10,
                    f'=IF($A{r}="","",IF($A{r}<$A{r-1},"ORDEN",'
                    f'IF(AND($A{r}=$A{r-1},$C{r}<=$C{r-1}),"ORDEN","OK")))')
        # Acumulados por pozo: suma corrida, O(n). Se reinicia al cambiar de pozo.
        if r == 3:
            ws.cell(r, 11, '=IF($A3="","",$F3/1000)').number_format = "#,##0.0"
            ws.cell(r, 12, '=IF($A3="","",$G3/1000)').number_format = "#,##0.0"
        else:
            for col, vol in ((11, "F"), (12, "G")):
                ws.cell(r, col,
                        f'=IF($A{r}="","",IF($A{r}=$A{r-1},${CL(col)}{r-1},0)'
                        f'+IF(${vol}{r}="",0,${vol}{r}/1000))'
                        ).number_format = "#,##0.0"
        ws.cell(r, 13,
                f'=IF($A{r}="","",IF(N({P}!$E{pr})>0,{P}!$F{pr}/{P}!$E{pr},""))'
                ).number_format = "0.000"
        # Clave de mes SOLO para el reservorio activo. Existe para que la hoja
        # Serie pueda hallar el primer mes con un MIN común, sin MINIFS (que no
        # está en Excel 2016 perpetuo) ni fórmula matricial.
        ws.cell(r, 14, f'=IF($B{r}="","",IF($B{r}=Reservorio_Sel,$D{r},""))')

    ws.freeze_panes = "A3"
    nombrar(wb, "Calc_Reservorio", "Cálculos", f"$B$3:$B${2 + MAX_FILAS}")
    nombrar(wb, "Calc_MesClave", "Cálculos", f"$D$3:$D${2 + MAX_FILAS}")
    nombrar(wb, "Calc_VolO", "Cálculos", f"$F$3:$F${2 + MAX_FILAS}")
    nombrar(wb, "Calc_VolW", "Cálculos", f"$G$3:$G${2 + MAX_FILAS}")
    nombrar(wb, "Calc_VolG", "Cálculos", f"$H$3:$H${2 + MAX_FILAS}")
    nombrar(wb, "Calc_VolIny", "Cálculos", f"$I$3:$I${2 + MAX_FILAS}")
    nombrar(wb, "Calc_Orden", "Cálculos", f"$J$3:$J${2 + MAX_FILAS}")
    nombrar(wb, "Calc_ClaveSel", "Cálculos", f"$N$3:$N${2 + MAX_FILAS}")
    proteger(ws)
    return ws


# ===========================================================================
# Hoja Serie — agregado mensual del reservorio activo
# ===========================================================================
COLS_SERIE = [
    ("i", 6, "0"), ("Mes_Clave", 10, "0"), ("Fecha", 12, "MMM-YYYY"),
    ("t_años", 9, "0.00"),
    ("Vol_o_bbl", 12, "#,##0"), ("Vol_w_bbl", 12, "#,##0"),
    ("Vol_g_Mpc", 12, "#,##0"), ("Vol_iny_bbl", 12, "#,##0"),
    ("Qo_bpd", 11, "#,##0.0"), ("Qw_bpd", 11, "#,##0.0"),
    ("Qg_Mpcd", 11, "#,##0.0"), ("Qiny_bpd", 11, "#,##0.0"),
    ("Np_Mbbl", 12, "#,##0.0"), ("Wp_Mbbl", 12, "#,##0.0"),
    ("Gp_MMpc", 12, "#,##0.0"), ("Wi_Mbbl", 12, "#,##0.0"),
    ("WOR", 10, "0.000"), ("fw", 9, "0.0%"), ("GOR_pc_bbl", 12, "#,##0"),
    ("WOR_deriv", 11, "0.0000"), ("Pres_psi", 10, "#,##0"), ("p_sobre_z", 11, "#,##0"),
    ("Activo", 8, "0"), ("Flag_Ajuste", 10, "0"), ("Qo_Safe", 11, "0.000"),
    ("Flag_Chan", 10, "0"), ("ln_t", 10, "0.000"), ("ln_WOR", 10, "0.000"),
    ("ln_WORd", 10, "0.000"), ("Flag_pz", 9, "0"), ("Flag_WORNp", 10, "0"),
    ("ln_WOR_Np", 10, "0.000"),
    # --- Inyección y productividad (se agregan al final para no correr las
    #     letras de columna de las anteriores) ---
    ("Piny_psi", 10, "#,##0"), ("Hall_acum", 14, "#,##0"),
    ("Flag_Hall", 10, "0"), ("IP_aparente", 12, "0.000"),
    ("Flag_Hall_Rec", 11, "0"), ("Flag_IP", 9, "0"),
    # --- Columnas que existen SOLO para los gráficos --------------------
    # Son las mismas magnitudes de más arriba pero vacías fuera del período
    # con historia, en vez de en 0 o arrastrando el último valor. Ver la nota
    # de abajo sobre por qué hacen falta duplicadas.
    ("t_graf", 9, "0.00"), ("pz_graf", 11, "#,##0"),
    ("Hall_graf", 14, "#,##0"),
]
# Regla que gobierna estas columnas: toda columna que participe de un SUMPRODUCT
# devuelve 0 —nunca cadena vacía— cuando no aplica. SUMPRODUCT propaga #¡VALOR!
# ante texto, y el indicador 0/1 ya se encarga de anular el término.
#
# Esa regla es correcta para el cálculo y desastrosa para los gráficos: una
# columna que sigue devolviendo 0 —o el último acumulado— durante los 30 años
# posteriores al fin de la historia dibuja una cola plana que se lee como si el
# campo hubiera seguido produciendo, y estira el eje X hasta los 50 años,
# comprimiendo la historia real contra el margen izquierdo. De ahí las columnas
# `*_graf`: mismas magnitudes, vacías donde no hay dato. Un punto sin X o sin Y
# no se dibuja, que es exactamente lo que se busca.
# índices de columna (1-based) por nombre
SC = {h: i for i, (h, _, _) in enumerate(COLS_SERIE, start=1)}


def hoja_serie(wb):
    ws = wb.create_sheet("Serie")
    f = titulo(ws, 1, "SERIE MENSUAL DEL RESERVORIO ACTIVO — hoja calculada",
               len(COLS_SERIE))
    nota(ws, f, "Se recalcula íntegra al cambiar Reservorio_Sel en la hoja Config.")

    for i, (h, w, fmt) in enumerate(COLS_SERIE, start=1):
        c = ws.cell(3, i, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[CL(i)].width = w

    L = {h: CL(i) for h, i in SC.items()}
    for r in range(SER0, SER1 + 1):
        i = r - SER0
        ws.cell(r, SC["i"], i)
        # Primer mes con producción del reservorio activo. Se usa MIN sobre la
        # columna auxiliar Clave_Sel de Cálculos en vez de MINIFS, que no existe
        # en Excel 2016 perpetuo.
        ws.cell(r, SC["Mes_Clave"],
                f'=IF(COUNT(Calc_ClaveSel)=0,"",MIN(Calc_ClaveSel)+{i})')
        clave = f'${L["Mes_Clave"]}{r}'
        ws.cell(r, SC["Fecha"],
                f'=IF({clave}="","",DATE(INT(({clave}-1)/12),MOD({clave}-1,12)+1,1))'
                ).number_format = "MMM-YYYY"
        # t siempre numérico, incluso fuera del período con datos: participa de
        # los SUMPRODUCT del ajuste y una cadena vacía los rompería.
        ws.cell(r, SC["t_años"], f"={i}/12")

        for nom, rng in (("Vol_o_bbl", "Calc_VolO"), ("Vol_w_bbl", "Calc_VolW"),
                         ("Vol_g_Mpc", "Calc_VolG"), ("Vol_iny_bbl", "Calc_VolIny")):
            ws.cell(r, SC[nom],
                    f'=IF({clave}="","",SUMIFS({rng},Calc_Reservorio,Reservorio_Sel,'
                    f'Calc_MesClave,{clave}))')

        for q, v in (("Qo_bpd", "Vol_o_bbl"), ("Qw_bpd", "Vol_w_bbl"),
                     ("Qg_Mpcd", "Vol_g_Mpc"), ("Qiny_bpd", "Vol_iny_bbl")):
            ws.cell(r, SC[q], f'=IF({clave}="","",${L[v]}{r}/Dias_Mes)')

        for ac, v, div in (("Np_Mbbl", "Vol_o_bbl", 1000), ("Wp_Mbbl", "Vol_w_bbl", 1000),
                           ("Gp_MMpc", "Vol_g_Mpc", 1000), ("Wi_Mbbl", "Vol_iny_bbl", 1000)):
            prev = f'${L[ac]}{r-1}' if r > SER0 else "0"
            ws.cell(r, SC[ac], f'=IF({clave}="","",{prev}+${L[v]}{r}/{div})')

        qo, qw, qg = f'${L["Qo_bpd"]}{r}', f'${L["Qw_bpd"]}{r}', f'${L["Qg_Mpcd"]}{r}'
        ws.cell(r, SC["WOR"], f'=IF({clave}="","",IF({qo}>0,{qw}/{qo},""))')
        ws.cell(r, SC["fw"],
                f'=IF({clave}="","",IF(({qo}+{qw})>0,{qw}/({qo}+{qw}),""))')
        ws.cell(r, SC["GOR_pc_bbl"], f'=IF({clave}="","",IF({qo}>0,{qg}*1000/{qo},""))')

        # Derivada centrada de WOR sobre ventana +/- Chan_Ventana meses.
        wor_rng = f'Serie_WOR'
        ws.cell(r, SC["WOR_deriv"],
                f'=IFERROR(IF(OR({i}-Chan_Ventana<0,{i}+Chan_Ventana>{MESES - 1}),"",'
                f'IF(OR(NOT(ISNUMBER(INDEX({wor_rng},{i}+Chan_Ventana+1))),'
                f'NOT(ISNUMBER(INDEX({wor_rng},{i}-Chan_Ventana+1)))),"",'
                f'(INDEX({wor_rng},{i}+Chan_Ventana+1)-INDEX({wor_rng},{i}-Chan_Ventana+1))'
                f'/(2*Chan_Ventana/12))),"")')

        ws.cell(r, SC["Pres_psi"],
                f'=IF({clave}="","",IFERROR(AVERAGEIFS(\'Carga_Producción\'!'
                f'$H${FIL0}:$H${FIL1},Prod_Reservorio,Reservorio_Sel,'
                f'Prod_Fecha,">="&DATE(INT(({clave}-1)/12),MOD({clave}-1,12)+1,1),'
                f'Prod_Fecha,"<"&DATE(INT(({clave}-1)/12),MOD({clave}-1,12)+2,1)),""))')
        ws.cell(r, SC["p_sobre_z"],
                f'=IF(N(${L["Pres_psi"]}{r})>0,${L["Pres_psi"]}{r}/Z_Gas,0)')

        ws.cell(r, SC["Activo"],
                f'=IF({clave}="",0,IF(OR(N(${L["Vol_o_bbl"]}{r})>0,'
                f'N(${L["Vol_w_bbl"]}{r})>0,N(${L["Vol_g_Mpc"]}{r})>0),1,0))')
        act = f'${L["Activo"]}{r}'
        ws.cell(r, SC["Flag_Ajuste"],
                f'=IF(AND({act}=1,N({qo})>0,{i}>=Ajuste_Mes_Inicio,'
                f'{i}<=Ajuste_Mes_Fin),1,0)')
        # Qo_Safe = 1 cuando la fila no entra al ajuste, para que Qo^(-b) nunca
        # devuelva error dentro de un SUMPRODUCT. El indicador la anula igual.
        ws.cell(r, SC["Qo_Safe"],
                f'=IF(${L["Flag_Ajuste"]}{r}=1,{qo},1)')

        wor = f'${L["WOR"]}{r}'
        wd = f'${L["WOR_deriv"]}{r}'
        ws.cell(r, SC["Flag_Chan"],
                f'=IF(AND({act}=1,{i}>0,ISNUMBER({wor}),N({wor})>Chan_WOR_Min,'
                f'ISNUMBER({wd}),N({wd})>0),1,0)')
        fc = f'${L["Flag_Chan"]}{r}'
        ws.cell(r, SC["ln_t"], f'=IF({fc}=1,LN({i}/12),0)')
        ws.cell(r, SC["ln_WOR"], f'=IF({fc}=1,LN({wor}),0)')
        ws.cell(r, SC["ln_WORd"], f'=IF({fc}=1,LN({wd}),0)')
        ws.cell(r, SC["Flag_pz"],
                f'=IF(AND({act}=1,N(${L["p_sobre_z"]}{r})>0),1,0)')
        ws.cell(r, SC["Flag_WORNp"],
                f'=IF(AND({act}=1,ISNUMBER({wor}),N({wor})>Chan_WOR_Min),1,0)')
        # ln(WOR) con su propio indicador: la extrapolación WOR vs Np no exige
        # derivada positiva, a diferencia del clasificador de Chan.
        ws.cell(r, SC["ln_WOR_Np"],
                f'=IF(${L["Flag_WORNp"]}{r}=1,LN({wor}),0)')

        # --- Inyección: presión y gráfico de Hall -------------------------
        ws.cell(r, SC["Piny_psi"],
                f'=IF({clave}="",0,IFERROR(AVERAGEIFS(\'Carga_Producción\'!'
                f'$K${FIL0}:$K${FIL1},Prod_Reservorio,Reservorio_Sel,'
                f'Prod_Fecha,">="&DATE(INT(({clave}-1)/12),MOD({clave}-1,12)+1,1),'
                f'Prod_Fecha,"<"&DATE(INT(({clave}-1)/12),MOD({clave}-1,12)+2,1)),0))')
        piny = f'${L["Piny_psi"]}{r}'
        # Integral de Hall: suma de (P_inyección - P_reservorio) x tiempo.
        # Se usa la presión inicial como referencia de reservorio porque es el
        # único valor disponible en el screening. Eso desplaza la recta pero NO
        # cambia su pendiente ni sus quiebres, que es lo que el gráfico
        # diagnostica.
        prev_h = f'${L["Hall_acum"]}{r-1}' if r > SER0 else "0"
        ws.cell(r, SC["Hall_acum"],
                f'=IF({clave}="","",{prev_h}+IF(AND(ISNUMBER(Act_Pipsi),'
                f'{piny}>0,${L["Vol_iny_bbl"]}{r}>0),'
                f'MAX(0,{piny}-Act_Pipsi)*Dias_Mes,0))')
        ws.cell(r, SC["Flag_Hall"],
                f'=IF(AND({piny}>0,N(${L["Vol_iny_bbl"]}{r})>0,'
                f'N(${L["Hall_acum"]}{r})>0),1,0)')
        ws.cell(r, SC["Flag_Hall_Rec"],
                f'=IF(AND(${L["Flag_Hall"]}{r}=1,{i}>=Serie_UltHall-24),1,0)')

        # Índice de productividad APARENTE: se usa la presión inicial como
        # referencia porque la presión de reservorio del mes rara vez existe.
        # El valor absoluto no significa nada; lo que informa es su TENDENCIA:
        # si cae sostenidamente hay daño creciente o agotamiento.
        ws.cell(r, SC["IP_aparente"],
                f'=IF({clave}="","",IF(AND(ISNUMBER(Act_Pipsi),'
                f'N(${L["Pres_psi"]}{r})>0,Act_Pipsi>${L["Pres_psi"]}{r}),'
                f'({qo}+{qw})/(Act_Pipsi-${L["Pres_psi"]}{r}),""))')
        # Indicador numérico para poder tomar el primer y el último IP con
        # MATCH y LOOKUP, sin recurrir a fórmulas matriciales.
        ws.cell(r, SC["Flag_IP"],
                f'=IF(AND({act}=1,ISNUMBER(${L["IP_aparente"]}{r}),'
                f'N(${L["IP_aparente"]}{r})>0),1,0)')

        # --- Columnas de graficado ----------------------------------------
        # Cada una reusa el indicador que ya decide si la fila tiene dato, para
        # que no haya dos criterios de "acá hay historia" que puedan divergir.
        ws.cell(r, SC["t_graf"], f'=IF({act}=1,${L["t_años"]}{r},"")')
        ws.cell(r, SC["pz_graf"],
                f'=IF(${L["Flag_pz"]}{r}=1,${L["p_sobre_z"]}{r},"")')
        ws.cell(r, SC["Hall_graf"],
                f'=IF(${L["Flag_Hall"]}{r}=1,${L["Hall_acum"]}{r},"")')

        for i_c, (h, _w, fmt) in enumerate(COLS_SERIE, start=1):
            if fmt:
                ws.cell(r, i_c).number_format = fmt

    # Último mes con inyección, para acotar la ventana "reciente" del gráfico
    # de Hall. Vive en una celda auxiliar y no dentro de cada fila para no
    # repetir 600 veces la misma búsqueda.
    col_aux = len(COLS_SERIE) + 2
    ws.cell(2, col_aux - 1, "Último mes con inyección:").font = F_NOTA
    ws.cell(2, col_aux,
            '=IFERROR(LOOKUP(2,1/(Serie_FlagHall=1),Serie_i),-999)'
            ).number_format = "0"
    nombrar(wb, "Serie_UltHall", "Serie", f"${CL(col_aux)}$2")

    ws.freeze_panes = "E4"
    for h, _w, _f in COLS_SERIE:
        nombrar(wb, sr(h), "Serie", f"${L[h]}${SER0}:${L[h]}${SER1}")
    proteger(ws)
    return ws


def sr(nombre):
    """Rango con nombre de una columna de Serie, saneado de acentos."""
    return f"Serie_{limpiar_nombre(nombre)}"


# ===========================================================================
# Hoja Grilla_b — barrido del exponente de Arps
# ===========================================================================
GB_FILA = {"b": 3, "n": 4, "pend": 5, "inter": 6, "qi": 7, "Di": 8,
           "SSE": 9, "SST": 10, "R2": 11}
GB_C0 = 3                                  # primera columna de b (C)
GB_C1 = GB_C0 + len(BS) - 1


def hoja_grilla_b(wb):
    """
    Ajuste de Arps por barrido de b, sin Solver.

    Para cada b la curva se linealiza y se resuelve por mínimos cuadrados; luego
    el R2 se evalúa sobre la escala ORIGINAL de q, no sobre la transformada.
    Comparar R2 entre distintos b sobre escalas transformadas distintas no es
    comparar lo mismo y sesga la selección hacia b altos.

    La grilla no necesita columnas de datos: SUMPRODUCT eleva el rango a la
    potencia en línea, así que todo el barrido cabe en 21 columnas por 9 filas.
    """
    ws = wb.create_sheet("Grilla_b")
    anchos(ws, {"A": 30, "B": 12})
    titulo(ws, 1, "BARRIDO DEL EXPONENTE DE ARPS — hoja calculada", GB_C1)

    etiquetas = {
        "b": "b (exponente)", "n": "n (meses en el ajuste)",
        "pend": "pendiente linealizada", "inter": "intercepto linealizado",
        "qi": "qi (bpd)", "Di": "Di (1/año)", "SSE": "SSE (escala original)",
        "SST": "SST", "R2": "R² (escala original)",
    }
    for k, f in GB_FILA.items():
        c = ws.cell(f, 1, etiquetas[k])
        c.font = F_CAB
        c.fill = R_CAB

    flag, x, q = "Serie_FlagAjuste", "Serie_tanos", "Serie_QoSafe"

    for j, b in enumerate(BS):
        col = GB_C0 + j
        CLc = CL(col)
        ws.column_dimensions[CLc].width = 13
        ws.cell(GB_FILA["b"], col, b).number_format = "0.00"
        ws.cell(GB_FILA["n"], col, f"=SUMPRODUCT({flag})")

        y = f"LN({q})" if b == 0 else f"{q}^({-b})"
        pend, inter = regresion_sumproduct(flag, x, y)
        ws.cell(GB_FILA["pend"], col, f"={pend}").number_format = "0.000000"
        ws.cell(GB_FILA["inter"], col, f"={inter}").number_format = "0.000000"

        p = f"{CLc}${GB_FILA['pend']}"
        it = f"{CLc}${GB_FILA['inter']}"
        qi = f"{CLc}${GB_FILA['qi']}"
        di = f"{CLc}${GB_FILA['Di']}"

        if b == 0:
            ws.cell(GB_FILA["qi"], col, f"=IFERROR(EXP({it}),\"\")")
            ws.cell(GB_FILA["Di"], col, f"=IFERROR(-{p},\"\")")
            qhat = f"{qi}*EXP(-{di}*{x})"
        else:
            ws.cell(GB_FILA["qi"], col, f"=IFERROR({it}^(-1/{b}),\"\")")
            ws.cell(GB_FILA["Di"], col, f"=IFERROR({p}/({it}*{b}),\"\")")
            qhat = f"{qi}/(1+{b}*{di}*{x})^(1/{b})"

        ws.cell(GB_FILA["qi"], col).number_format = "#,##0.0"
        ws.cell(GB_FILA["Di"], col).number_format = "0.0000"
        ws.cell(GB_FILA["SSE"], col,
                f"=IFERROR(SUMPRODUCT({flag},({q}-{qhat})^2),\"\")")
        ws.cell(GB_FILA["SST"], col,
                f"=IFERROR(SUMPRODUCT({flag},({q}-SUMPRODUCT({flag},{q})"
                f"/SUMPRODUCT({flag}))^2),\"\")")
        ws.cell(GB_FILA["R2"], col,
                f"=IFERROR(IF({CLc}${GB_FILA['SST']}<=0,\"\","
                f"1-{CLc}${GB_FILA['SSE']}/{CLc}${GB_FILA['SST']}),\"\")"
                ).number_format = "0.0000"

    c0, c1 = CL(GB_C0), CL(GB_C1)
    fr2, fb = GB_FILA["R2"], GB_FILA["b"]
    rng_r2 = f"${c0}${fr2}:${c1}${fr2}"
    match = f"MATCH(MAX({rng_r2}),{rng_r2},0)"

    f = 13
    f = subtitulo(ws, f, "MEJOR AJUSTE", GB_C1)
    salidas = [
        ("Fit_R2", "R² del mejor ajuste", f"=IFERROR(MAX({rng_r2}),\"\")", "0.0000"),
        ("Fit_b", "b óptimo",
         f"=IFERROR(INDEX(${c0}${fb}:${c1}${fb},{match}),\"\")", "0.00"),
        ("Fit_qi", "qi (bpd)",
         f"=IFERROR(INDEX(${c0}${GB_FILA['qi']}:${c1}${GB_FILA['qi']},{match}),\"\")",
         "#,##0.0"),
        ("Fit_Di", "Di (1/año)",
         f"=IFERROR(INDEX(${c0}${GB_FILA['Di']}:${c1}${GB_FILA['Di']},{match}),\"\")",
         "0.0000"),
        ("Fit_N", "meses usados", f"=SUMPRODUCT({flag})", "0"),
    ]
    for nombre, etiqueta, formula, fmt in salidas:
        ws.cell(f, 1, etiqueta).font = F_CAB
        c = ws.cell(f, 2, formula)
        c.number_format = fmt
        c.fill = R_CAB
        nombrar(wb, nombre, "Grilla_b", f"$B${f}")
        f += 1

    f += 1
    nota(ws, f, "El paso de la grilla es 0,05. Para afinar, agregar columnas "
                "replicando el patrón y extender los rangos de MAX y MATCH.")
    proteger(ws)
    return ws


# ===========================================================================
# Hoja Diagnóstico
# ===========================================================================
# Último valor de una columna restringido a los meses activos.
# LOOKUP(2,1/(cond),rango) es el modismo clásico de "último que cumple": no
# requiere Ctrl+Shift+Enter y funciona igual en toda versión de Excel.
def ultimo(col_valores, cond="Serie_Activo=1"):
    return f'IFERROR(LOOKUP(2,1/({cond}),{col_valores}),"")'


def hoja_diagnostico(wb, filas_param):
    ws = wb.create_sheet("Diagnóstico")
    anchos(ws, {"A": 40, "B": 16, "C": 12, "D": 70})
    f = titulo(ws, 1, "DIAGNÓSTICO DEL RESERVORIO ACTIVO", 4)
    f = nota(ws, f, "Hoja calculada. Cambiar Reservorio_Sel en Config recalcula todo.")
    f += 1

    def fila(etiqueta, formula, fmt=None, nombre=None, comentario="", f_=None):
        nonlocal f
        r = f_ or f
        ws.cell(r, 1, etiqueta).font = F_CAB
        c = ws.cell(r, 2, formula)
        if fmt:
            c.number_format = fmt
        c.fill = R_CAB
        c.border = BORDE_FINO
        if comentario:
            d = ws.cell(r, 4, comentario)
            d.font = F_NOTA
            d.alignment = Alignment(wrap_text=True, vertical="top")
            if len(comentario) > 88:
                ws.row_dimensions[r].height = 42
        if nombre:
            nombrar(wb, nombre, "Diagnóstico", f"$B${r}")
        f = r + 1
        return r

    # ---------------- Identificación ----------------
    f = subtitulo(ws, f, "IDENTIFICACIÓN", 4)
    fila("Campo", "=Campo_Nombre")
    fila("Reservorio", "=Reservorio_Sel")
    fila("Meses con actividad", "=SUMPRODUCT(Serie_Activo)", "0", "Diag_MesesAct")
    fila("Primer mes con datos", f"=IFERROR(INDEX(Serie_Fecha,MATCH(1,Serie_Activo,0)),\"\")",
         "MMM-YYYY")
    fila("Último mes con datos", f"={ultimo('Serie_Fecha')}", "MMM-YYYY")
    fila("Pozos con datos en el campo",
         '=SUMPRODUCT((Calc_Reservorio=Reservorio_Sel)*1)/MAX(1,SUMPRODUCT(Serie_Activo))',
         "0.0", None,
         "Aproximación: filas del reservorio dividido meses activos. Sirve como "
         "orden de magnitud del número de pozos, no como conteo exacto.")
    fila("Filas fuera de orden",
         '=COUNTIF(Calc_Orden,"ORDEN")', "0", "Diag_Desorden",
         "Debe ser 0. Si no lo es, los acumulados por pozo son incorrectos: "
         "ordenar Carga_Producción por Pozo y luego por Fecha.")
    f += 1

    # ---------------- Datos del reservorio activo ----------------
    f = subtitulo(ws, f, "DATOS DEL RESERVORIO ACTIVO (desde Carga_Estáticos)", 4)
    ws.cell(f - 1, 4, "Vacío = dato no disponible. Se propaga como tal, no se rellena."
            ).font = F_NOTA
    for nombre in filas_param:
        etiqueta = next(e for n, e, _v, _n, _d in ESTATICOS if n == nombre)
        fila(etiqueta, f"=IFERROR({ref_estatico(filas_param, nombre)},\"\")",
             None, f"Act_{limpiar_nombre(nombre)}")
    f += 1

    # ---------------- Producción acumulada ----------------
    f = subtitulo(ws, f, "PRODUCCIÓN ACUMULADA", 4)
    fila("Np — petróleo (Mbbl)", "=IFERROR(MAX(Serie_NpMbbl),\"\")", "#,##0.0", "Diag_Np")
    fila("Wp — agua (Mbbl)", "=IFERROR(MAX(Serie_WpMbbl),\"\")", "#,##0.0", "Diag_Wp")
    fila("Gp — gas (MMpc)", "=IFERROR(MAX(Serie_GpMMpc),\"\")", "#,##0.0", "Diag_Gp")
    fila("Wi — agua inyectada (Mbbl)", "=IFERROR(MAX(Serie_WiMbbl),\"\")", "#,##0.0",
         "Diag_Wi")
    fila("Último Qo (bpd)", f"={ultimo('Serie_Qobpd')}", "#,##0.0", "Diag_QoUlt")
    fila("Último Qw (bpd)", f"={ultimo('Serie_Qwbpd')}", "#,##0.0")
    fila("Último WOR", f"={ultimo('Serie_WOR')}", "0.00", "Diag_WORUlt")
    fila("Último corte de agua", f"={ultimo('Serie_fw')}", "0.0%", "Diag_fwUlt")
    fila("Último GOR (pc/bbl)", f"={ultimo('Serie_GORpcbbl')}", "#,##0", "Diag_GORUlt")
    f += 1

    # ---------------- Declinación ----------------
    f = subtitulo(ws, f, "DECLINACIÓN DE ARPS", 4)
    fila("b óptimo", "=Fit_b", "0.00", None,
         "0 = exponencial. Valores altos indican empuje sostenido o mezcla de "
         "mecanismos; revisar la ventana de ajuste en Config.")
    fila("Di (1/año)", "=Fit_Di", "0.0000")
    fila("qi del ajuste (bpd)", "=Fit_qi", "#,##0.0")
    fila("R² del ajuste", "=Fit_R2", "0.0000", None,
         "Por debajo de 0,85 el ajuste no es confiable: acotar la ventana.")
    fila("Meses usados en el ajuste", "=Fit_N", "0")
    # EUR por Arps, según el valor de b
    eur = ('=IFERROR(IF(OR(Fit_qi<=Limite_Economico,Fit_Di<=0),"",'
           'IF(Fit_b<0.025,(Fit_qi-Limite_Economico)/Fit_Di,'
           'IF(ABS(Fit_b-1)<0.025,Fit_qi/Fit_Di*LN(Fit_qi/Limite_Economico),'
           'Fit_qi/((1-Fit_b)*Fit_Di)*(1-(Limite_Economico/Fit_qi)^(1-Fit_b))))'
           '*365.25/1000),"")')
    fila("EUR primaria (Mbbl)", eur, "#,##0.0", "Diag_EUR",
         "Integral de la curva de Arps hasta el límite económico. Los tres casos "
         "(b=0, b=1, resto) tienen soluciones cerradas distintas.")
    fila("Reservas remanentes (Mbbl)",
         '=IFERROR(MAX(0,Diag_EUR-Diag_Np),"")', "#,##0.0", "Diag_Rem")
    tlim = ('=IFERROR(IF(OR(Fit_qi<=Limite_Economico,Fit_Di<=0),"",'
            'IF(Fit_b<0.025,LN(Fit_qi/Limite_Economico)/Fit_Di,'
            '((Fit_qi/Limite_Economico)^Fit_b-1)/(Fit_b*Fit_Di))),"")')
    fila("Años hasta el límite económico", tlim, "#,##0.0")
    f += 1

    # ---------------- Chan ----------------
    f = subtitulo(ws, f, "DIAGNÓSTICO DE AGUA — CHAN (SPE 30775)", 4)
    pend_w, _ = regresion_sumproduct("Serie_FlagChan", "Serie_lnt", "Serie_lnWOR")
    pend_d, _ = regresion_sumproduct("Serie_FlagChan", "Serie_lnt", "Serie_lnWORd")
    fila("Puntos válidos", "=SUMPRODUCT(Serie_FlagChan)", "0", "Diag_ChanN")
    fila("Pendiente log-log de WOR", f"={pend_w}", "0.000", "Diag_PendWOR")
    fila("Pendiente log-log de WOR'", f"={pend_d}", "0.000", "Diag_PendWORd",
         "Es el discriminante. Si WOR ~ t^m entonces WOR' ~ t^(m-1): m=1 da 0, "
         "canalización da positivo, y la conificación real da muy negativo "
         "porque el WOR asintota.")
    clas = ('=IF(SUMPRODUCT(Serie_FlagWORNp)=0,"SIN AGUA",'
            'IF(Diag_ChanN<Chan_Min_Puntos,"INDETERMINADO",'
            'IF(NOT(ISNUMBER(Diag_PendWORd)),"INDETERMINADO",'
            'IF(Diag_PendWORd>=Chan_Pend_Canal,"CANALIZACION",'
            'IF(Diag_PendWORd<=Chan_Pend_Conif,"CONIFICACION",'
            '"DESPLAZAMIENTO NORMAL")))))')
    r_clas = fila("Clasificación", clas, None, "Diag_Chan")
    ws.cell(r_clas, 2).font = Font(bold=True)
    for texto, color in (("CANALIZACION", ROJO), ("CONIFICACION", AMARILLO),
                         ("DESPLAZAMIENTO NORMAL", VERDE), ("SIN AGUA", VERDE)):
        ws.conditional_formatting.add(
            f"B{r_clas}", CellIsRule(operator="equal", formula=[f'"{texto}"'],
                                     fill=PatternFill("solid", fgColor=color)))
    f += 1

    # ---------------- WOR vs Np ----------------
    f = subtitulo(ws, f, "EXTRAPOLACIÓN WOR vs Np", 4)
    pw, iw = regresion_sumproduct("Serie_FlagWORNp", "Serie_NpMbbl", "Serie_lnWORNp")
    fila("Pendiente de ln(WOR) vs Np", f"={pw}", "0.000000", "Diag_WNpPend")
    fila("Intercepto", f"={iw}", "0.0000", "Diag_WNpInter")
    fila("Np al WOR económico (Mbbl)",
         '=IFERROR(IF(Diag_WNpPend<=0,"",(LN(WOR_Economico)-Diag_WNpInter)'
         '/Diag_WNpPend),"")', "#,##0.0", "Diag_NpWOREc",
         "Recuperación primaria extrapolada al WOR límite. Solo tiene sentido si "
         "ya hay historia de agua suficiente.")
    f += 1

    # ---------------- Balance de materia ----------------
    f = subtitulo(ws, f, "BALANCE DE MATERIA DE GAS (p/z vs Gp)", 4)
    pz_p, pz_i = regresion_sumproduct("Serie_Flagpz", "Serie_GpMMpc", "Serie_psobrez")
    fila("Puntos con presión", "=SUMPRODUCT(Serie_Flagpz)", "0", "Diag_pzN")
    fila("Pendiente", f"={pz_p}", "0.0000", "Diag_pzPend")
    fila("p/z inicial (psi)", f"={pz_i}", "#,##0.0", "Diag_pzInter")
    fila("OGIP por p/z (MMpc)",
         '=IFERROR(IF(OR(Diag_pzN<5,Diag_pzPend>=0),"",-Diag_pzInter/Diag_pzPend),"")',
         "#,##0", "Diag_OGIP",
         "La recta de p/z corta el eje Gp exactamente en el OGIP. Requiere "
         "reservorio volumétrico: con acuífero activo la recta se curva y el "
         "resultado sobreestima.")
    f += 1

    # ---------------- Volumetría ----------------
    f = subtitulo(ws, f, "VOLUMETRÍA Y PETRÓLEO MÓVIL", 4)
    ooip = ('=IFERROR(IF(OR(Act_Areaha="",Act_Espesornetom="",Act_Porosidad="",'
            'Act_Swi="",Act_Boi=""),"",'
            '7758*(Act_Areaha*2.47105)*(Act_Espesornetom*3.28084)*Act_Porosidad'
            '*(1-Act_Swi)/Act_Boi/1000),"")')
    fila("OOIP volumétrico (Mbbl)", ooip, "#,##0", "Diag_OOIP",
         "7758 x acres x pies x phi x (1-Sw) / Boi. Devuelve vacío si falta "
         "cualquier término: no se completa con supuestos.")
    fila("Factor de recobro actual",
         '=IFERROR(IF(N(Diag_OOIP)<=0,"",Diag_Np/Diag_OOIP),"")', "0.0%", "Diag_RF")
    fila("So estimada por balance",
         '=IFERROR(IF(OR(Act_Swi="",N(Diag_RF)<=0),"",(1-Act_Swi)*(1-Diag_RF)),"")',
         "0.000", "Diag_SoEst",
         "Estimación gruesa que supone ausencia de capa de gas. Si hay So medida "
         "en registro de saturación, esa manda.")
    fila("So usada",
         '=IF(Act_Soactual<>"",Act_Soactual,IF(ISNUMBER(Diag_SoEst),Diag_SoEst,""))',
         "0.000", "Diag_So")
    fila("Petróleo móvil remanente (So - Sor)",
         '=IFERROR(IF(OR(Diag_So="",Act_Sor=""),"",Diag_So-Act_Sor),"")',
         "0.000", "Diag_Movil",
         "Criterio de mayor peso del score técnico y disparador del killing "
         "factor K1. Si sale vacío, el IAW no se puede calcular.")
    f += 1

    # ---------------- VRR ----------------
    f = subtitulo(ws, f, "BALANCE DE VACIAMIENTO (VRR acumulado)", 4)
    vac = ('IFERROR(Diag_Np*1000*Act_Bo+Diag_Wp*1000*Act_Bw'
           '+MAX(0,Diag_Gp*1000-Diag_Np*Act_Rs)*Act_Bg,"")')
    fila("Vaciamiento acumulado (bbl res.)", f"={vac}", "#,##0", "Diag_Vaciamiento",
         "Np*Bo + Wp*Bw + gas libre*Bg. El gas libre es Gp menos el gas que "
         "estaba disuelto (Np*Rs).")
    fila("Inyección acumulada (bbl res.)",
         '=IFERROR(Diag_Wi*1000*Act_Bw,"")', "#,##0", "Diag_Inyeccion")
    fila("VRR acumulado",
         '=IFERROR(IF(N(Diag_Vaciamiento)<=0,"",Diag_Inyeccion/Diag_Vaciamiento),"")',
         "0.00", "Diag_VRR",
         "Cerca de 1 significa que el vaciamiento se está reponiendo. Cero es lo "
         "esperable en un campo sin inyección y no es un error.")
    f += 1

    # ---------------- Hall e índice de productividad ----------------
    f = subtitulo(ws, f, "INYECTORES (HALL) Y PRODUCTIVIDAD", 4)
    hall_tot, _ = regresion_sumproduct("Serie_FlagHall", "Serie_WiMbbl",
                                       "Serie_Hallacum")
    hall_rec, _ = regresion_sumproduct("Serie_FlagHallRec", "Serie_WiMbbl",
                                       "Serie_Hallacum")
    fila("Meses con inyección", "=SUMPRODUCT(Serie_FlagHall)", "0", "Diag_HallN")
    fila("Pendiente de Hall — todo el período", f"={hall_tot}", "#,##0.0",
         "Diag_HallTot",
         "Pendiente de la integral de Hall contra el agua inyectada acumulada. "
         "Su VARIACIÓN es el diagnóstico, no su valor.")
    fila("Pendiente de Hall — últimos 24 meses", f"={hall_rec}", "#,##0.0",
         "Diag_HallRec")
    estado_hall = ('=IF(Diag_HallN<12,"SIN DATOS DE INYECCIÓN",'
                   'IF(OR(NOT(ISNUMBER(Diag_HallRec)),NOT(ISNUMBER(Diag_HallTot)),'
                   'Diag_HallTot<=0),"INDETERMINADO",'
                   'IF(Diag_HallRec>1.25*Diag_HallTot,"DAÑO CRECIENTE",'
                   'IF(Diag_HallRec<0.75*Diag_HallTot,"POSIBLE FRACTURA",'
                   '"INYECTIVIDAD ESTABLE"))))')
    r_hall = fila("Estado del inyector", estado_hall, None, "Diag_Hall",
                  "Pendiente creciente = daño; decreciente = la formación se "
                  "está fracturando; constante = inyectividad sana.")
    ws.cell(r_hall, 2).font = Font(bold=True)
    for texto, color in (("DAÑO CRECIENTE", ROJO), ("POSIBLE FRACTURA", AMARILLO),
                         ("INYECTIVIDAD ESTABLE", VERDE)):
        ws.conditional_formatting.add(
            f"B{r_hall}", CellIsRule(operator="equal", formula=[f'"{texto}"'],
                                     fill=PatternFill("solid", fgColor=color)))

    fila("IP aparente inicial",
         '=IFERROR(INDEX(Serie_IPaparente,MATCH(1,Serie_FlagIP,0)),"")',
         "0.000", "Diag_IPini",
         "Índice de productividad usando la presión inicial como referencia. El "
         "valor absoluto no significa nada; la tendencia sí.")
    fila("IP aparente actual",
         '=IFERROR(LOOKUP(2,1/(Serie_FlagIP=1),Serie_IPaparente),"")',
         "0.000", "Diag_IPact")
    fila("Variación del IP",
         '=IFERROR(IF(N(Diag_IPini)<=0,"",Diag_IPact/Diag_IPini-1),"")',
         "0.0%", "Diag_IPvar",
         "Una caída fuerte con presión sostenida apunta a daño; una caída junto "
         "con la presión apunta a agotamiento.")
    f += 1

    # ---------------- Interpretación ----------------
    f = subtitulo(ws, f, "INTERPRETACIÓN AUTOMÁTICA", 4)
    ws.cell(f - 1, 4, "Texto generado por fórmula a partir de los resultados de arriba."
            ).font = F_NOTA
    interp = [
        ("Estado de agotamiento",
         '=IF(NOT(ISNUMBER(Diag_RF)),"Sin OOIP no se puede evaluar el agotamiento. '
         'Falta área, espesor, porosidad, Swi o Boi.",'
         'IF(Diag_RF<0.12,"Factor de recobro bajo ("&TEXT(Diag_RF,"0,0%")&"): '
         'queda mucho petróleo por recuperar. Candidato de interés.",'
         'IF(Diag_RF<0.30,"Factor de recobro intermedio ("&TEXT(Diag_RF,"0,0%")&"): '
         'potencial razonable para recuperación secundaria.",'
         '"Factor de recobro alto ("&TEXT(Diag_RF,"0,0%")&"): verificar que quede '
         'petróleo móvil suficiente antes de seguir.")))'),
        ("Mecanismo de producción de agua",
         '=IF(Diag_Chan="SIN AGUA","No hay producción de agua significativa. El '
         'diagnóstico de Chan no aplica todavía.",'
         'IF(Diag_Chan="CANALIZACION","Canalización probable (pendiente de WOR* '
         '"&TEXT(Diag_PendWORd,"+0,00")&"). El agua toma un camino preferencial. '
         'Evaluar conformancia y trazadores ANTES de considerar inyección: inyectar '
         'sobre un canal existente lo agrava.",'
         'IF(Diag_Chan="CONIFICACION","Conificación probable (pendiente de WOR* '
         '"&TEXT(Diag_PendWORd,"+0,00")&"). Es un problema de completación y de '
         'caudal, no de barrido. Revisar intervalos y tasas antes de atribuirlo '
         'al reservorio.",'
         'IF(Diag_Chan="DESPLAZAMIENTO NORMAL","Desplazamiento normal (pendiente de '
         'WOR* "&TEXT(Diag_PendWORd,"+0,00")&"). El avance del agua es el esperable, '
         'sin patología detectada.",'
         '"Datos insuficientes para clasificar: se requieren al menos '
         '"&Chan_Min_Puntos&" meses con agua."))))'),
        ("Calidad del ajuste de declinación",
         '=IF(NOT(ISNUMBER(Fit_R2)),"No se pudo ajustar la declinación.",'
         'IF(Fit_R2>=0.9,"Ajuste bueno (R2 = "&TEXT(Fit_R2,"0,000")&") con b = '
         '"&TEXT(Fit_b,"0,00")&".",'
         '"Ajuste pobre (R2 = "&TEXT(Fit_R2,"0,000")&"). Acotar la ventana de '
         'ajuste en Config: es habitual que la historia completa mezcle períodos '
         'con mecanismos distintos."))'),
        ("Integridad de los datos",
         '=IF(Diag_Desorden>0,"ATENCIÓN: hay "&Diag_Desorden&" fila(s) fuera de '
         'orden en Carga_Producción. Los acumulados por pozo son incorrectos '
         'hasta ordenar por Pozo y luego por Fecha.",'
         'IF(Diag_MesesAct=0,"No hay datos para el reservorio seleccionado. '
         'Verificar que el nombre en Config coincida exactamente con el de '
         'Carga_Producción.","Datos consistentes: '
         '"&Diag_MesesAct&" meses con actividad."))'),
        ("Salud de los inyectores",
         '=IF(Diag_Hall="SIN DATOS DE INYECCIÓN","El reservorio no tiene '
         'inyección registrada: el gráfico de Hall no aplica todavía.",'
         'IF(Diag_Hall="DAÑO CRECIENTE","La pendiente de Hall creció '
         '"&TEXT(Diag_HallRec/Diag_HallTot-1,"0,0%")&" en los últimos 24 meses: '
         'daño progresivo en los inyectores. Revisar calidad del agua de '
         'inyección y programa de estimulación.",'
         'IF(Diag_Hall="POSIBLE FRACTURA","La pendiente de Hall cayó: la '
         'formación podría estar fracturándose. Verificar que la presión de '
         'inyección esté por debajo de la presión de fractura; una fractura no '
         'controlada canaliza el agua y arruina el barrido.",'
         'IF(Diag_Hall="INYECTIVIDAD ESTABLE","Inyectividad estable: la '
         'pendiente de Hall no cambió de forma significativa.",'
         '"Datos de inyección insuficientes para diagnosticar."))))'),
        ("Tendencia de la productividad",
         '=IF(NOT(ISNUMBER(Diag_IPvar)),"Sin presiones de fondo suficientes para '
         'calcular el índice de productividad.",'
         'IF(Diag_IPvar<-0.5,"El IP aparente cayó "&TEXT(-Diag_IPvar,"0,0%")&": '
         'caída fuerte. Distinguir daño de agotamiento comparando contra la '
         'evolución de la presión de reservorio.",'
         'IF(Diag_IPvar<-0.2,"El IP aparente cayó "&TEXT(-Diag_IPvar,"0,0%")&": '
         'caída moderada, dentro de lo esperable en un campo maduro.",'
         '"El IP aparente se mantiene ("&TEXT(Diag_IPvar,"+0,0%")&").")))'),
        ("Aptitud preliminar para inyección",
         '=IF(Act_Tipo="Condensado seco","No aplica waterflooding: reservorio de '
         'condensado sin anillo de petróleo (killing factor K2).",'
         'IF(NOT(ISNUMBER(Diag_Movil)),"No evaluable: falta So o Sor para calcular '
         'el petróleo móvil remanente. Es el dato que desbloquea el screening.",'
         'IF(Diag_Movil<0.05,"Petróleo móvil remanente insuficiente '
         '("&TEXT(Diag_Movil,"0,000")&"): killing factor K1 activo.",'
         'IF(Diag_Movil<0.15,"Petróleo móvil remanente marginal '
         '("&TEXT(Diag_Movil,"0,000")&"). Verificar Sor con núcleo antes de '
         'avanzar.","Petróleo móvil remanente favorable '
         '("&TEXT(Diag_Movil,"0,000")&"). Pasa el criterio de mayor peso."))))'),
    ]
    for etiqueta, formula in interp:
        ws.cell(f, 1, etiqueta).font = F_CAB
        c = ws.cell(f, 2, formula)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=f, start_column=2, end_row=f, end_column=4)
        ws.row_dimensions[f].height = 62
        f += 1

    proteger(ws)
    return ws


# ===========================================================================
# Hoja Completitud
# ===========================================================================
def hoja_completitud(wb, filas_param):
    ws = wb.create_sheet("Completitud")
    anchos(ws, {"A": 36, "B": 8, "C": 12, "D": 60})
    f = titulo(ws, 1, "COMPLETITUD DE DATOS DEL RESERVORIO ACTIVO", 4)
    f = nota(ws, f,
             "El IAW se reporta siempre junto a este porcentaje. Un índice alto "
             "sostenido por pocos datos no es el mismo número que uno bien "
             "sustentado, y la diferencia tiene que estar a la vista.")
    f += 1
    f = cabeceras(ws, f, ["Dato", "Nivel", "¿Disponible?", "Para qué se usa"])

    por_nivel = {"N1": [], "N2": [], "N3": []}
    for nombre, etiqueta, _v, nivel, desc in ESTATICOS:
        if nombre == "SECCION" or nombre not in filas_param:
            continue
        ws.cell(f, 1, etiqueta)
        n = ws.cell(f, 2, nivel)
        n.alignment = Alignment(horizontal="center")
        c = ws.cell(f, 3, f'=IF(Act_{limpiar_nombre(nombre)}="","FALTA","OK")')
        c.alignment = Alignment(horizontal="center")
        c.font = F_CAB
        d = ws.cell(f, 4, desc)
        d.font = F_NOTA
        d.alignment = Alignment(wrap_text=True, vertical="top")
        por_nivel[nivel].append(f)
        f += 1

    for texto, color in (("OK", VERDE), ("FALTA", ROJO)):
        ws.conditional_formatting.add(
            f"C6:C{f - 1}",
            CellIsRule(operator="equal", formula=[f'"{texto}"'],
                       fill=PatternFill("solid", fgColor=color)))

    f += 1
    f = subtitulo(ws, f, "RESUMEN POR NIVEL", 4)
    leyendas = {
        "N1": "Nivel 1 — mínimo indispensable. Habilita el diagnóstico de este libro.",
        "N2": "Nivel 2 — habilita el IAW del Libro B. Sin esto no hay screening.",
        "N3": "Nivel 3 — refinamiento. No bloquea, sube la confianza.",
    }
    for nivel in ("N1", "N2", "N3"):
        filas = por_nivel[nivel]
        cond = "+".join(f'--(C{r}="OK")' for r in filas)
        ws.cell(f, 1, leyendas[nivel]).font = F_CAB
        c = ws.cell(f, 3, f"=IFERROR(({cond})/{len(filas)},0)")
        c.number_format = "0%"
        c.fill = R_CAB
        nombrar(wb, f"Comp_{nivel}", "Completitud", f"$C${f}")
        f += 1

    todas = sum(por_nivel.values(), [])
    cond = "+".join(f'--(C{r}="OK")' for r in todas)
    ws.cell(f, 1, "GLOBAL").font = Font(bold=True, size=12)
    c = ws.cell(f, 3, f"=IFERROR(({cond})/{len(todas)},0)")
    c.number_format = "0%"
    c.font = Font(bold=True, size=12)
    c.fill = R_CAB
    nombrar(wb, "Comp_Global", "Completitud", f"$C${f}")
    f += 2

    ws.cell(f, 1, "Banda de confianza").font = F_CAB
    ws.cell(f, 3,
            '=IF(Comp_Global>=0.75,"El ranking es defendible",'
            'IF(Comp_Global>=0.5,"Indicativo: verificar antes de comprometer capital",'
            '"NO usar para decidir. Usar para priorizar qué datos recopilar"))')
    ws.merge_cells(start_row=f, start_column=3, end_row=f, end_column=4)
    proteger(ws)
    return ws


# ===========================================================================
# Hoja Resumen — la fila que se copia al Libro B
# ===========================================================================
def hoja_resumen(wb):
    ws = wb.create_sheet("Resumen")
    f = titulo(ws, 1, "FILA DE RESUMEN — copiar y pegar en la hoja "
                      "Reservorios del Libro B", 10)
    f = nota(ws, f, "Seleccionar la fila 4 completa, copiar, y pegar como VALORES "
                    "en el Libro B. Pegar con fórmulas crearía un vínculo externo "
                    "que se rompe al mover el archivo.")

    for j, (h, formula, fmt, ancho) in enumerate(COLUMNAS_RESUMEN, start=1):
        c = ws.cell(3, j, h)
        c.font = F_CAB
        c.fill = R_CAB
        c.border = BORDE_FINO
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[CL(j)].width = ancho
        v = ws.cell(4, j, formula if formula else VERSION)
        if fmt:
            v.number_format = fmt
        v.border = BORDE_FINO
    ws.row_dimensions[3].height = 34
    ws.freeze_panes = "A4"
    proteger(ws)
    return ws


# ===========================================================================
# Hoja Gráficos
# ===========================================================================
def _serie_ref(ws_serie, col, titulo_serie):
    return Series(Reference(ws_serie, min_col=col, min_row=SER0, max_row=SER1),
                  title=titulo_serie)


# Título del eje X cuando la columna graficada es una de las `*_graf`, que
# existen por una razón técnica que al lector del gráfico no le importa.
TITULO_EJE_X = {"t_graf": "t_años"}


def hoja_graficos(wb, ws_serie):
    ws = wb.create_sheet("Gráficos")
    titulo(ws, 1, "GRÁFICOS DEL RESERVORIO ACTIVO", 12)
    nota(ws, 2, "Se redibujan solos al cambiar Reservorio_Sel en la hoja Config.")

    definiciones = [
        # (título, col_x, [(col_y, nombre)], log_x, log_y, ancla)
        ("Caudales vs tiempo", SC["t_graf"],
         [(SC["Qo_bpd"], "Qo (bpd)"), (SC["Qw_bpd"], "Qw (bpd)")],
         False, True, "A4"),
        ("Chan — WOR y WOR' vs tiempo (log-log)", SC["t_graf"],
         [(SC["WOR"], "WOR"), (SC["WOR_deriv"], "WOR'")],
         True, True, "J4"),
        ("WOR vs Np acumulado", SC["Np_Mbbl"],
         [(SC["WOR"], "WOR")], False, True, "A22"),
        ("GOR vs tiempo", SC["t_graf"],
         [(SC["GOR_pc_bbl"], "GOR (pc/bbl)")], False, False, "J22"),
        ("Corte de agua vs Np", SC["Np_Mbbl"],
         [(SC["fw"], "fw")], False, False, "A40"),
        ("p/z vs Gp acumulado", SC["Gp_MMpc"],
         [(SC["pz_graf"], "p/z (psi)")], False, False, "J40"),
        ("Np acumulado vs tiempo", SC["t_graf"],
         [(SC["Np_Mbbl"], "Np (Mbbl)")], False, False, "A58"),
        ("Presión vs tiempo", SC["t_graf"],
         [(SC["Pres_psi"], "Presión (psi)")], False, False, "J58"),
        ("Gráfico de Hall — integral vs agua inyectada", SC["Wi_Mbbl"],
         [(SC["Hall_graf"], "Integral de Hall")], False, False, "A76"),
        ("Índice de productividad aparente vs tiempo", SC["t_graf"],
         [(SC["IP_aparente"], "IP aparente (bpd/psi)")], False, False, "J76"),
    ]

    for tit, colx, ys, logx, logy, ancla in definiciones:
        ch = ScatterChart()
        ch.title = tit
        ch.style = 13
        ch.height, ch.width = 8.2, 15.5
        nombre_x = COLS_SERIE[colx - 1][0]
        ch.x_axis.title = TITULO_EJE_X.get(nombre_x, nombre_x)
        ch.y_axis.title = ys[0][1]
        xref = Reference(ws_serie, min_col=colx, min_row=SER0, max_row=SER1)
        for coly, nombre in ys:
            s = Series(Reference(ws_serie, min_col=coly, min_row=SER0, max_row=SER1),
                       xref, title=nombre)
            # Línea continua y sin marcadores. Son historias mensuales de
            # cientos de puntos: con marcadores de 3 pt y sin línea la curva se
            # ve como una nube de motas y el gráfico parece vacío.
            s.marker = Marker(symbol="none")
            s.graphicalProperties.line = LineProperties(w=12700)   # 1 pt
            s.smooth = False
            ch.series.append(s)
        if logx:
            ch.x_axis.scaling.logBase = 10
        if logy:
            ch.y_axis.scaling.logBase = 10
        # Sin esto Excel oculta los ejes de un gráfico creado por openpyxl
        ch.x_axis.delete = False
        ch.y_axis.delete = False
        ws.add_chart(ch, ancla)

    # Los gráficos van en dos columnas y no entran en un A4 vertical: al
    # imprimir o exportar a PDF, la columna derecha queda cortada por el
    # margen. Alguien va a imprimir esta hoja para llevarla a una reunión.
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    return ws


# ===========================================================================
# Hoja Bibliografía
# ===========================================================================
BIBLIO = [
    ("Declinación de Arps", "Arps, J.J. — Analysis of Decline Curves, "
     "Trans. AIME 160, 1945",
     "Grilla_b y sección de declinación del Diagnóstico"),
    ("Diagnóstico de agua", "Chan, K.S. — Water Control Diagnostic Plots, "
     "SPE 30775, 1995",
     "WOR, WOR' y clasificación en Diagnóstico"),
    ("Heterogeneidad y recobro", "Dykstra, H. y Parsons, R.L. — Prediction of Oil "
     "Recovery by Waterflood, JPT 8(11), 1956",
     "Criterio de heterogeneidad del Libro B"),
    ("Criterios de screening", "Taber, J.J., Martin, F.D. y Seright, R.S. — EOR "
     "Screening Criteria Revisited, Partes 1 y 2, SPE Res. Eng. 12(3), 1997",
     "Rangos de la hoja Criterios del Libro B"),
    ("Salud del inyector", "Hall, H.N. — How to Analyze Waterflood Injection Well "
     "Performance, World Oil, 1963",
     "Integral de Hall y su pendiente; sección Inyectores del Diagnóstico"),
    ("Índice de productividad", "Práctica corriente de vigilancia de pozos",
     "IP aparente; la tendencia distingue daño de agotamiento"),
    ("Balance de materia", "Havlena, D. y Odeh, A.S. — The Material Balance as an "
     "Equation of a Straight Line, JPT, 1963",
     "p/z vs Gp y estimación de OGIP"),
    ("Anillo con casquete", "Development strategies of a gas condensate reservoir "
     "with a large gas cap and thin oil rim, Petroleum Science, 2025",
     "Rama de condensado con anillo"),
]


def hoja_biblio(wb):
    ws = wb.create_sheet("Bibliografía")
    anchos(ws, {"A": 26, "B": 72, "C": 46})
    f = titulo(ws, 1, "BIBLIOGRAFÍA POR MÉTODO", 3)
    f += 1
    f = cabeceras(ws, f, ["Método", "Referencia", "Dónde se usa en este libro"])
    for metodo, ref, uso in BIBLIO:
        ws.cell(f, 1, metodo).font = F_CAB
        for col, txt in ((2, ref), (3, uso)):
            c = ws.cell(f, col, txt)
            c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[f].height = 32
        f += 1
    return ws


# ===========================================================================
def main():
    wb = Workbook()
    wb.remove(wb.active)

    hoja_leeme(wb)
    hoja_config(wb)
    hoja_carga_produccion(wb)
    _ws_est, filas_param, _fc = hoja_estaticos(wb)
    hoja_calculos(wb)
    ws_serie = hoja_serie(wb)
    hoja_grilla_b(wb)
    hoja_diagnostico(wb, filas_param)
    hoja_completitud(wb, filas_param)
    hoja_resumen(wb)
    hoja_graficos(wb, ws_serie)
    hoja_biblio(wb)

    wb.properties.title = "Libro A — Diagnóstico de campo"
    wb.properties.creator = "Proyecto de screening de waterflooding — YPFB"

    destino = SALIDA / f"Libro_A_Diagnostico_v{VERSION}.xlsx"
    wb.save(destino)
    print(f"Libro A -> {destino.relative_to(RAIZ)}")
    print(f"  hojas: {len(wb.sheetnames)}  |  nombres definidos: "
          f"{len(list(wb.defined_names))}")
    return destino


if __name__ == "__main__":
    main()
