"""
Verificación de los libros en una hoja de cálculo REAL (LibreOffice).

Las tres capas anteriores evalúan fórmulas; ninguna abre el archivo. Esta lo
hace: le pasa los libros a LibreOffice, lo obliga a recalcular todo desde cero y
después lee lo que quedó calculado. Es la única capa que ejercita el artefacto
completo —el mismo `.xlsx` que se entrega, con sus ~103.000 fórmulas, sus
gráficos y su formato— en vez de una versión reducida.

**Cómo lee los resultados.** LibreOffice, al convertir un `.xlsx`, escribe en el
archivo de salida los valores que calculó. Entonces alcanza con convertir y
volver a leer con `openpyxl(data_only=True)`: no hace falta UNO ni macros. El
único requisito es forzar el recálculo al cargar, porque LibreOffice por defecto
se queda con la caché del archivo de entrada —que en un libro recién generado
por openpyxl está vacía— y el chequeo daría todo en blanco sin fallar.

**Qué NO demuestra.** LibreOffice no es Excel. Coincide en el conjunto de
funciones que estos libros usan y es un segundo motor independiente, lo cual es
mucho, pero no reemplaza la prueba en el Excel que efectivamente usa YPFB. Los
gráficos tampoco se verifican acá: se revisan sobre el PDF que exporta
`--convert-to pdf`.
"""

import shutil
import subprocess
import sys
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

import construir_libro_a as A                                      # noqa: E402
import construir_libro_b as B                                      # noqa: E402
from verificar_numerico import (SALIDAS, cargar_golden, celda_de,   # noqa: E402
                                comparar, imprimir_resultados)
from verificar_numerico_b import filas_de_prueba                    # noqa: E402

# El directorio de trabajo va DENTRO del proyecto, no en /tmp, porque la versión
# flatpak de LibreOffice corre con un /tmp privado y no vería los archivos.
TRABAJO = RAIZ / "construccion" / ".tmp_libreoffice"
PERFIL = TRABAJO / "perfil"
SALIDA = TRABAJO / "salida"

DEMO = RAIZ / "datos" / "ejemplos" / f"Libro_A_DEMO_CAMPO_SINTETICO_v{A.VERSION}.xlsx"
LIBRO_B = RAIZ / "herramienta" / f"Libro_B_Screening_v{B.VERSION}.xlsx"

# Valores de error tal como los escribe una hoja de cálculo en la celda. `Err:`
# cubre los códigos propios de LibreOffice (Err:501, Err:508...), que no tienen
# equivalente textual en Excel y delatan una fórmula mal formada.
ERRORES = {"#NAME?", "#REF!", "#VALUE!", "#DIV/0!", "#N/A", "#NULL!", "#NUM!",
           "#NAME", "#N/D"}

TIEMPO_LIMITE = 600


def localizar_libreoffice():
    """Devuelve el prefijo de comando para invocar LibreOffice, o None."""
    for cand in ("soffice", "libreoffice"):
        ruta = shutil.which(cand)
        if ruta:
            return [ruta]
    if shutil.which("flatpak"):
        r = subprocess.run(["flatpak", "info", "org.libreoffice.LibreOffice"],
                           capture_output=True)
        if r.returncode == 0:
            return ["flatpak", "run", "org.libreoffice.LibreOffice"]
    return None


def preparar_perfil(cmd):
    """Crea un perfil desechable con recálculo al cargar SIEMPRE activado.

    Perfil aparte del personal por dos razones: para no cambiarle la
    configuración a quien esté usando LibreOffice en esta máquina, y para que la
    verificación no dependa de cómo lo tenga configurado.
    """
    PERFIL.mkdir(parents=True, exist_ok=True)
    registro = PERFIL / "user" / "registrymodifications.xcu"
    if not registro.exists():
        subprocess.run(cmd + [f"-env:UserInstallation=file://{PERFIL}",
                              "--headless", "--terminate_after_init"],
                       capture_output=True, timeout=TIEMPO_LIMITE)
    if not registro.exists():
        raise RuntimeError(f"LibreOffice no generó el perfil en {PERFIL}")

    texto = registro.read_text(encoding="utf-8")
    if "OOXMLRecalcMode" not in texto:
        item = ('<item oor:path="/org.openoffice.Office.Calc/Formula/Load">'
                '<prop oor:name="OOXMLRecalcMode" oor:op="fuse">'
                '<value>0</value></prop></item>')     # 0 = recalcular siempre
        registro.write_text(texto.replace("</oor:items>", item + "</oor:items>"),
                            encoding="utf-8")


def convertir(cmd, entrada, formato="xlsx"):
    """Convierte con LibreOffice y devuelve (ruta de salida, segundos)."""
    SALIDA.mkdir(parents=True, exist_ok=True)
    destino = SALIDA / f"{entrada.stem}.{formato.split(':')[0]}"
    destino.unlink(missing_ok=True)
    t0 = time.perf_counter()
    r = subprocess.run(cmd + [f"-env:UserInstallation=file://{PERFIL}",
                              "--headless", "--convert-to", formato,
                              "--outdir", str(SALIDA), str(entrada)],
                       capture_output=True, text=True, timeout=TIEMPO_LIMITE)
    seg = time.perf_counter() - t0
    if not destino.exists():
        raise RuntimeError(f"LibreOffice no produjo {destino.name}.\n"
                           f"{r.stdout}\n{r.stderr}")
    return destino, seg


def celdas_con_error(wb, tope=20):
    """Barre el libro calculado buscando celdas en error."""
    hallados = []
    for ws in wb.worksheets:
        for fila in ws.iter_rows():
            for celda in fila:
                v = celda.value
                if isinstance(v, str) and (v in ERRORES or v.startswith("Err:")):
                    hallados.append((ws.title, celda.coordinate, v))
                    if len(hallados) >= tope:
                        return hallados
    return hallados


def verificar_libro_a(cmd):
    from openpyxl import load_workbook

    if not DEMO.exists():
        print(f"  No existe {DEMO.name}. Correr primero preparar_demo.py")
        return 1, 0.0

    golden = cargar_golden()
    referencia = load_workbook(DEMO)          # con fórmulas: resuelve los nombres
    ubicacion = {n: celda_de(referencia, n) for n in SALIDAS}
    hoja_sel, coord_sel = celda_de(referencia, "Reservorio_Sel")

    fallos, lineas, peor = 0, [], 0.0
    errores = []
    for nombre in sorted(golden):
        wb = load_workbook(DEMO)
        wb[hoja_sel][coord_sel] = nombre
        entrada = TRABAJO / f"A_{nombre}.xlsx"
        wb.save(entrada)

        convertido, seg = convertir(cmd, entrada)
        peor = max(peor, seg)
        calculado = load_workbook(convertido, data_only=True)
        got = {n: calculado[h][c].value for n, (h, c) in ubicacion.items()}

        chk = comparar(got, golden[nombre])
        fallos += sum(1 for c in chk if not c[3])
        lineas.append((nombre, chk))
        if not errores:
            errores = celdas_con_error(calculado)
        print(f"  · {nombre} recalculado por LibreOffice ({seg:.1f} s)", flush=True)

    imprimir_resultados(
        "LIBRO A RECALCULADO POR LIBREOFFICE (libro completo, no reducido)",
        lineas, fallos)

    if errores:
        fallos += len(errores)
        print("\n  Celdas en error:")
        for hoja, coord, v in errores:
            print(f"    {hoja}!{coord}  {v}")
    else:
        print("\n  Sin celdas en error en ninguna hoja.")
    return fallos, peor


def verificar_libro_b(cmd):
    from openpyxl import load_workbook

    if not LIBRO_B.exists():
        print(f"  No existe {LIBRO_B.name}. Correr primero construir_libro_b.py")
        return 1, 0.0

    convertido, seg = convertir(cmd, LIBRO_B)
    referencia = load_workbook(LIBRO_B)
    filas, fila_global = filas_de_prueba(referencia["Pruebas"])
    calculado = load_workbook(convertido, data_only=True)
    ws = calculado["Pruebas"]

    a = 92
    print("\n" + "=" * a)
    print("LIBRO B RECALCULADO POR LIBREOFFICE — su propia hoja Pruebas")
    print("=" * a)
    print(f"  {'Caso':<18}{'Qué verifica':<44}{'Obtenido':>11}{'Esperado':>11}")
    print("-" * a)

    def fmt(x):
        return f"{x:,.3f}" if isinstance(x, float) else str(x)[:11]

    fallos = 0
    for r in filas:
        caso = referencia["Pruebas"].cell(r, 1).value or ""
        que = referencia["Pruebas"].cell(r, 2).value or ""
        res = str(ws.cell(r, 5).value).strip() if ws.cell(r, 5).value else "?"
        if res != "OK":
            fallos += 1
        print(f"  {caso:<18}{que[:43]:<44}"
              f"{fmt(ws.cell(r, 3).value):>11}{fmt(ws.cell(r, 4).value):>11}   {res}")

    print("-" * a)
    if fila_global:
        print(f"  Resultado que muestra la propia hoja: "
              f"{str(ws.cell(fila_global, 3).value).strip()}")

    errores = celdas_con_error(calculado)
    if errores:
        fallos += len(errores)
        print("\n  Celdas en error:")
        for hoja, coord, v in errores:
            print(f"    {hoja}!{coord}  {v}")
    else:
        print("  Sin celdas en error en ninguna hoja.")

    print("=" * a)
    print("RESULTADO: TODO OK" if fallos == 0 else f"RESULTADO: {fallos} FALLA(S)")
    print("=" * a)
    return fallos, seg


def main():
    cmd = localizar_libreoffice()
    if cmd is None:
        print("  LibreOffice no está instalado: se omite esta capa.")
        print("  (las otras tres capas no lo necesitan; esta sí, y es la única")
        print("   que prueba el libro completo en una hoja de cálculo real)")
        return 0

    TRABAJO.mkdir(parents=True, exist_ok=True)
    preparar_perfil(cmd)
    print(f"  LibreOffice: {' '.join(cmd)}")

    fallos_a, seg_a = verificar_libro_a(cmd)
    fallos_b, seg_b = verificar_libro_b(cmd)

    print(f"\n  Tiempo de carga + recálculo completo + guardado:")
    print(f"    Libro A (peor caso, ~103.000 fórmulas): {seg_a:.1f} s")
    print(f"    Libro B:                                {seg_b:.1f} s")
    print("  Incluye el arranque del proceso y el guardado, así que es una cota")
    print("  superior de lo que tarda un recálculo dentro de la aplicación.")

    return 1 if (fallos_a or fallos_b) else 0


if __name__ == "__main__":
    raise SystemExit(main())
