"""
Arma un Libro A con un yacimiento real del norte argentino ya cargado.

El demo sintético sirve para ver la herramienta funcionando; este script sirve
para verla trabajar contra datos que alguien puede auditar. La fuente es el
Capítulo IV de la Secretaría de Energía de Argentina, que publica producción e
inyección por pozo y por mes.

    python construccion/cargar_capiv.py PALMAR_LARGO

Reglas que hereda del LÉEME del Libro A y que este script no puede violar:

  - Las filas salen ordenadas por pozo y después por fecha, porque los
    acumulados se calculan como suma corrida.
  - Vacío significa DESCONOCIDO. Las presiones de fondo, de boca y de inyección
    no existen en fuente pública: van vacías. No se rellenan con correlaciones.
  - Cero significa CERO. Capítulo IV informa cero, no blanco, cuando un pozo no
    produjo o no inyectó, así que ese cero se transcribe tal cual.

Los meses con menos de MIN_DIAS_EF días efectivos quedan afuera: dividir un
volumen mensual por dos días de operación fabrica un caudal que nunca existió.
Es el mismo umbral que usa scripts/dca_referencia.py en el curso.

Con una excepción que hay que conocer para no perder la mitad del campo: el tef
de Capítulo IV cuenta días de PRODUCCIÓN, así que un pozo inyector informa
siempre tef = 0. Sus filas se toman igual, con los días del mes como base del
caudal de inyección. Sin esa excepción, los inyectores desaparecen del libro y
el screening se queda sin la mitad que le importa.
"""

import csv
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from openpyxl import load_workbook          # noqa: E402

import construir_libro_a as A               # noqa: E402

RAIZ = Path(__file__).resolve().parent.parent
CURSO = Path.home() / "Projects" / "activos" / "curso-ia-energia" / "scripts" / "_cache"
MENSUAL = CURSO / "capiv_noroeste_oil_monthly.csv"
POZOS = CURSO / "capiv_noroeste_oil_wells.json"
CATALOGO = (Path.home() / "Projects" / "research" / "subsidencia-vaca-muerta" /
            "exploraciones" / "escala_pozo" / "_data" / "capitulo_iv_pozos.csv")

# --- Conversiones a unidades de campo --------------------------------------
# Capítulo IV informa volúmenes mensuales: petróleo y agua en m3, gas en miles
# de m3. El Libro A piensa en caudales diarios de campo.
M3_A_BBL = 6.28981
KM3_A_MPC = 35.3147             # mil m3 -> miles de pies cúbicos
MIN_DIAS_EF = 10.0              # meses por debajo de esto quedan afuera
DIAS_MES = 30.4375              # base del caudal de inyección, que no tiene tef

# Formaciones que no son un reservorio.
NO_RESERVORIO = {"formación improductiva", "formacion improductiva", ""}

YACIMIENTOS = {
    "PALMAR_LARGO": "PALMAR LARGO",
    "CAMPO_DURAN_TUPAMBI": "CAMPO DURAN (TUPAMBI)",
    "CAIMANCITO": "CAIMANCITO",
    "PUESTO_GUARDIAN": "PUESTO GUARDIAN",
    "DOS_PUNTITAS": "DOS PUNTITAS",
}


def reservorio_de(pozo: dict) -> str:
    """La formación productiva del pozo. Un pozo puede figurar con varias;
    se toma la primera que sea un reservorio de verdad."""
    for f in pozo.get("formaciones") or []:
        if f.lower().strip() not in NO_RESERVORIO:
            return f.lower().strip()
    return ""


def profundidades(idpozos: set[str]) -> dict[str, float]:
    """Profundidad por pozo, del catálogo de Capítulo IV. Es dato de Nivel 1."""
    if not CATALOGO.exists():
        return {}
    csv.field_size_limit(1 << 24)
    out: dict[str, float] = {}
    with CATALOGO.open(encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            idp = (r.get("idpozo") or "").strip()
            if idp not in idpozos:
                continue
            try:
                p = float(r.get("profundidad") or 0)
            except ValueError:
                continue
            if p > 0:
                out[idp] = p
    return out


def main() -> int:
    clave = (sys.argv[1] if len(sys.argv) > 1 else "PALMAR_LARGO").upper()
    if clave not in YACIMIENTOS:
        print(f"Yacimiento desconocido: {clave}. Opciones: {', '.join(YACIMIENTOS)}")
        return 1
    yacimiento = YACIMIENTOS[clave]

    origen = RAIZ / "herramienta" / f"Libro_A_Diagnostico_v{A.VERSION}.xlsx"
    if not origen.exists():
        print("Falta el Libro A. Correr primero construir_libro_a.py")
        return 1
    if not MENSUAL.exists():
        print(f"Falta {MENSUAL}. Correr fetch_capiv_noroeste.py en el repo del curso.")
        return 1

    W = json.loads(POZOS.read_text(encoding="utf-8"))
    del_yac = {k for k, v in W.items() if (v.get("yacimiento") or "") == yacimiento}
    if not del_yac:
        print(f"El caché no tiene pozos de {yacimiento}.")
        return 1

    # --- Armado de filas ---------------------------------------------------
    filas = []
    descartadas = 0
    inyectoras = 0
    sin_reservorio = set()
    with MENSUAL.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            idp = r["idpozo"]
            if idp not in del_yac:
                continue
            tef = float(r["tef"])
            pet, gas, agua, iny = (float(r[k]) for k in
                                   ("prod_pet", "prod_gas", "prod_agua", "iny_agua"))
            # Un pozo sin ningún movimiento en el mes no aporta nada al ajuste.
            if pet == 0 and agua == 0 and gas == 0 and iny == 0:
                continue
            if tef >= MIN_DIAS_EF:
                dias = tef
            elif iny > 0:
                # Fila de inyección: el tef no la describe, el mes sí.
                dias = DIAS_MES
                inyectoras += 1
            else:
                descartadas += 1
                continue
            res = reservorio_de(W[idp])
            if not res:
                sin_reservorio.add(idp)
                continue
            y, m = (int(x) for x in r["ym"].split("-"))
            filas.append((
                W[idp].get("sigla") or idp,
                res,
                date(y, m, 1),
                round(dias, 2),
                round(pet * M3_A_BBL / dias, 3),
                round(agua * M3_A_BBL / dias, 3),
                round(gas * KM3_A_MPC / dias, 3),
                round(iny * M3_A_BBL / dias, 3),
            ))

    filas.sort(key=lambda x: (x[0], x[2]))
    if not filas:
        print("No quedó ninguna fila utilizable.")
        return 1
    if len(filas) > A.MAX_FILAS:
        print(f"El yacimiento da {len(filas)} filas y el libro admite {A.MAX_FILAS}.")
        return 1

    reservorios = sorted({f[1] for f in filas})
    if len(reservorios) > A.MAX_RES:
        print(f"{len(reservorios)} reservorios y el libro admite {A.MAX_RES}.")
        return 1

    wb = load_workbook(origen)
    ws = wb["Carga_Producción"]
    for i, (pozo, res, fecha, dias, qo, qw, qg, winy) in enumerate(filas):
        f = A.FIL0 + i
        ws.cell(f, 1, pozo)
        ws.cell(f, 2, res)
        ws.cell(f, 3, fecha).number_format = "DD/MM/YYYY"
        ws.cell(f, 4, dias)
        ws.cell(f, 5, qo)
        ws.cell(f, 6, qw)
        ws.cell(f, 7, qg)
        # Columnas 8 y 9 (Pwf, Pwh) quedan vacías a propósito: no hay dato.
        ws.cell(f, 10, winy)
        # Columna 11 (Piny) también queda vacía.

    # --- Estáticos: solo Nivel 1, que es lo único que da la fuente pública --
    est = wb["Carga_Estáticos"]
    fila_cab = next((rr for rr in range(1, 12)
                     if est.cell(rr, 1).value == "Parámetro"), None)
    columna_de = {}
    for j, nombre in enumerate(reservorios):
        est.cell(fila_cab, A.EST_C0 + j, nombre)
        columna_de[nombre] = A.EST_C0 + j

    etiqueta_de = {n: e for n, e, _v, _niv, _d in A.ESTATICOS if n != "SECCION"}
    fila_de = {}
    for rr in range(1, est.max_row + 1):
        v = est.cell(rr, 1).value
        for nombre, etiqueta in etiqueta_de.items():
            if v == etiqueta:
                fila_de[nombre] = rr

    prof = profundidades(del_yac)
    por_res = {}
    for idp in del_yac:
        res = reservorio_de(W[idp])
        if res in columna_de and idp in prof:
            por_res.setdefault(res, []).append(prof[idp])

    col_com = A.EST_C0 + A.MAX_RES     # columna "Comentario / fuente del dato"
    for res, col in columna_de.items():
        if "Formacion" in fila_de:
            est.cell(fila_de["Formacion"], col, res)
        if "Prof_m" in fila_de and por_res.get(res):
            vals = por_res[res]
            est.cell(fila_de["Prof_m"], col, round(sum(vals) / len(vals)))
            est.cell(fila_de["Prof_m"], col_com,
                     "Profundidad media de los pozos, catálogo de Capítulo IV")

    # --- Config ------------------------------------------------------------
    empresas = {W[i].get("empresa", "") for i in del_yac if W[i].get("empresa")}
    provincia = next((W[i].get("provincia", "") for i in del_yac
                      if W[i].get("provincia")), "")
    activo = max(reservorios, key=lambda res: sum(1 for f in filas if f[1] == res))
    cfg = wb["Config"]
    for rr in range(1, 60):
        etiqueta = cfg.cell(rr, 1).value
        if etiqueta == "Campo":
            cfg.cell(rr, 2, f"{yacimiento} ({provincia}, Argentina)")
        elif etiqueta == "Reservorio activo":
            cfg.cell(rr, 2, activo)
        elif etiqueta == "Analista":
            cfg.cell(rr, 2, "Curso YPFB — datos públicos de Capítulo IV")

    # --- Guía de lectura dentro del archivo --------------------------------
    pozos = sorted({f[0] for f in filas})
    meses = sorted({f[2] for f in filas})
    leeme = wb["LÉEME"]
    f = leeme.max_row + 3
    leeme.cell(f, 1, "DE DÓNDE SALEN ESTOS DATOS").font = A.Font(bold=True, size=12)
    f += 1
    notas = [
        ("Yacimiento", f"{yacimiento}, cuenca Noroeste, {provincia}"),
        ("Operador", ", ".join(sorted(empresas)) or "sin dato"),
        ("Fuente", "Capítulo IV, Secretaría de Energía de Argentina (datos abiertos)"),
        ("Período", f"{meses[0]:%m/%Y} a {meses[-1]:%m/%Y}"),
        ("Alcance", f"{len(pozos)} pozos, {len(filas):,} filas, "
                    f"{len(reservorios)} reservorio(s)"),
        ("Conversión", "petróleo y agua m3 -> bbl (6.28981); gas mil m3 -> Mpc "
                       "(35.3147); caudal = volumen mensual / días efectivos"),
        ("Filtro", f"meses con menos de {MIN_DIAS_EF:.0f} días efectivos, afuera "
                   f"({descartadas} filas). Las {inyectoras} filas de inyección "
                   f"no tienen días efectivos y usan los del mes."),
        ("Lo que NO hay", "presión de fondo, de boca y de inyección; y todo el "
                          "Nivel 2 (volumetría, fluidos, roca). Van vacías: la "
                          "fuente pública no las informa y no se inventan."),
    ]
    for k, v in notas:
        leeme.cell(f, 1, k).font = A.F_CAB
        c = leeme.cell(f, 2, v)
        c.alignment = A.Alignment(wrap_text=True, vertical="top")
        leeme.row_dimensions[f].height = 30
        f += 1

    destino = RAIZ / "datos" / "argentina"
    destino.mkdir(parents=True, exist_ok=True)
    salida = destino / f"Libro_A_{clave}_v{A.VERSION}_{date.today():%Y-%m-%d}.xlsx"
    wb.save(salida)

    print(f"Libro A -> {salida.relative_to(RAIZ)}  "
          f"({salida.stat().st_size / 1024 / 1024:.1f} MB)")
    print(f"  {yacimiento}: {len(pozos)} pozos, {len(filas):,} filas, "
          f"{meses[0]:%m/%Y} a {meses[-1]:%m/%Y}")
    print(f"  reservorios: {', '.join(reservorios)}  (activo al abrir: {activo})")
    print(f"  descartadas por días efectivos < {MIN_DIAS_EF:.0f}: {descartadas}")
    print(f"  filas de inyección, prorrateadas por mes: {inyectoras}")
    if sin_reservorio:
        print(f"  pozos sin formación productiva declarada, afuera: {len(sin_reservorio)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
