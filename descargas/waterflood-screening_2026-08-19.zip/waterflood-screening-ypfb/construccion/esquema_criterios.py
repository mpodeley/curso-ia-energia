"""
Definición de la metodología de screening: killing factors y criterios puntuados.

Los valores de acá son SEMILLA: se escriben en la hoja `Criterios` del Libro B y
a partir de ese momento la hoja manda. Un ingeniero cambia un umbral en una celda
y todo el libro recalcula, sin volver a ejecutar este archivo.

Los rangos por defecto provienen de la literatura internacional (Taber-Martin-
Seright 1997; Dykstra-Parsons 1956) y están pendientes de calibración contra la
experiencia boliviana —Víbora, Sirari, Yapacaní— en el taller de la Semana 8.
"""

# ---------------------------------------------------------------------------
# Killing factors duros: descartan por sí solos
# (código, nombre, comparador, umbral, unidad, columna_origen, si_falta, motivo)
# comparador: "<" descarta si el valor es menor que el umbral; ">" si es mayor;
#             "IGUAL" descarta si el texto coincide.
# ---------------------------------------------------------------------------
KILLING_DUROS = [
    ("K1", "Sin petróleo móvil remanente", "<", 0.05, "fracción",
     "Movil_remanente", "BLOQUEA",
     "So - Sor por debajo del umbral: no queda petróleo desplazable."),
    ("K2", "Condensado sin anillo de petróleo", "IGUAL", "Condensado seco", "—",
     "Tipo", "BLOQUEA",
     "Reservorio de condensado retrógrado sin fase líquida móvil: no hay "
     "petróleo que desplazar."),
    ("K2b", "Anillo de petróleo demasiado delgado", "<", 3.0, "m",
     "Espesor_anillo_m", "OMITE",
     "Anillo por debajo de 3 m: la conificación domina y el barrido vertical "
     "colapsa."),
    ("K5", "OOIP bajo el umbral económico", "<", 1500.0, "Mbbl incrementales",
     "__INCREMENTAL__", "BLOQUEA",
     "El incremental esperado no paga la infraestructura mínima."),
    ("K6", "Viscosidad excesiva", ">", 200.0, "cP",
     "uo_cP", "PENALIZA",
     "Relación de movilidad irrecuperable: derivar a métodos térmicos o "
     "químicos."),
]

# ---------------------------------------------------------------------------
# Killing factors mitigables: penalizan y disparan un estudio
# (código, nombre, comparador, umbral, unidad, columna, subíndice, penalización, estudio)
# ---------------------------------------------------------------------------
KILLING_MITIGABLES = [
    ("M2", "Casquete de gas primario grande", ">", 0.30, "V_gas/V_petróleo",
     "m_casquete", "T", 0.15,
     "Definir ubicación y secuencia de inyección; evaluar riesgo de migración "
     "de petróleo al casquete."),
    ("M5", "Integridad de pozos comprometida", "<", 60.0, "% verificado",
     "Integridad_ok_pct", "X", 0.25,
     "Censo de integridad; comparar costo de reacondicionamiento contra pozos "
     "nuevos."),
    ("M6", "Heterogeneidad alta", ">", 0.75, "Dykstra-Parsons",
     "V_Dykstra_Parsons", "T", 0.20,
     "Caracterización de capas y evaluación de inyección selectiva."),
    ("M7", "Presión muy por debajo de la de burbuja", "<", 0.70, "P/Pb",
     "__P_SOBRE_PB__", "E", 0.15,
     "Calcular volumen y tiempo de rellenado; el gas libre difiere la respuesta "
     "y corre el flujo de caja."),
    ("M8", "Restricción ambiental o social", "IGUAL", "Área protegida", "—",
     "Restriccion_amb", "X", 0.20,
     "Relevamiento socioambiental temprano; no diferirlo al FEED."),
]

# ---------------------------------------------------------------------------
# Criterios puntuados
# (código, nombre, subíndice, peso, tipo, x10, x7, x4, x0, columna, si_falta, pen)
#   tipo "NUM"   -> interpolación por tramos entre los cuatro puntos de quiebre
#   tipo "TEXTO" -> búsqueda en la tabla de equivalencias de texto
#   si_falta: BLOQUEA | PENALIZA | OMITE
# ---------------------------------------------------------------------------
CRITERIOS = [
    # ---------------- Técnico (T) ----------------
    ("T1", "Petróleo móvil remanente (So - Sor)", "T", 20, "NUM",
     0.30, 0.20, 0.12, 0.05, "Movil_remanente", "BLOQUEA", 0),
    ("T2", "Relación de movilidad (proxy uo/uw)", "T", 15, "NUM",
     0.8, 2.0, 5.0, 15.0, "__MOVILIDAD__", "PENALIZA", 3),
    ("T3", "Heterogeneidad (Dykstra-Parsons)", "T", 13, "NUM",
     0.45, 0.60, 0.75, 0.90, "V_Dykstra_Parsons", "OMITE", 0),
    ("T4", "Permeabilidad (mD)", "T", 12, "NUM",
     200, 50, 10, 1, "Perm_mD", "PENALIZA", 3),
    ("T5", "Estado de presión (P actual / Pb)", "T", 12, "NUM",
     1.00, 0.85, 0.60, 0.35, "__P_SOBRE_PB__", "PENALIZA", 4),
    ("T6", "Continuidad (net-to-gross)", "T", 10, "NUM",
     0.70, 0.50, 0.30, 0.15, "NTG", "OMITE", 0),
    ("T7", "Espesor neto (m)", "T", 8, "NUM",
     15, 8, 4, 1.5, "Espesor_neto_m", "PENALIZA", 3),
    ("T8", "Porosidad", "T", 5, "NUM",
     0.20, 0.15, 0.10, 0.06, "Porosidad", "PENALIZA", 3),
    ("T9", "Buzamiento (grados)", "T", 5, "NUM",
     12, 6, 2, 0, "Buzamiento_deg", "OMITE", 0),

    # ---------------- Económico (E) ----------------
    ("E1", "Incremental recuperable (Mbbl)", "E", 30, "NUM",
     15000, 6000, 2500, 1000, "__INCREMENTAL__", "BLOQUEA", 0),
    ("E2", "Costo de desarrollo (US$/bbl)", "E", 30, "NUM",
     6, 12, 20, 35, "__COSTO_BBL__", "BLOQUEA", 0),
    ("E3", "VAN al 10% (MM US$)", "E", 20, "NUM",
     60, 20, 5, 0, "__VAN__", "BLOQUEA", 0),
    ("E4", "Payback (años)", "E", 10, "NUM",
     3, 5, 8, 12, "__PAYBACK__", "OMITE", 0),
    ("E5", "Robustez al precio bajo", "E", 10, "NUM",
     1, 1, 0, 0, "__ROBUSTEZ__", "OMITE", 0),

    # ---------------- Ejecutabilidad (X) ----------------
    ("X1", "Disponibilidad de agua", "X", 25, "TEXTO",
     None, None, None, None, "Fuente_agua", "PENALIZA", 0),
    ("X2", "Pozos convertibles / activos", "X", 20, "NUM",
     0.50, 0.30, 0.15, 0.00, "__RATIO_CONV__", "PENALIZA", 2),
    ("X3", "Integridad de pozos verificada (%)", "X", 15, "NUM",
     85, 65, 40, 0, "Integridad_ok_pct", "PENALIZA", 2),
    ("X4", "Infraestructura de superficie", "X", 15, "TEXTO",
     None, None, None, None, "Infraestructura", "PENALIZA", 0),
    ("X5", "Madurez del conocimiento", "X", 15, "NUM",
     0.85, 0.65, 0.45, 0.20, "Completitud_global", "PENALIZA", 2),
    ("X6", "Situación ambiental y social", "X", 10, "TEXTO",
     None, None, None, None, "Restriccion_amb", "PENALIZA", 0),
]

# Equivalencias de texto a puntaje, por criterio
TABLAS_TEXTO = {
    "X1": [("Sí", 10), ("Si", 10), ("Parcial", 5), ("No", 0)],
    "X4": [("Completa", 10), ("Parcial", 5), ("Inexistente", 0)],
    "X6": [("Ninguna", 10), ("Permisos pendientes", 6),
           ("Área protegida", 0), ("Conflicto activo", 0)],
}

# Pesos de los subíndices dentro del IAW (media geométrica ponderada)
PESOS_IAW = [("T", 0.40), ("E", 0.35), ("X", 0.25)]

# ---------------------------------------------------------------------------
# Supuestos económicos (semilla)
# (nombre_rango, etiqueta, valor, unidad, descripción)
# ---------------------------------------------------------------------------
SUPUESTOS = [
    ("SECCION", "PRECIOS Y FISCALIDAD", None, None, None),
    ("Precio_Base", "Precio del petróleo — base", 60.0, "US$/bbl",
     "Reemplazar por el precio efectivo que percibe YPFB, incluyendo incentivos."),
    ("Precio_Bajo", "Precio del petróleo — escenario bajo", 40.0, "US$/bbl",
     "Define el criterio E5 de robustez."),
    ("Regalias_Part", "Regalías y participaciones", 0.50, "fracción",
     "18% de regalías más 32% de IDH. Verificar el régimen vigente aplicable."),
    ("Tasa_Descuento", "Tasa de descuento", 0.10, "fracción", ""),
    ("Vida_Proyecto", "Vida del proyecto", 20, "años", ""),

    ("SECCION", "RECUPERACIÓN INCREMENTAL", None, None, None),
    ("Delta_RF", "Incremento de factor de recobro", 0.12, "fracción del OOIP",
     "Valor por defecto cuando no hay analogía ni historia de agua. "
     "PENDIENTE: reemplazar por la analogía con Víbora, Sirari y Yapacaní."),
    ("Rel_Iny_Prod", "Barriles de agua por barril incremental", 4.0, "bbl/bbl",
     "Determina la tasa de inyección de diseño y el opex de manejo de agua."),

    ("SECCION", "COSTOS DE CAPITAL", None, None, None),
    ("C_Conversion", "Conversión de productor a inyector", 350000.0, "US$/pozo",
     "PENDIENTE: costo unitario real de YPFB."),
    ("C_Inyector_Nuevo", "Inyector nuevo", 2500000.0, "US$/pozo",
     "PENDIENTE: costo unitario real de YPFB."),
    ("C_Planta_bpd", "Planta de inyección", 120.0, "US$ por bpd de capacidad",
     "PENDIENTE: costo unitario real de YPFB."),
    ("C_Fijo", "Capex fijo del proyecto", 3000000.0, "US$",
     "Líneas, captación, energía y obras generales."),
    ("Rel_Iny_Pozos", "Inyectores por pozo activo", 0.40, "fracción",
     "Define cuántos inyectores requiere el patrón."),

    ("SECCION", "COSTOS OPERATIVOS", None, None, None),
    ("Opex_Agua", "Manejo de agua", 1.20, "US$/bbl de agua",
     "Inyección más tratamiento del agua producida."),
    ("Opex_Fijo_Pct", "Opex fijo anual", 0.05, "fracción del capex", ""),

    ("SECCION", "UMBRALES DE DECISIÓN", None, None, None),
    ("Umbral_IAW", "IAW de atractivo alto", 55.0, "0 a 100", ""),
    ("Umbral_X", "X de ejecutabilidad alta", 55.0, "0 a 100", ""),
]

# Columnas derivadas que se calculan en el Libro B a partir de la fila de resumen.
# (marcador, etiqueta, unidad, formato)
DERIVADAS = [
    ("__MOVILIDAD__", "Relación de movilidad (uo/uw)", "—", "0.00"),
    ("__P_SOBRE_PB__", "P actual / Pb", "—", "0.00"),
    ("__RATIO_CONV__", "Pozos convertibles / activos", "—", "0.00"),
    ("__INCREMENTAL__", "Incremental recuperable", "Mbbl", "#,##0"),
    ("__INYECTORES__", "Inyectores requeridos", "pozos", "0"),
    ("__CONVERSIONES__", "Conversiones", "pozos", "0"),
    ("__NUEVOS__", "Inyectores nuevos", "pozos", "0"),
    ("__WINY__", "Tasa de inyección de diseño", "bpd", "#,##0"),
    ("__CAPEX__", "Capex total", "MM US$", "#,##0.0"),
    ("__OPEX_ANUAL__", "Opex anual", "MM US$", "#,##0.0"),
    ("__PROD_ANUAL__", "Producción incremental anual", "Mbbl/año", "#,##0.0"),
    ("__FLUJO_ANUAL__", "Flujo de caja anual", "MM US$", "#,##0.0"),
    ("__VAN__", "VAN al 10%", "MM US$", "#,##0.0"),
    ("__VAN_BAJO__", "VAN al precio bajo", "MM US$", "#,##0.0"),
    ("__ROBUSTEZ__", "Robustez al precio bajo", "1/0", "0"),
    ("__COSTO_BBL__", "Costo de desarrollo", "US$/bbl", "#,##0.0"),
    ("__PAYBACK__", "Payback", "años", "0.0"),
]
