"""
Arma un Libro A con el campo sintético ya cargado.

Sirve para que alguien abra un archivo y vea la herramienta funcionando, sin
tener que conseguir datos primero. Los siete reservorios del campo sintético
están construidos para exhibir una firma distinta cada uno, así que sirve
además como material de capacitación: se cambia el reservorio activo en Config
y se ve cómo cambian los gráficos y la interpretación.
"""

import csv
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from openpyxl import load_workbook          # noqa: E402

import construir_libro_a as A               # noqa: E402

RAIZ = Path(__file__).resolve().parent.parent
CSV = RAIZ / "datos" / "ejemplos" / "CAMPO_SINTETICO.csv"
DESTINO = RAIZ / "datos" / "ejemplos" / f"Libro_A_DEMO_CAMPO_SINTETICO_v{A.VERSION}.xlsx"

# Cada reservorio sintético con una nota de qué debería mostrar al abrirlo.
GUIA = {
    "SINT_EXPONENCIAL": "b converge a 0; EUR = 2.386 Mbbl; Chan: SIN AGUA",
    "SINT_HIPERBOLICO": "b = 0,50; Di = 0,30; qi = 800 bpd",
    "SINT_CANALIZACION": "Chan: CANALIZACION (pendiente de WOR' +1,37)",
    "SINT_CONIFICACION": "Chan: CONIFICACION (pendiente de WOR' -3,37)",
    "SINT_NORMAL": "Chan: DESPLAZAMIENTO NORMAL (derivada plana)",
    "SINT_NORMAL_LENTO": "Chan: DESPLAZAMIENTO NORMAL pese a derivada -0,28",
    "SINT_BALANCE_GAS": "p/z corta el eje en OGIP = 120.000 MMpc",
    "SINT_INYECCION": "Hall de pendiente 1.000 e INYECTIVIDAD ESTABLE; "
                      "el IP aparente cae 62,9% siguiendo la declinación. "
                      "Requiere Pi_psi = 2000 en Carga_Estáticos",
}


def main():
    origen = RAIZ / "herramienta" / f"Libro_A_Diagnostico_v{A.VERSION}.xlsx"
    if not origen.exists():
        print("Falta el Libro A. Correr primero construir_libro_a.py")
        return 1

    wb = load_workbook(origen)
    ws = wb["Carga_Producción"]

    def opcional(v):
        return float(v) if v not in (None, "") else None

    filas = []
    with CSV.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            y, m, d = (int(x) for x in r["Fecha"].split("-"))
            filas.append((r["Pozo"], r["Reservorio"], date(y, m, d),
                          float(r["Dias_operados"]), float(r["Qo_bpd"]),
                          float(r["Qw_bpd"]), float(r["Qg_Mpcd"]),
                          opcional(r["Pwf_psi"]), opcional(r.get("Pwh_psi")),
                          opcional(r.get("Winy_bpd")), opcional(r.get("Piny_psi"))))
    filas.sort(key=lambda x: (x[0], x[2]))

    if len(filas) > A.MAX_FILAS:
        print(f"El CSV tiene {len(filas)} filas y el libro admite {A.MAX_FILAS}.")
        return 1

    # Winy y Piny no son opcionales para el demo aunque lo sean para un campo
    # cualquiera: sin ellas SINT_INYECCION no tiene contra qué integrar y el
    # diagnóstico de Hall sale "SIN DATOS DE INYECCIÓN", contradiciendo lo que
    # el propio LÉEME del archivo promete que se va a ver.
    for i, (pozo, res, fecha, dias, qo, qw, qg, pwf, pwh, winy, piny) in \
            enumerate(filas):
        r = A.FIL0 + i
        ws.cell(r, 1, pozo)
        ws.cell(r, 2, res)
        ws.cell(r, 3, fecha).number_format = "DD/MM/YYYY"
        ws.cell(r, 4, dias)
        ws.cell(r, 5, qo)
        ws.cell(r, 6, qw)
        ws.cell(r, 7, qg)
        for col, valor in ((8, pwf), (9, pwh), (10, winy), (11, piny)):
            if valor is not None:
                ws.cell(r, col, valor)

    reservorios = sorted({f[1] for f in filas})
    est = wb["Carga_Estáticos"]
    fila_cab = None
    for rr in range(1, 12):
        if est.cell(rr, 1).value == "Parámetro":
            fila_cab = rr
            break
    columna_de = {}
    for j, nombre in enumerate(reservorios[:A.MAX_RES]):
        est.cell(fila_cab, A.EST_C0 + j, nombre)
        columna_de[nombre] = A.EST_C0 + j

    # Datos estáticos que algunos casos necesitan para que su diagnóstico se
    # pueda calcular. Sin Pi_psi, por ejemplo, la integral de Hall no tiene
    # contra qué integrar y el gráfico sale vacío.
    etiqueta_de = {n: e for n, e, _v, _niv, _d in A.ESTATICOS if n != "SECCION"}
    fila_de = {}
    for rr in range(1, est.max_row + 1):
        v = est.cell(rr, 1).value
        for nombre, etiqueta in etiqueta_de.items():
            if v == etiqueta:
                fila_de[nombre] = rr

    golden = json.loads((RAIZ / "datos" / "ejemplos" / "casos_golden.json")
                        .read_text(encoding="utf-8"))
    for caso in golden:
        for param, valor in (caso.get("estaticos") or {}).items():
            col = columna_de.get(caso["caso"])
            if col and param in fila_de:
                est.cell(fila_de[param], col, valor)

    cfg = wb["Config"]
    for rr in range(1, 60):
        etiqueta = cfg.cell(rr, 1).value
        if etiqueta == "Campo":
            cfg.cell(rr, 2, "CAMPO SINTÉTICO (demostración)")
        elif etiqueta == "Reservorio activo":
            cfg.cell(rr, 2, "SINT_CANALIZACION")
        elif etiqueta == "Analista":
            cfg.cell(rr, 2, "—")

    # Guía de lectura dentro del propio archivo
    leeme = wb["LÉEME"]
    f = leeme.max_row + 3
    leeme.cell(f, 1, "QUÉ ESPERAR DE ESTE DEMO").font = A.Font(bold=True, size=12)
    f += 1
    leeme.cell(f, 1, "Cambiar el reservorio activo en Config > B5 y observar "
                     "cómo cambia el Diagnóstico:").font = A.F_NOTA
    f += 1
    for nombre in reservorios:
        leeme.cell(f, 1, nombre).font = A.F_CAB
        leeme.cell(f, 2, GUIA.get(nombre, ""))
        f += 1

    wb.save(DESTINO)
    mb = DESTINO.stat().st_size / 1024 / 1024
    print(f"Demo -> {DESTINO.relative_to(RAIZ)}  ({mb:.1f} MB)")
    print(f"  {len(filas):,} filas de producción, {len(reservorios)} reservorios")
    print(f"  reservorio activo al abrir: SINT_CANALIZACION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
