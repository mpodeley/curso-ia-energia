"""
Las tres tablas del recorrido en vivo del caso, para proyectar.

Contesta, sobre datos públicos del Capítulo IV, la pregunta con la que arrancó
el caso: dónde hay waterflooding en el norte argentino. La respuesta corta es
que no hay, y las tablas muestran por qué.

    python construccion/resumen_cuenca.py
"""

import csv
import json
import collections
from pathlib import Path

CACHE = Path.home() / "Projects" / "activos" / "curso-ia-energia" / "scripts" / "_cache"
MENSUAL = CACHE / "capiv_noroeste_oil_monthly.csv"
POZOS = CACHE / "capiv_noroeste_oil_wells.json"

M3_A_BBL = 6.28981


def miles(x, dec=0):
    return f"{x:,.{dec}f}"


def main() -> int:
    W = json.loads(POZOS.read_text(encoding="utf-8"))
    filas = list(csv.DictReader(MENSUAL.open(encoding="utf-8")))

    meses = sorted({r["ym"] for r in filas})
    print()
    print("=" * 74)
    print("  CUENCA NOROESTE — CAPÍTULO IV, SECRETARÍA DE ENERGÍA DE ARGENTINA")
    print("=" * 74)
    print(f"  {len(W):,} pozos · {len(filas):,} registros mensuales · "
          f"{meses[0]} a {meses[-1]}")

    # --- 1. Quién inyecta -------------------------------------------------
    vol = collections.defaultdict(float)
    pz = collections.defaultdict(set)
    for r in filas:
        ia = float(r["iny_agua"])
        if ia <= 0:
            continue
        t = W[r["idpozo"]].get("tipopozo") or "sin clasificar"
        vol[t] += ia
        pz[t].add(r["idpozo"])
    total = sum(vol.values())

    print()
    print("  1. QUIÉN INYECTA AGUA, Y PARA QUÉ")
    print(f"  {'tipo de pozo':<24}{'pozos':>7}{'m3 inyectados':>18}{'share':>9}")
    print("  " + "-" * 58)
    for t, v in sorted(vol.items(), key=lambda kv: -kv[1]):
        print(f"  {t:<24}{len(pz[t]):>7}{miles(v):>18}{v / total:>8.1%}")
    print("  " + "-" * 58)
    print(f"  {'TOTAL':<24}{sum(len(s) for s in pz.values()):>7}{miles(total):>18}")
    print()
    print("  Sumidero = disposición del agua que sale con el petróleo, en una")
    print("  formación que no produce. No es recuperación secundaria.")

    # --- 2. Dónde está el único inyector ----------------------------------
    print()
    print("  2. LOS POZOS DECLARADOS COMO INYECCIÓN DE AGUA")
    print(f"  {'pozo':<18}{'yacimiento':<26}{'m3 inyectados':>15}   estado")
    print("  " + "-" * 74)
    declarados = [(i, w) for i, w in W.items()
                  if w.get("tipopozo") == "Inyección de Agua"]
    porpozo_iny = collections.defaultdict(float)
    for r in filas:
        porpozo_iny[r["idpozo"]] += float(r["iny_agua"])
    for idp, w in sorted(declarados, key=lambda kv: -porpozo_iny[kv[0]]):
        v = porpozo_iny[idp]
        print(f"  {w['sigla'][:17]:<18}{w['yacimiento'][:25]:<26}{miles(v):>15}"
              f"   {w['tipoestado']}")
    print("  " + "-" * 74)
    vivos = sum(1 for i, _ in declarados if porpozo_iny[i] > 0)
    print(f"  {len(declarados)} pozos declarados, {vivos} inyectó algo en "
          f"{len(meses)} meses.")

    # --- 3. El campo del caso ---------------------------------------------
    yac = "PUESTO GUARDIAN"
    delyac = {k for k, v in W.items() if v.get("yacimiento") == yac}
    sub = [r for r in filas if r["idpozo"] in delyac]
    print()
    print(f"  3. EL CAMPO DEL CASO — {yac}")
    print(f"  {'pozo':<18}{'tipo':<20}{'estado':<26}{'bbl/d medio':>12}")
    print("  " + "-" * 74)
    porpozo = collections.defaultdict(lambda: [0.0, 0.0, 0])
    for r in sub:
        d = porpozo[r["idpozo"]]
        d[0] += float(r["prod_pet"])
        d[1] += float(r["iny_agua"])
        d[2] += 1
    orden = sorted(porpozo.items(), key=lambda kv: -(kv[1][0] + kv[1][1]))
    for idp, (pet, iny, n) in orden:
        if pet == 0 and iny == 0:
            continue
        w = W[idp]
        cual = pet if pet > 0 else iny
        signo = "" if pet > 0 else "iny "
        print(f"  {w['sigla'][:17]:<18}{w['tipopozo']:<20}{w['tipoestado'][:25]:<26}"
              f"{signo + miles(cual * M3_A_BBL / (n * 30.4375), 1):>12}")
    ult = max(r["ym"] for r in sub)
    print("  " + "-" * 74)
    print(f"  Última información del campo: {ult}. El resto de la cuenca llega "
          f"a {meses[-1]}.")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
