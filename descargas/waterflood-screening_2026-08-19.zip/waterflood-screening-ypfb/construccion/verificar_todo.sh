#!/usr/bin/env bash
# Regenera los libros y corre las cuatro capas de verificación.
#
#   1. El método recupera respuestas analíticas conocidas   (Python de referencia)
#   2. Los libros abren y calculan                          (validación estática)
#   3. Las fórmulas del Libro A dan los números correctos    (motor de Excel)
#   4. Las fórmulas del Libro B dan los números correctos    (motor de Excel)
#
# Las capas 3 y 4 son lentas —evalúan el grafo completo de dependencias— pero
# son las únicas que cierran el hueco entre "el método es correcto" y "las
# fórmulas implementan ese método".
set -euo pipefail
cd "$(dirname "$0")/.."
PY=construccion/.venv/bin/python

echo "### 1/6  Datos sintéticos"
$PY construccion/generar_datos_sinteticos.py

echo; echo "### 2/6  El método contra los casos golden"
$PY construccion/referencia_diagnosticos.py

echo; echo "### 3/6  Construcción de los libros"
$PY construccion/construir_libro_a.py
$PY construccion/construir_libro_b.py

echo; echo "### 4/6  Validación estática (compatibilidad y sintaxis)"
$PY construccion/verificar_libros.py

echo; echo "### 5/6  Verificación numérica del Libro A"
$PY construccion/verificar_numerico.py 2>&1 | grep -v "it/s]" || true

echo; echo "### 6/6  Verificación numérica del Libro B"
$PY construccion/verificar_numerico_b.py 2>&1 | grep -v "it/s]" || true

echo; echo "### Demo"
$PY construccion/preparar_demo.py
