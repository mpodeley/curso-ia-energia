"""
Genera los casos golden: reservorios sintéticos con respuesta analítica conocida.

Sirven para dos cosas:
  1. Validar las fórmulas del Libro A contra un resultado que se conoce de antemano.
  2. Poblar la hoja `Pruebas` con valores esperados y tolerancias.

Cada caso está construido para producir una firma inequívoca. Si el libro no la
reconoce, el libro está mal — no el dato.

Salida: datos/ejemplos/CAMPO_SINTETICO.csv  +  datos/ejemplos/casos_golden.json
"""

import csv
import json
import math
from datetime import date
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
SALIDA = RAIZ / "datos" / "ejemplos"
SALIDA.mkdir(parents=True, exist_ok=True)

DIAS_MES = 30.4375          # promedio, consistente en todo el proyecto
MESES_ANIO = 12.0


def meses(inicio_anio, n):
    """Serie de fechas mensuales (primer día del mes)."""
    out = []
    for i in range(n):
        anio = inicio_anio + i // 12
        mes = i % 12 + 1
        out.append(date(anio, mes, 1))
    return out


# ---------------------------------------------------------------------------
# Caso 1 — Declinación exponencial pura, sin agua
# ---------------------------------------------------------------------------
# q(t) = qi * exp(-D*t),  t en años
# Np(t) = (qi - q(t)) / D   [en bbl/año -> se convierte]
# EUR al límite económico q_lim:  Np = (qi - q_lim) / D
def caso_exponencial():
    qi, D, n = 1000.0, 0.15, 240          # 20 años
    q_lim = 20.0
    filas = []
    for i, f in enumerate(meses(1995, n)):
        t = i / MESES_ANIO
        qo = qi * math.exp(-D * t)
        filas.append(dict(
            Pozo="SINT-EXP-1", Reservorio="SINT_EXPONENCIAL", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qo, 3),
            Qw_bpd=0.0, Qg_Mpcd=round(qo * 0.5, 3),
            Pwf_psi="", Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    # EUR analítica en Mbbl: (qi - q_lim)/D  [bbl/d / (1/año)] * 365.25 d/año / 1000
    eur_mbbl = (qi - q_lim) / D * 365.25 / 1000.0
    return filas, {
        "caso": "SINT_EXPONENCIAL",
        "descripcion": "Declinación exponencial pura, sin producción de agua",
        "esperado": {
            "D_anual": D,
            "b_arps": 0.0,
            "EUR_Mbbl": round(eur_mbbl, 1),
            "clasificacion_chan": "SIN AGUA",
        },
        "tolerancia": {"D_anual": 0.01, "b_arps": 0.10, "EUR_Mbbl": 0.05},
        "por_que": "b debe converger a ~0. Si el ajuste hiperbólico devuelve b alto, "
                   "la grilla de candidatos está mal construida.",
    }


# ---------------------------------------------------------------------------
# Caso 2 — Declinación hiperbólica, b conocido
# ---------------------------------------------------------------------------
# q(t) = qi / (1 + b*Di*t)^(1/b)
def caso_hiperbolico():
    qi, Di, b, n = 800.0, 0.30, 0.50, 300      # 25 años
    filas = []
    for i, f in enumerate(meses(1990, n)):
        t = i / MESES_ANIO
        qo = qi / (1.0 + b * Di * t) ** (1.0 / b)
        filas.append(dict(
            Pozo="SINT-HIP-1", Reservorio="SINT_HIPERBOLICO", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qo, 3),
            Qw_bpd=0.0, Qg_Mpcd=round(qo * 0.4, 3),
            Pwf_psi="", Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    return filas, {
        "caso": "SINT_HIPERBOLICO",
        "descripcion": "Declinación hiperbólica con b = 0,50 exacto",
        "esperado": {"b_arps": b, "Di_anual": Di, "qi_bpd": qi},
        "tolerancia": {"b_arps": 0.05, "Di_anual": 0.05, "qi_bpd": 0.05},
        "por_que": "Verifica que la grilla de b (paso 0,05) encuentra el óptimo real. "
                   "b=0,50 cae justo sobre un nodo de la grilla.",
    }


# ---------------------------------------------------------------------------
# Caso 3 — Canalización (firma de Chan)
# ---------------------------------------------------------------------------
# WOR ~ t^m con m alto (~1,8): sube abrupto y sigue subiendo.
# WOR' = dWOR/dt ~ t^(m-1)  -> pendiente POSITIVA en log-log.
def caso_canalizacion():
    qi, D, n = 600.0, 0.10, 240
    t0 = 3.0            # años hasta la irrupción de agua
    m = 1.8
    k = 0.35
    filas = []
    for i, f in enumerate(meses(1998, n)):
        t = i / MESES_ANIO
        ql = qi * math.exp(-D * t)          # líquido total declina suave
        if t <= t0:
            wor = 0.02
        else:
            wor = 0.02 + k * (t - t0) ** m
        fw = wor / (1.0 + wor)
        qo, qw = ql * (1 - fw), ql * fw
        filas.append(dict(
            Pozo="SINT-CAN-1", Reservorio="SINT_CANALIZACION", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qo, 3),
            Qw_bpd=round(qw, 3), Qg_Mpcd=round(qo * 0.6, 3),
            Pwf_psi="", Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    return filas, {
        "caso": "SINT_CANALIZACION",
        "descripcion": "WOR ~ t^1,8 tras irrupción al año 3. Firma de canalización.",
        "esperado": {
            "clasificacion_chan": "CANALIZACION",
            "pendiente_WOR_loglog": m,
            "signo_pendiente_WORd": "positiva",
        },
        "tolerancia": {"pendiente_WOR_loglog": 0.30},
        "por_que": "Chan (SPE 30775): canalización = WOR de ascenso abrupto con "
                   "derivada de pendiente positiva. Es el caso que NO debe confundirse "
                   "con conificación, porque la respuesta operativa es opuesta.",
    }


# ---------------------------------------------------------------------------
# Caso 4 — Conificación (firma de Chan)
# ---------------------------------------------------------------------------
# WOR = WORmax * (1 - exp(-(t-t0)/tau)): sube y se aplana.
# WOR' = (WORmax/tau)*exp(-(t-t0)/tau) -> DECRECIENTE, pendiente NEGATIVA.
def caso_conificacion():
    qi, D, n = 500.0, 0.09, 240
    t0, tau, wor_max = 2.0, 2.5, 4.0
    filas = []
    for i, f in enumerate(meses(1996, n)):
        t = i / MESES_ANIO
        ql = qi * math.exp(-D * t)
        if t <= t0:
            wor = 0.02
        else:
            wor = 0.02 + wor_max * (1.0 - math.exp(-(t - t0) / tau))
        fw = wor / (1.0 + wor)
        qo, qw = ql * (1 - fw), ql * fw
        filas.append(dict(
            Pozo="SINT-CON-1", Reservorio="SINT_CONIFICACION", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qo, 3),
            Qw_bpd=round(qw, 3), Qg_Mpcd=round(qo * 0.6, 3),
            Pwf_psi="", Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    return filas, {
        "caso": "SINT_CONIFICACION",
        "descripcion": "WOR asintótico a 4,0 con tau = 2,5 años. Firma de conificación.",
        "esperado": {
            "clasificacion_chan": "CONIFICACION",
            "signo_pendiente_WORd": "negativa",
            "WOR_final": round(0.02 + wor_max * (1 - math.exp(-(20 - t0) / tau)), 2),
        },
        "tolerancia": {"WOR_final": 0.05},
        "por_que": "La derivada decreciente es el discriminante. Si el libro clasifica "
                   "esto como canalización, la ventana de derivada o los umbrales "
                   "de pendiente están mal.",
    }


# ---------------------------------------------------------------------------
# Caso 5 — Desplazamiento normal (firma de Chan)
# ---------------------------------------------------------------------------
# WOR ~ t^m con m ~ 1: ascenso gradual y sostenido, derivada casi plana.
#
# m = 1 es el centro de la banda de desplazamiento normal: si WOR ~ t^m
# entonces WOR' ~ t^(m-1), de modo que m = 1 da derivada constante
# (pendiente log-log nula). Es el punto de referencia contra el cual se miden
# las desviaciones hacia canalización (m > 1) y conificación (WOR asintótico).
def _serie_normal(pozo, reservorio, anio, m, k, n=264):
    qi, D, t0 = 700.0, 0.08, 1.5
    filas = []
    for i, f in enumerate(meses(anio, n)):
        t = i / MESES_ANIO
        ql = qi * math.exp(-D * t)
        wor = 0.02 if t <= t0 else 0.02 + k * (t - t0) ** m
        fw = wor / (1.0 + wor)
        qo, qw = ql * (1 - fw), ql * fw
        filas.append(dict(
            Pozo=pozo, Reservorio=reservorio, Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qo, 3),
            Qw_bpd=round(qw, 3), Qg_Mpcd=round(qo * 0.55, 3),
            Pwf_psi="", Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    return filas


def caso_normal():
    m = 1.0
    filas = _serie_normal("SINT-NOR-1", "SINT_NORMAL", 1994, m=m, k=0.30)
    return filas, {
        "caso": "SINT_NORMAL",
        "descripcion": "WOR ~ t^1,0. Desplazamiento normal canónico, derivada plana.",
        "esperado": {
            "clasificacion_chan": "DESPLAZAMIENTO NORMAL",
            "pendiente_WOR_loglog": m,
        },
        "tolerancia": {"pendiente_WOR_loglog": 0.30},
        "por_que": "Caso de control: el libro no debe encontrar patología donde no la "
                   "hay. Un clasificador que marca todo como canalización pasa el caso "
                   "3 y falla este.",
    }


# ---------------------------------------------------------------------------
# Caso 7 — Desplazamiento normal lento (borde inferior de la banda)
# ---------------------------------------------------------------------------
# WOR ~ t^0,8 -> WOR' ~ t^(-0,2): derivada de pendiente LEVEMENTE negativa.
#
# Este caso existe por un fallo real detectado en la calibración: una pendiente
# negativa leve NO es conificación. La conificación verdadera asintota, y su
# derivada decae exponencialmente dando pendientes del orden de -3. Discriminar
# por el SIGNO de la pendiente confunde ambos casos; hay que discriminar por su
# MAGNITUD. Este caso es el que fija el borde inferior de la banda normal.
def caso_normal_lento():
    m = 0.8
    filas = _serie_normal("SINT-NOL-1", "SINT_NORMAL_LENTO", 1992, m=m, k=0.30)
    return filas, {
        "caso": "SINT_NORMAL_LENTO",
        "descripcion": "WOR ~ t^0,8. Pozo que se inunda despacio; derivada levemente "
                       "negativa pero sin patología.",
        "esperado": {
            "clasificacion_chan": "DESPLAZAMIENTO NORMAL",
            "pendiente_WOR_loglog": m,
        },
        "tolerancia": {"pendiente_WOR_loglog": 0.35},
        "por_que": "Borde inferior de la banda normal. Si el umbral de conificación se "
                   "fija cerca de cero, este caso se clasifica mal y el libro recomienda "
                   "control de conificación en un pozo que no la tiene.",
    }


# ---------------------------------------------------------------------------
# Caso 6 — Balance de materia de gas con OGIP conocido (p/z vs Gp)
# ---------------------------------------------------------------------------
# Reservorio volumétrico de gas: p/z = (pi/zi) * (1 - Gp/G)
# La recta corta el eje Gp exactamente en G.
def caso_balance_gas():
    G = 120_000.0            # MMpc de OGIP
    pi, zi = 4200.0, 0.88
    n = 216
    qg0 = 15_000.0           # Mpcd
    filas = []
    gp_acum = 0.0            # MMpc
    for i, f in enumerate(meses(2000, n)):
        qg = qg0 * math.exp(-0.09 * i / MESES_ANIO)
        gp_acum += qg * DIAS_MES / 1000.0        # Mpcd*d -> Mpc -> MMpc
        p_sobre_z = (pi / zi) * (1.0 - gp_acum / G)
        p = p_sobre_z * zi
        filas.append(dict(
            Pozo="SINT-GAS-1", Reservorio="SINT_BALANCE_GAS", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qg * 0.004, 3),
            Qw_bpd=0.0, Qg_Mpcd=round(qg, 3),
            Pwf_psi=round(p, 1), Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    return filas, {
        "caso": "SINT_BALANCE_GAS",
        "descripcion": "Reservorio volumétrico de gas, OGIP = 120.000 MMpc exacto",
        "esperado": {"OGIP_MMpc": G, "p_sobre_z_inicial": round(pi / zi, 1)},
        "tolerancia": {"OGIP_MMpc": 0.03, "p_sobre_z_inicial": 0.02},
        "por_que": "La extrapolación de p/z al eje Gp debe devolver G exacto. "
                   "Verifica la regresión lineal y el manejo de unidades acumuladas.",
    }


# ---------------------------------------------------------------------------
# Caso 8 — Inyección con gráfico de Hall e IP de pendiente conocida
# ---------------------------------------------------------------------------
# Un inyector a caudal y presión constantes, más un productor cuyo caudal
# declina de forma exponencial con la presión de fondo fija.
#
# Integral de Hall:   incremento mensual = (Piny - Pi) * dias
# Agua inyectada:     incremento mensual = Winy * dias / 1000  [Mbbl]
# => pendiente = 1000 * (Piny - Pi) / Winy,  exacta y constante.
#
# Índice de productividad aparente: IP = Ql / (Pi - Pwf), de modo que su
# variación relativa es exactamente la del caudal, exp(-D*T) - 1.
def caso_inyeccion():
    n = 120
    winy, piny, pi_yac, pwf = 500.0, 2500.0, 2000.0, 1500.0
    qi, D = 400.0, 0.10
    filas = []
    for i, f in enumerate(meses(2005, n)):
        t = i / MESES_ANIO
        # Inyector: no produce
        filas.append(dict(
            Pozo="SINT-INY-1", Reservorio="SINT_INYECCION", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=0.0, Qw_bpd=0.0, Qg_Mpcd=0.0,
            Pwf_psi="", Pwh_psi="", Winy_bpd=winy, Piny_psi=piny, Evento="",
        ))
        # Productor: declina exponencialmente con Pwf constante
        filas.append(dict(
            Pozo="SINT-PRO-1", Reservorio="SINT_INYECCION", Fecha=f,
            Dias_operados=DIAS_MES, Qo_bpd=round(qi * math.exp(-D * t), 6),
            Qw_bpd=0.0, Qg_Mpcd=0.0,
            Pwf_psi=pwf, Pwh_psi="", Winy_bpd="", Piny_psi="", Evento="",
        ))
    pend = 1000.0 * (piny - pi_yac) / winy
    var_ip = math.exp(-D * (n - 1) / MESES_ANIO) - 1.0
    return filas, {
        "caso": "SINT_INYECCION",
        "descripcion": "Inyector a presión y caudal constantes más productor en "
                       "declinación exponencial con Pwf fija.",
        "estaticos": {"Pi_psi": pi_yac},
        "esperado": {
            "Hall_pendiente": pend,
            "Hall_estado": "INYECTIVIDAD ESTABLE",
            "IP_variacion": round(var_ip, 6),
        },
        "tolerancia": {"Hall_pendiente": 0.001, "IP_variacion": 0.005},
        "por_que": "Verifica la integral de Hall, el manejo de unidades entre "
                   "psi-día y Mbbl, y que un inyector sano NO se reporte como "
                   "dañado. También comprueba que el IP aparente siga la "
                   "declinación del caudal cuando la presión de fondo no cambia.",
    }


CASOS = [
    caso_exponencial, caso_hiperbolico, caso_canalizacion,
    caso_conificacion, caso_normal, caso_normal_lento, caso_balance_gas,
    caso_inyeccion,
]

COLUMNAS = ["Pozo", "Reservorio", "Fecha", "Dias_operados", "Qo_bpd", "Qw_bpd",
            "Qg_Mpcd", "Pwf_psi", "Pwh_psi", "Winy_bpd", "Piny_psi", "Evento"]


def main():
    todas, metadatos = [], []
    for fn in CASOS:
        filas, meta = fn()
        todas.extend(filas)
        metadatos.append(meta)

    # ordenado por Pozo y luego Fecha: el Libro A lo exige para los acumulados
    todas.sort(key=lambda r: (r["Pozo"], r["Fecha"]))

    csv_path = SALIDA / "CAMPO_SINTETICO.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNAS)
        w.writeheader()
        for r in todas:
            r = dict(r)
            r["Fecha"] = r["Fecha"].isoformat()
            w.writerow(r)

    json_path = SALIDA / "casos_golden.json"
    json_path.write_text(
        json.dumps(metadatos, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"{len(todas)} filas -> {csv_path.relative_to(RAIZ)}")
    print(f"{len(metadatos)} casos  -> {json_path.relative_to(RAIZ)}")
    for m in metadatos:
        print(f"  · {m['caso']:24s} {m['descripcion']}")


if __name__ == "__main__":
    main()
