"""
Verificación numérica del Libro B.

Evalúa el libro con un motor de fórmulas de Excel y LEE SU PROPIA HOJA `Pruebas`.
No duplica los valores esperados acá: si lo hiciera, habría dos definiciones de
lo correcto y podrían divergir. La hoja Pruebas es la que el ingeniero de YPFB va
a mirar, así que es la que tiene que estar bien.

Además comprueba a mano un puñado de valores que la hoja no puede verificar
sobre sí misma, como que los subíndices de un caso descartado queden vacíos.
"""

import re
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

RAIZ = Path(__file__).resolve().parent.parent
LIBRO = RAIZ / "herramienta" / "Libro_B_Screening_v0.1.xlsx"


def valor(sol, archivo, hoja, coord):
    for clave in (f"'[{archivo}]{hoja.upper()}'!{coord}",
                  f"'[{archivo}]{hoja}'!{coord}"):
        v = sol.get(clave)
        if v is not None:
            try:
                return v.value[0, 0]
            except Exception:
                return v
    return None


def filas_de_prueba(ws):
    """Filas de la hoja `Pruebas`: las que tienen una fórmula OK/FALLA en E.

    Se localizan por su fórmula y no por número de fila para que agregar un caso
    de prueba al libro no obligue a tocar los verificadores. Devuelve
    (filas de caso, fila del resultado global).
    """
    filas = [r for r in range(1, ws.max_row + 1)
             if isinstance(ws.cell(r, 5).value, str)
             and '"OK"' in ws.cell(r, 5).value
             and '"FALLA"' in ws.cell(r, 5).value]
    fila_global = next((r for r in range(1, ws.max_row + 1)
                        if ws.cell(r, 1).value == "RESULTADO GLOBAL"), None)
    return filas, fila_global


def main():
    import formulas
    from openpyxl import load_workbook

    if not LIBRO.exists():
        print(f"No existe {LIBRO}. Correr primero construir_libro_b.py")
        return 1

    wb = load_workbook(LIBRO)
    ws = wb["Pruebas"]
    filas, fila_global = filas_de_prueba(ws)

    print(f"  evaluando {LIBRO.name} ...", flush=True)
    xl = formulas.ExcelModel().loads(str(LIBRO)).finish()
    sol = xl.calculate()
    arch = LIBRO.name

    a = 92
    print("=" * a)
    print("VERIFICACIÓN NUMÉRICA DEL LIBRO B — hoja Pruebas evaluada")
    print("=" * a)
    print(f"  {'Caso':<18}{'Qué verifica':<44}{'Obtenido':>11}{'Esperado':>11}  ")
    print("-" * a)

    fallos = 0
    for r in filas:
        caso = ws.cell(r, 1).value or ""
        que = ws.cell(r, 2).value or ""
        obt = valor(sol, arch, "Pruebas", f"C{r}")
        esp = valor(sol, arch, "Pruebas", f"D{r}")
        res = valor(sol, arch, "Pruebas", f"E{r}")
        res = str(res).strip() if res is not None else "?"

        def fmt(x):
            if isinstance(x, float):
                return f"{x:,.3f}"
            return str(x)[:11]

        if res != "OK":
            fallos += 1
        print(f"  {caso:<18}{que[:43]:<44}{fmt(obt):>11}{fmt(esp):>11}   {res}")

    print("-" * a)
    if fila_global:
        g = valor(sol, arch, "Pruebas", f"C{fila_global}")
        print(f"  Resultado que muestra la propia hoja: {str(g).strip()}")

    # Comprobaciones que la hoja no puede hacer sobre sí misma
    print("\n  Comprobaciones adicionales")
    print("-" * a)
    extras = []
    ws_sco = wb["Scoring"]
    col_iaw = None
    for c in range(1, ws_sco.max_column + 1):
        if ws_sco.cell(2, c).value == "IAW":
            col_iaw = c
            break
    from openpyxl.utils import get_column_letter as CL
    # PRUEBA-K1 está en la primera fila de datos y fue descartado: su IAW debe
    # quedar vacío, no en cero. Cero se leería como "evaluado y pésimo".
    iaw_k1 = valor(sol, arch, "Scoring", f"{CL(col_iaw)}3")
    ok = iaw_k1 in (None, "", 0) or str(iaw_k1).strip() == ""
    extras.append(("IAW de un descartado queda vacío", str(iaw_k1), '""', ok))

    ws_cri = wb["Criterios"]
    for r in range(1, ws_cri.max_row + 1):
        et = ws_cri.cell(r, 2).value
        if isinstance(et, str) and et.startswith("Suma de pesos de "):
            sub = et.replace("Suma de pesos de ", "")
            v = valor(sol, arch, "Criterios", f"D{r}")
            extras.append((f"Pesos del subíndice {sub} suman 100",
                           str(v), "100", abs(float(v or 0) - 100) < 1e-6))

    for etiqueta, obt, esp, ok in extras:
        if not ok:
            fallos += 1
        print(f"  {etiqueta:<62}{obt:>11}{esp:>11}   {'OK' if ok else 'FALLA'}")

    print("\n" + "=" * a)
    print("RESULTADO: TODO OK" if fallos == 0 else f"RESULTADO: {fallos} FALLA(S)")
    print("=" * a)
    return 1 if fallos else 0


if __name__ == "__main__":
    raise SystemExit(main())
