"""
Verificación estática de los libros generados.

Es la prueba de compatibilidad del plan, automatizada. Comprueba cuatro cosas
que, si fallan, rompen el libro en la máquina del usuario y no acá:

  1. Ninguna función posterior a Excel 2016 ni ninguna que exija Ctrl+Shift+Enter.
  2. Paréntesis y comillas balanceados en toda fórmula.
  3. Todo nombre referenciado existe como rango definido.
  4. Ningún rango definido apunta a una hoja inexistente.

No verifica que los números sean correctos: eso lo hacen los casos golden y la
hoja Pruebas. Verifica que el libro ABRA y CALCULE en vez de mostrar #¿NOMBRE?.
"""

import re
import sys
from pathlib import Path

from openpyxl import load_workbook

RAIZ = Path(__file__).resolve().parent.parent

# Funciones que no existen en Excel 2016 perpetuo, o que exigen fórmula matricial.
PROHIBIDAS = {
    "XLOOKUP": "Excel 365/2021. Usar INDEX/MATCH.",
    "XMATCH": "Excel 365/2021. Usar MATCH.",
    "LET": "Excel 365.",
    "LAMBDA": "Excel 365.",
    "FILTER": "Excel 365. Matriz dinámica.",
    "SORT": "Excel 365. Matriz dinámica.",
    "SORTBY": "Excel 365. Matriz dinámica.",
    "UNIQUE": "Excel 365. Matriz dinámica.",
    "SEQUENCE": "Excel 365. Matriz dinámica.",
    "TEXTSPLIT": "Excel 365.",
    "TEXTJOIN": "Excel 2019. Usar concatenación con &.",
    "CONCAT": "Excel 2019. Usar CONCATENATE o &.",
    "IFS": "Excel 2019. Usar IF anidados.",
    "SWITCH": "Excel 2019.",
    "MINIFS": "Excel 2019. Usar columna auxiliar + MIN.",
    "MAXIFS": "Excel 2019. Usar columna auxiliar + MAX.",
    "MAXA": "Ambiguo con texto; evitar.",
}

# Referencia de celda: A1, $B$5, C$6, AA12. El signo $ puede ir en cualquiera
# de las dos posiciones, por eso el token se captura entero y recién después se
# decide si es referencia o nombre. Capturar solo la parte alfabética hacía que
# "C$6" se leyera como un nombre "C" inexistente.
RE_CELDA = re.compile(r"^\$?[A-Z]{1,3}\$?\d+$")
RE_FUNCION = re.compile(r"([A-Z][A-Z0-9\.]*)\s*\(")
RE_IDENT = re.compile(r"(?<![A-Za-z0-9_.!$'])(\$?[A-Za-z_][A-Za-z0-9_.]*(?:\$?\d+)?)")

# Palabras que aparecen en fórmulas y no son nombres definidos
RESERVADAS = {"TRUE", "FALSE", "IF", "AND", "OR", "NOT", "SUM", "SUMPRODUCT",
              "SUMIFS", "COUNTIF", "COUNTIFS", "COUNT", "COUNTA", "AVERAGE",
              "AVERAGEIFS", "MIN", "MAX", "ABS", "LN", "LOG", "EXP", "INDEX",
              "MATCH", "LOOKUP", "VLOOKUP", "HLOOKUP", "IFERROR", "ISNUMBER",
              "ISERROR", "ISBLANK", "TEXT", "VALUE", "N", "DATE", "YEAR",
              "MONTH", "DAY", "EDATE", "INT", "MOD", "ROUND", "SQRT", "PI",
              "CONCATENATE", "LEFT", "RIGHT", "MID", "LEN", "TRIM", "UPPER",
              "LOWER", "SLOPE", "INTERCEPT", "RSQ", "LINEST", "NPV", "IRR",
              "PMT", "POWER", "SIGN", "ROWS", "COLUMNS", "ROW", "COLUMN",
              "INDIRECT", "OFFSET", "CHOOSE", "RANK", "LARGE", "SMALL",
              "PERCENTILE", "STDEV", "MEDIAN", "SUMIF", "AVERAGEIF"}


def balanceado(f):
    """Paréntesis balanceados fuera de literales entre comillas dobles."""
    prof, en_texto, i = 0, False, 0
    while i < len(f):
        ch = f[i]
        if ch == '"':
            if en_texto and i + 1 < len(f) and f[i + 1] == '"':
                i += 2
                continue
            en_texto = not en_texto
        elif not en_texto:
            if ch == "(":
                prof += 1
            elif ch == ")":
                prof -= 1
                if prof < 0:
                    return False, "paréntesis de cierre de más"
        i += 1
    if en_texto:
        return False, "comilla doble sin cerrar"
    if prof != 0:
        return False, f"faltan {prof} paréntesis de cierre"
    return True, ""


def verificar(ruta):
    wb = load_workbook(ruta, data_only=False)
    hojas = set(wb.sheetnames)
    nombres = set(wb.defined_names.keys())
    for ws in wb.worksheets:
        nombres |= set(ws.defined_names.keys())

    problemas = []
    formulas_vistas = 0
    funciones_usadas = set()
    nombres_usados = set()

    for ws in wb.worksheets:
        for fila in ws.iter_rows():
            for celda in fila:
                v = celda.value
                if not isinstance(v, str) or not v.startswith("="):
                    continue
                formulas_vistas += 1
                ubic = f"{ws.title}!{celda.coordinate}"

                ok, motivo = balanceado(v)
                if not ok:
                    problemas.append(("SINTAXIS", ubic, motivo, v[:90]))

                # Los literales de texto se eliminan ANTES de buscar funciones:
                # una interpretación que dice "canalización probable (" contiene
                # la secuencia PROBABLE( y se leería como una llamada a función.
                sin_texto = re.sub(r'"[^"]*"', '""', v)
                # Referencias de hoja, con y sin comillas simples. Las hojas de
                # este proyecto llevan acentos (Diagnóstico, Cálculos,
                # Bibliografía), así que la clase de caracteres los incluye.
                sin_hojas = re.sub(
                    r"(?:'[^']*'|[A-Za-zÁÉÍÓÚÜÑáéíóúüñ_][A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9_.]*)!",
                    "", sin_texto)

                for fn in RE_FUNCION.findall(sin_texto.upper()):
                    funciones_usadas.add(fn)
                    if fn in PROHIBIDAS:
                        problemas.append(
                            ("COMPATIBILIDAD", ubic, f"{fn}: {PROHIBIDAS[fn]}", v[:90]))
                for ident in RE_IDENT.findall(sin_hojas):
                    up = ident.upper()
                    if up in RESERVADAS or RE_CELDA.match(ident.upper()):
                        continue
                    if re.search(rf"\b{re.escape(ident)}\s*\(", sin_hojas):
                        continue
                    nombres_usados.add(ident)
                    if ident not in nombres:
                        problemas.append(
                            ("NOMBRE", ubic, f"'{ident}' no está definido", v[:90]))

    for nombre in wb.defined_names.values():
        destino = nombre.attr_text or ""
        m = re.match(r"^'?([^'!]+)'?!", destino)
        if m and m.group(1) not in hojas:
            problemas.append(
                ("RANGO", nombre.name, f"apunta a la hoja inexistente "
                                       f"'{m.group(1)}'", destino))

    return {
        "ruta": ruta, "hojas": len(hojas), "formulas": formulas_vistas,
        "nombres_def": len(nombres), "nombres_usados": len(nombres_usados),
        "funciones": sorted(funciones_usadas), "problemas": problemas,
    }


def main(rutas):
    total = 0
    for ruta in rutas:
        r = verificar(ruta)
        print("=" * 78)
        print(f"  {Path(r['ruta']).name}")
        print("=" * 78)
        print(f"  hojas {r['hojas']}   fórmulas {r['formulas']:,}   "
              f"nombres definidos {r['nombres_def']}   "
              f"usados {r['nombres_usados']}")
        print(f"  funciones empleadas: {', '.join(r['funciones'])}")

        vistos, dedup = set(), []
        for tipo, ubic, motivo, ctx in r["problemas"]:
            # Se deduplica por hoja, no globalmente: dos errores de sintaxis
            # distintos con el mismo mensaje en hojas distintas son dos errores
            # distintos, y agrupar por mensaje escondía el segundo.
            clave = (tipo, motivo, ubic.split("!")[0])
            if clave in vistos:
                continue
            vistos.add(clave)
            dedup.append((tipo, ubic, motivo, ctx))

        if not dedup:
            print("\n  Sin problemas.\n")
        else:
            n = len(r["problemas"])
            print(f"\n  {n} problema(s), {len(dedup)} distinto(s):\n")
            for tipo, ubic, motivo, ctx in dedup[:40]:
                print(f"  [{tipo:14s}] {ubic:26s} {motivo}")
                print(f"                   {ctx}")
            total += n
    print("=" * 78)
    print("RESULTADO: TODO OK" if total == 0 else f"RESULTADO: {total} problema(s)")
    print("=" * 78)
    return 1 if total else 0


if __name__ == "__main__":
    args = sys.argv[1:] or [str(p) for p in
                            sorted((RAIZ / "herramienta").glob("*.xlsx"))]
    raise SystemExit(main(args))
