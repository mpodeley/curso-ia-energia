# Checklist de recopilación de datos

**Versión 0.1**

Organizado en niveles para que el screening arranque con lo que hay y mejore
incrementalmente. Cada ítem declara **para qué se usa**, **qué habilita**, **qué pasa si
falta** y **quién es el dueño del dato** dentro de YPFB (a completar con los nombres reales
de las gerencias durante el relevamiento).

---

## Hallazgo que ordena todo lo demás

> **El Nivel 1 alcanza para el diagnóstico, pero no para el IAW.**

El Libro A (diagnóstico) funciona solo con historia de producción y presiones: da
declinación, firma de Chan, GOR, VRR e índice de productividad. Es útil por sí mismo.

Pero el IAW no se puede calcular, porque el criterio de **petróleo móvil remanente**
—20% del score técnico y factor eliminatorio K1— exige conocer la saturación actual y
la residual, y eso requiere PVT y petrofísica.

De ahí sale la prioridad de relevamiento: no hace falta el Nivel 2 completo, sino un
**subconjunto mínimo de ocho datos** que desbloquea el índice. Ver §4.

---

## 1. Nivel 1 — Mínimo indispensable

Lo que casi siempre existe en un campo maduro, aunque esté en planillas dispersas.
**Habilita el Libro A completo.**

| # | Dato | Para qué se usa | Habilita | Si falta | Dueño |
|---|---|---|---|---|---|
| 1.1 | Caudal de petróleo mensual por pozo | Declinación de Arps, Np, RF actual | Todo el diagnóstico | **BLOQUEA todo** | Producción |
| 1.2 | Caudal de agua mensual por pozo | WOR, WOR′, corte de agua | Diagnóstico de Chan, extrapolación WOR vs Np | Bloquea el diagnóstico de agua | Producción |
| 1.3 | Caudal de gas mensual por pozo | GOR, mecanismo de empuje | M7, balance de materia | Bloquea balance de materia | Producción |
| 1.4 | Presión de fondo fluyente (Pwf) | Índice de productividad, VRR | Estado de presión, K3, daño | Se usa Pwh con correlación; se marca como estimado | Producción / Reservorios |
| 1.5 | Presión de cabeza (Pwh) | Respaldo de 1.4 | — | Omite | Producción |
| 1.6 | Fechas y tipo de intervenciones | Interpretar quiebres en las curvas | **Evita falsos positivos en Chan** | Penaliza confianza del diagnóstico | Producción / Workover |
| 1.7 | Estado actual de cada pozo | Pozos reutilizables como inyectores | Subíndice X | PENALIZA en X | Producción |
| 1.8 | Coordenadas de pozos | Mapas de burbuja, espaciamiento, diseño de patrón | X, capex de patrón | Omite mapas | Geología / Catastro |
| 1.9 | Topes y bases del reservorio por pozo | Espesor bruto, volumen preliminar | T (espesor), E (volumen) | PENALIZA | Geología |
| 1.10 | Fecha de descubrimiento e inicio de producción | Madurez, contexto de la declinación | Interpretación | Omite | Reservorios |
| 1.11 | Historia de inyección, si existe (Winy, Piny) | Gráfico de Hall, VRR real | Diagnóstico de inyectores | Omite si no hay inyección | Producción |

**Nota sobre 1.6.** Es el dato que más se subestima. Un quiebre en la curva de WOR causado
por un cambio de zona de completación se interpreta como canalización si nadie registró la
intervención. Sin el historial de intervenciones, el diagnóstico de Chan produce
conclusiones erróneas con apariencia de rigor.

---

## 2. Nivel 2 — Habilita la cuantificación

**Habilita el Libro B y el IAW.**

| # | Dato | Para qué se usa | Habilita | Si falta | Dueño |
|---|---|---|---|---|---|
| 2.1 | PVT: Bo, Rs, μo, Pb, densidad | Balance de materia, VRR, relación de movilidad | **K6, M7, criterio de movilidad** | PENALIZA; se puede correlacionar desde °API y T con menor confianza | Reservorios / Laboratorio |
| 2.2 | Porosidad promedio por reservorio | OOIP volumétrico | T (porosidad), E (volumen) | PENALIZA | Petrofísica |
| 2.3 | Permeabilidad promedio | Tasa de inyección alcanzable | T (permeabilidad) | PENALIZA | Petrofísica |
| 2.4 | Saturación de agua inicial (Swi) | OOIP, móvil remanente | **K1** | BLOQUEA el IAW | Petrofísica |
| 2.5 | Espesor neto (net pay) por pozo | OOIP, NTG | T (espesor y NTG) | PENALIZA | Petrofísica |
| 2.6 | Área del reservorio y límites | OOIP volumétrico | **K5, E** | BLOQUEA el IAW | Geología |
| 2.7 | Mapas estructurales e isópacos | Geometría, buzamiento, compartimentación | T (geometría) | OMITE | Geología |
| 2.8 | Presiones de reservorio históricas (build-up, RFT) | Balance de materia, mecanismo de empuje | **K3**, estado de presión | PENALIZA | Reservorios |
| 2.9 | Contactos de fluidos (CAO, CGO) | Volumen del anillo, riesgo de conificación | **K2**, rama condensado | BLOQUEA la rama condensado | Geología |
| 2.10 | Análisis fisicoquímico del agua de formación | Compatibilidad con el agua de inyección | **M4** | PENALIZA | Laboratorio |
| 2.11 | Clasificación del reservorio (petróleo negro / volátil / condensado) | Selecciona la rama metodológica | **K2** | BLOQUEA | Reservorios |

---

## 3. Nivel 3 — Habilita la evaluación fina

Rara vez disponible en campos maduros bolivianos. **No bloquea el screening**: refina y
sube la banda de confianza.

| # | Dato | Para qué se usa | Habilita | Si falta |
|---|---|---|---|---|
| 3.1 | Núcleos: permeabilidades relativas | Relación de movilidad rigurosa | Criterio de movilidad con confianza alta | OMITE; se usa correlación |
| 3.2 | Núcleos: Sor y mojabilidad | Petróleo móvil, techo de recobro | **K1 con confianza alta** | Se estima Sor por correlación, marcado como estimado |
| 3.3 | Pruebas de pozo (build-up) | k·h real, daño, límites del reservorio | Permeabilidad real vs petrofísica | OMITE |
| 3.4 | Registros de saturación (RST / TDT) | So actual medida | **K1 directo, sin balance de materia** | Se usa balance de materia |
| 3.5 | Difracción de rayos X / análisis de arcillas | Contenido de esmectita | **M3** | PENALIZA en X |
| 3.6 | Coeficiente de Dykstra-Parsons por capa | Heterogeneidad cuantificada | Criterio de heterogeneidad | OMITE y renormaliza |
| 3.7 | Trazadores inter-pozo | Conectividad, canalización | **M1 confirmado** | Se infiere de Chan |
| 3.8 | Modelo estático o dinámico | Todo, con confianza alta | Sube la banda de confianza | OMITE |
| 3.9 | Estudio de fuentes de agua | Volumen, calidad, distancia, permisos | **K4, X** | PENALIZA al máximo en X |
| 3.10 | Censo de integridad de pozos | Estado de casing y cemento | **M5** | PENALIZA en X |

---

## 4. Plan de relevamiento priorizado

No se piden 200 datos cuando 8 mueven la decisión.

### 4.1 Prioridad 1 — Los ocho datos que desbloquean el IAW

Si el campo tiene Nivel 1 cargado, **estos ocho ítems son lo único que separa un
diagnóstico de un índice de atractivo**:

| Orden | Dato | Ítem | Por qué es prioritario |
|---|---|---|---|
| 1 | Clasificación del reservorio | 2.11 | Decide la rama metodológica y dispara K2. Sin esto, todo lo demás puede ser trabajo perdido |
| 2 | PVT básico (Bo, Rs, μo, Pb) | 2.1 | Alimenta movilidad, VRR, balance de materia y dos killing factors |
| 3 | Swi | 2.4 | Sin esto no hay móvil remanente ni K1 |
| 4 | Área del reservorio | 2.6 | Sin esto no hay OOIP ni K5 |
| 5 | Porosidad promedio | 2.2 | OOIP |
| 6 | Espesor neto | 2.5 | OOIP y criterio propio |
| 7 | Permeabilidad promedio | 2.3 | Tasa de inyección alcanzable |
| 8 | Contactos de fluidos | 2.9 | Rama condensado; en Bolivia aplica a la mayoría del portafolio |

**Regla de eficiencia:** empezar por el ítem 1 en **todos** los campos antes de profundizar
en ninguno. Dado que buena parte del portafolio boliviano es gas-condensado sin anillo
significativo, clasificar primero permite descartar por K2 y concentrar el esfuerzo de
recopilación en los candidatos reales. Recopilar PVT y petrofísica de un reservorio que va
a morir por K2 es trabajo tirado.

### 4.2 Prioridad 2 — Los que gobiernan la ejecutabilidad

Suelen ser los que frenan proyectos, y no están en ninguna base de datos de reservorios:

| Dato | Ítem | Dónde buscarlo |
|---|---|---|
| Estudio de fuentes de agua | 3.9 | Fuera de Reservorios: hidrogeología, ambiental, operaciones |
| Censo de integridad de pozos | 3.10 | Workover, archivos de pozo |
| Estado de la infraestructura de superficie | — | Facilities / Operaciones |
| Permisos, áreas protegidas, situación social | — | Medio Ambiente y Relaciones Comunitarias |

### 4.3 Prioridad 3 — Refinamiento

Todo el resto del Nivel 3. Se recopila **solo para los campos que ya pasaron a la
shortlist**, no para el portafolio completo.

---

## 5. Cómo registrar lo que no existe

El registro de ausencia es parte del entregable, no una omisión.

Para cada dato faltante se anota:

| Campo | Contenido |
|---|---|
| Estado | `No existe` / `Existe pero no localizado` / `En papel, sin digitalizar` / `Existe en otra gerencia` |
| Esfuerzo estimado de recuperación | Horas o días de trabajo |
| Costo si requiere adquisición nueva | Ej.: un registro de saturación, un análisis PVT |
| Impacto sobre el IAW | Qué criterio queda bloqueado, penalizado u omitido |

Esa tabla es la que justifica el presupuesto de rescate de datos. Sin ella, "faltan datos"
es una queja; con ella, es una solicitud de inversión con retorno identificable.

**La distinción entre "no existe" y "no localizado" es la más importante de todas.** En
campos de los años cincuenta y sesenta suele haber núcleos, análisis PVT y pruebas de pozo
que fueron adquiridos y hoy están en archivo físico, en tesis universitarias, o en informes
de operadores anteriores. Recuperarlos cuesta órdenes de magnitud menos que adquirirlos de
nuevo, y esa diferencia justifica por sí sola dedicarle tiempo a la búsqueda antes de
declarar un dato como inexistente.

---

## 6. Plantilla de carga

La hoja `Carga_Producción` del Libro A espera este formato exacto, una fila por pozo y mes:

| Columna | Formato | Obligatorio | Ejemplo |
|---|---|---|---|
| `Pozo` | Texto | Sí | `CAM-23` |
| `Reservorio` | Texto | Sí | `Yantata` |
| `Fecha` | Fecha (primer día del mes) | Sí | `01/03/1998` |
| `Dias_operados` | Número | No | `28` |
| `Qo_bpd` | Número | Sí | `142,5` |
| `Qw_bpd` | Número | Sí | `38,0` |
| `Qg_Mpcd` | Número | Sí | `210` |
| `Pwf_psi` | Número | No | `1.240` |
| `Pwh_psi` | Número | No | `380` |
| `Winy_bpd` | Número | No | `0` |
| `Piny_psi` | Número | No | `0` |
| `Evento` | Texto | No | `Reacondicionamiento — cambio de zona` |

Reglas:

- **Caudales promedio del mes**, no acumulados. Si la fuente da acumulado mensual, dividir
  por días operados y anotarlo.
- **Celda vacía significa desconocido. Cero significa cero.** No son lo mismo: un pozo
  cerrado tiene `Qo = 0`; un pozo del que se perdió el registro tiene la celda vacía. La
  herramienta los trata distinto y confundirlos deforma la declinación.
- Los eventos van en la fila del mes en que ocurrieron.
- Una fila por pozo y mes, sin filas en blanco intermedias.
