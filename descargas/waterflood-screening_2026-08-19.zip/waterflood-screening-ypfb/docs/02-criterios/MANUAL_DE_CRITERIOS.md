# Manual de criterios de screening de waterflooding

**Versión 0.1 — borrador para taller de calibración con el equipo de reservorios**

Este documento define la metodología. Los valores numéricos viven en la hoja `Criterios`
del Libro B y son editables: **este manual explica el porqué, la hoja contiene el cuánto**.
Todo umbral acá listado es un valor por defecto tomado de la literatura, a calibrar contra
la experiencia boliviana en el taller de la Semana 8.

---

## 1. Estructura general

El screening es una secuencia de tres compuertas. Un reservorio solo llega a la siguiente
si sobrevive la anterior.

```
                  ┌──────────────────────────────────────┐
  Reservorio ───► │ COMPUERTA 0 — Killing factors        │
                  │ ¿Hay algo que lo mate de entrada?    │
                  └──────────┬───────────────┬───────────┘
                    duro     │               │ sobrevive
                             ▼               ▼
                     DESCARTADO      ┌──────────────────────┐
                    (con motivo      │ COMPUERTA 1 — Score  │
                     registrado)     │ técnico (T)          │
                                     └──────────┬───────────┘
                                                ▼
                                     ┌──────────────────────┐
                                     │ COMPUERTA 2 — Score  │
                                     │ económico (E)        │
                                     └──────────┬───────────┘
                                                ▼
                                   Ejecutabilidad (X) ──► IAW
                                                ▼
                                       Matriz de decisión
```

Un descarte **no borra el reservorio**: lo deja en la lista con el motivo registrado. Si
mañana cambia el precio, aparece una fuente de agua o se recupera información, se revisa.

---

## 2. Compuerta 0 — Killing factors

### 2.1 Duros (K) — descartan

Cada factor descarta por sí solo. La columna *Dato requerido* indica de dónde sale, y
*Si falta* qué hacer cuando no se tiene el dato.

| # | Factor | Umbral por defecto | Dato requerido | Si falta |
|---|--------|--------------------|----------------|----------|
| **K1** | Sin petróleo móvil remanente | `So_actual − Sor < 0,05` **o** `RF_actual > 0,95 × RF_últ_esperado` | So de balance de materia o registros de saturación; Sor de núcleos o correlación | **BLOQUEA** — sin esto no hay screening posible |
| **K2** | Gas-condensado sin anillo de petróleo | Espesor de anillo `< 3 m` **o** volumen del anillo `< 5%` del HCPV total **o** ausencia de fase líquida móvil en el reservorio (solo condensado retrógrado) | Contactos CGO/CAO, mapas isópacos, PVT | **BLOQUEA** si el reservorio está clasificado como gas-condensado |
| **K3** | Acuífero activo fuerte ya efectivo | Índice de empuje hidráulico `> 0,60` **y** presión actual `> 85%` de la inicial con `RF > 25%` | Balance de materia, historia de presión | No descarta; marca M-flag de revisión |
| **K4** | Sin fuente de agua viable | No existe fuente que cubra `1,1 × tasa de vaciamiento objetivo` a distancia y capex razonables | Estudio de fuentes: acuíferos someros, agua producida, superficial | **PENALIZA** al máximo en X — desconocer la fuente de agua es en sí un riesgo mayor |
| **K5** | OOIP bajo el umbral económico | Incremental esperado `OOIP × ΔRF < 1,5 MMbbl` (parametrizable) | OOIP volumétrico o de balance de materia | **BLOQUEA** |
| **K6** | Viscosidad excesiva | `μo > 200 cP` a condiciones de reservorio **o** `M > 15` | PVT o correlación desde °API y temperatura | **PENALIZA** con el peor tramo |

**Nota sobre K3.** Es el killing factor que más discusión genera y por eso *no* descarta
automáticamente: un acuífero que sostiene presión puede estar barriendo mal, y una
inyección periférica que complemente el empuje natural puede seguir teniendo sentido. Se
marca para revisión manual en vez de matarlo.

**Nota sobre K6.** El límite real no es la viscosidad sino la relación de movilidad. Un
petróleo de 150 cP en un reservorio de alta permeabilidad con agua salina viscosa puede ser
mejor candidato que uno de 80 cP en roca apretada. Por eso el criterio es `μo` **o** `M`, y
`M` manda cuando está disponible.

### 2.2 Mitigables (M) — penalizan y disparan un estudio

No descartan. Restan puntos en el subíndice correspondiente y generan una línea en la
sección "Estudios requeridos" de la ficha del reservorio.

| # | Bandera roja | Umbral por defecto | Penalización | Estudio que dispara |
|---|--------------|--------------------|--------------|---------------------|
| **M1** | Fracturamiento severo o fallas conductivas | Pérdida total de circulación documentada, **o** irrupción de agua en `< 10%` del VP inyectado en pozos vecinos | −20% sobre T | Trazadores inter-pozo, control de conformancia, rediseño de patrón |
| **M2** | Casquete de gas primario grande | `m = V_gas / V_petróleo > 0,30` | −15% sobre T | Ubicación y secuencia de inyección; riesgo de migración de petróleo al casquete |
| **M3** | Arcillas hinchables | Esmectita `> 10%` del volumen de arcilla, o sensibilidad al agua demostrada en laboratorio | −15% sobre X | Compatibilidad agua-roca, ajuste de salinidad de inyección, ensayos de flujo en núcleo |
| **M4** | Anhidrita, yeso o riesgo de incrustación | Presencia `> 5%`, **o** agua de formación con Ba/Sr altos frente a agua de inyección con sulfatos | −10% sobre X | Modelado de compatibilidad de aguas, programa de inhibidores |
| **M5** | Integridad de pozos comprometida | `> 40%` de los pozos con falla de integridad conocida | −25% sobre X | Censo de integridad; comparación de costo de reacondicionamiento vs pozos nuevos |
| **M6** | Heterogeneidad alta | Dykstra-Parsons `V > 0,75` | −20% sobre T | Caracterización de capas, evaluación de inyección selectiva |
| **M7** | Presión muy por debajo de la de burbuja | `P_actual < 0,70 × Pb` con `Sg > 0,15` | −15% sobre E | Cálculo de volumen y tiempo de rellenado; impacto sobre el momento de la respuesta |
| **M8** | Acceso, permisos o licencia social | Área protegida, conflicto activo, o sin acceso vial | −20% sobre X | Relevamiento socioambiental temprano — **no diferirlo al FEED** |

**Sobre M7 y el rellenado.** Cuando la presión cayó bien por debajo de la de burbuja hay
gas libre en el reservorio. Antes de que el banco de petróleo responda hay que reponer ese
volumen (*fill-up*), lo que consume agua e inversión durante meses o años sin producción
incremental. No es un impedimento técnico: es un corrimiento del flujo de caja que la
economía tiene que reflejar. Un matiz que conviene no perder: una saturación de gas
moderada y atrapada puede **reducir** el Sor y mejorar el recobro final — el problema es el
volumen a reponer, no el gas en sí.

---

## 3. Compuerta 1 — Score técnico (T)

Cada criterio se puntúa de 0 a 10 con una **función de utilidad por tramos con
interpolación lineal**, no con un binario cumple/no cumple. Un valor apenas por debajo del
óptimo no debe valer lo mismo que uno muy malo.

### 3.1 Tabla de puntuación

Los valores intermedios se interpolan linealmente entre los puntos de quiebre.

| Criterio | Peso | 10 puntos | 7 puntos | 4 puntos | 0 puntos | Si falta |
|---|---|---|---|---|---|---|
| Petróleo móvil remanente `So − Sor` | 20% | ≥ 0,30 | 0,20 | 0,12 | ≤ 0,05 | BLOQUEA |
| Relación de movilidad `M` | 15% | ≤ 0,8 | 2 | 5 | ≥ 15 | PENALIZA (3 pts) |
| Heterogeneidad `V` (Dykstra-Parsons) | 13% | ≤ 0,45 | 0,60 | 0,75 | ≥ 0,90 | OMITE |
| Permeabilidad `k` (mD) | 12% | ≥ 200 | 50 | 10 | ≤ 1 | PENALIZA (3 pts) |
| Estado de presión `P/Pb` | 12% | ≥ 1,0 | 0,85 | 0,60 | ≤ 0,35 | PENALIZA (4 pts) |
| Continuidad / net-to-gross | 10% | ≥ 0,70 | 0,50 | 0,30 | ≤ 0,15 | OMITE |
| Espesor neto (m) | 8% | ≥ 15 | 8 | 4 | ≤ 1,5 | PENALIZA (3 pts) |
| Porosidad `φ` | 5% | ≥ 0,20 | 0,15 | 0,10 | ≤ 0,06 | PENALIZA (3 pts) |
| Geometría y buzamiento | 5% | Buzamiento > 10° con posibilidad de inyección buzamiento abajo | Buzamiento moderado | Estructura plana | Geometría desfavorable o compartimentada | OMITE |

`T = Σ(puntaje × peso) × 10`, escalado a 0–100, y luego se aplican las penalizaciones M
que correspondan.

### 3.2 Por qué estos criterios y no otros

Los nueve criterios cubren los tres términos del factor de recobro por inyección:

```
RF_waterflood  =  E_desplazamiento  ×  E_areal  ×  E_vertical
                        │                  │            │
              móvil remanente,      movilidad,    heterogeneidad,
              movilidad             geometría,    NTG, espesor
                                    patrón
```

Todo lo que no entra en alguno de esos tres términos —o en el costo de conseguirlos— no es
criterio de screening: es detalle de factibilidad.

---

## 4. Compuerta 2 — Score económico (E)

Cálculo preliminar clase 5 (±50%). El objetivo no es acertar el VAN sino **ordenar**
candidatos con el mismo criterio.

### 4.1 Estimación del incremental

Tres métodos, en orden de preferencia según los datos disponibles:

1. **Analogía con campos bolivianos ya inyectados** — Víbora, Sirari, Yapacaní. Es el
   método más confiable acá, porque comparte cuenca, tipo de roca y prácticas operativas.
   Requiere construir la tabla de analogías como parte del dossier (E1).
2. **Extrapolación de WOR vs Np** al corte de agua económico, cuando ya hay historia de
   producción de agua suficiente.
3. **Correlación de factor de recobro** en función de movilidad, heterogeneidad y volumen
   poral inyectado, cuando no hay ni analogía ni historia de agua.

El método usado se registra en la ficha. Un incremental por correlación y uno por analogía
**no son comparables sin decirlo**.

### 4.2 Puntuación económica

| Criterio | Peso | 10 puntos | 7 puntos | 4 puntos | 0 puntos |
|---|---|---|---|---|---|
| Incremental recuperable (MMbbl) | 30% | ≥ 15 | 6 | 2,5 | ≤ 1,0 |
| Costo de desarrollo (US$/bbl incremental) | 30% | ≤ 6 | 12 | 20 | ≥ 35 |
| VAN @ 10% (MM US$) | 20% | ≥ 60 | 20 | 5 | ≤ 0 |
| Payback (años) | 10% | ≤ 3 | 5 | 8 | ≥ 12 |
| Robustez al precio | 10% | VAN > 0 al precio bajo del escenario | — | — | VAN < 0 al precio base |

El **US$/bbl incremental de desarrollo** pesa tanto como el volumen a propósito: en un
portafolio con capital limitado, un campo chico y barato puede ser mejor decisión que uno
grande y caro.

### 4.3 Estructura de costos

| Partida | Base de estimación |
|---|---|
| Conversión de productor a inyector | Costo unitario × número de conversiones |
| Inyectores nuevos | Costo por pozo × cantidad, según patrón y espaciamiento |
| Planta de inyección (bombas, tratamiento) | Función de la tasa de inyección de diseño |
| Líneas de conducción y captación de agua | Función de la distancia a la fuente |
| Tratamiento de agua producida | Función del corte de agua proyectado al final del período |
| Energía | Función de la potencia de bombeo y tarifa |
| Opex incremental de operación y químicos | % del capex o costo unitario por barril de agua manejada |

Todos los costos unitarios viven en la hoja `Supuestos_Económicos` y son editables. Se
cargan con valores placeholder hasta que Ingeniería de YPFB aporte los reales.

---

## 5. Ejecutabilidad (X)

Mide si el proyecto se puede hacer, aparte de si conviene. Es el subíndice que la mayoría
de las metodologías omite y el que más proyectos frena en la práctica.

| Criterio | Peso | 10 puntos | 4 puntos | 0 puntos |
|---|---|---|---|---|
| Disponibilidad y calidad del agua | 25% | Fuente identificada, suficiente, compatible y cercana | Fuente identificada con tratamiento o distancia significativos | Sin fuente identificada |
| Pozos reutilizables / densidad de patrón | 20% | Patrón existente convertible con pocos pozos nuevos | Requiere perforación significativa | Sin infraestructura de pozos utilizable |
| Integridad de pozos | 15% | Censo hecho, mayoría en buen estado | Estado parcialmente conocido | Sin censo, o mayoría comprometida |
| Infraestructura existente | 15% | Energía, facilities y tratamiento disponibles | Requiere ampliación | Campo sin infraestructura |
| Madurez del conocimiento | 15% | Modelo estático o dinámico existente, PVT y núcleos | Solo producción y petrofísica básica | Datos dispersos o en papel |
| Acceso, permisos, licencia social | 10% | Sin restricciones conocidas | Permisos pendientes | Área protegida o conflicto activo |

---

## 6. Índice de Atractivo de Waterflooding (IAW)

### 6.1 Fórmula

Media geométrica ponderada de los tres subíndices:

```
IAW = T^0,40 × E^0,35 × X^0,25
```

En Excel: `=Sub_T^Peso_T * Sub_E^Peso_E * Sub_X^Peso_X`

**Por qué geométrica y no aritmética.** Un promedio aritmético permite que un subíndice
excelente compense uno pésimo. Un reservorio técnicamente ideal sin fuente de agua no es un
proyecto "bueno con un problema": no es un proyecto. La media geométrica castiga el
desbalance y se anula si algún subíndice es cero, que es el comportamiento correcto.

Ejemplo del efecto:

| Caso | T | E | X | IAW aritmético | **IAW geométrico** |
|---|---|---|---|---|---|
| Equilibrado | 70 | 70 | 70 | 70 | **70** |
| Sin agua disponible | 90 | 70 | 20 | 65 | **56** |
| Mediocre parejo | 60 | 60 | 60 | 60 | **60** |

El caso "sin agua" queda por debajo del "mediocre parejo" con la media geométrica, y por
encima con la aritmética. La geométrica ordena mejor.

### 6.2 Los tres subíndices se reportan siempre por separado

El IAW ordena; los subíndices explican. Un campo con T=85 y X=25 requiere una decisión
distinta a uno con T=55 y X=55, aunque el IAW sea parecido: el primero necesita
**desbloquear un cuello de botella**, el segundo necesita **mejor información**.

### 6.3 Completitud de datos

```
Completitud (%) = Σ(pesos de criterios con dato) / Σ(pesos totales) × 100
```

Se calcula por subíndice y global, y **acompaña siempre al IAW**. Un IAW de 72 con 40% de
completitud no es el mismo número que uno con 90%.

Bandas de confianza:

| Completitud | Lectura |
|---|---|
| ≥ 75% | El ranking es defendible |
| 50–75% | Ordenamiento indicativo; verificar antes de comprometer capital |
| < 50% | **No usar para decidir.** Usar para priorizar qué datos recopilar |

---

## 7. Matriz de decisión

Dos ejes: **Atractivo** (combinación de T y E) contra **Ejecutabilidad** (X).

```
        Atractivo
   alto │                      │
        │  DESBLOQUEAR         │  AVANZAR A FACTIBILIDAD (F1)
        │  PRIMERO             │  Prioridad 1
        │  Resolver agua,      │  Presupuestar estudio completo
        │  integridad o datos  │
        │  antes de estudiar   │
   ─────┼──────────────────────┼──────────────────────────────
        │  DESCARTAR           │  CANDIDATO A PILOTO
        │  O DIFERIR           │  Bajo riesgo, bajo premio.
        │  Revisar si cambia   │  Sirve para aprender antes
   bajo │  precio o info       │  de ir a un campo grande
        └──────────────────────┴──────────────────────────────
          bajo                        alto     Ejecutabilidad (X)
```

Umbrales por defecto: **Atractivo alto** si `IAW ≥ 55`; **Ejecutabilidad alta** si `X ≥ 55`.

El cuadrante **candidato a piloto** merece atención especial: un campo modesto pero fácil
de ejecutar tiene un valor que el IAW no captura, que es **generar la experiencia operativa
y los datos** con los que se decide el campo grande. En un portafolio donde YPFB tiene poca
inyección activa, ese valor de aprendizaje es real.

---

## 8. Reglas de dato faltante

Tres modos, declarados criterio por criterio en la hoja `Criterios`:

| Modo | Qué hace | Cuándo se usa |
|---|---|---|
| **BLOQUEA** | El subíndice no se calcula. El reservorio queda *sin evaluar*, no mal evaluado | Datos sin los cuales el screening carece de sentido (móvil remanente, OOIP) |
| **PENALIZA** | Se asigna un puntaje bajo fijo (3 o 4 de 10) | Cuando desconocer el dato **es en sí mismo un riesgo** (fuente de agua, integridad, viscosidad) |
| **OMITE** | Se excluye del promedio y se renormalizan los pesos restantes | Datos de refinamiento que rara vez existen en campos maduros (Dykstra-Parsons, NTG) |

**Lo que nunca se hace:** rellenar con un valor por defecto silencioso. Produce un número
que parece sólido y no lo es — peor que no tener número.

La diferencia entre PENALIZA y OMITE es deliberada y vale la pena entenderla: no saber si
hay agua disponible **es** una mala noticia, porque el proyecto no puede avanzar sin
resolverlo. No conocer el coeficiente de Dykstra-Parsons es simplemente normal en un campo
de los años sesenta, y castigarlo penalizaría a todos los candidatos por igual sin aportar
capacidad de ordenamiento.

---

## 9. Rama de gas-condensado con anillo de petróleo

Los reservorios de condensado con anillo requieren criterios propios porque el objetivo
puede ser el anillo, el casquete, o ambos, y las decisiones se contraponen.

### 9.1 Criterios adicionales

| Criterio | Umbral favorable | Comentario |
|---|---|---|
| Espesor del anillo | > 10 m | Por debajo de 3 m se dispara K2 |
| Relación anillo/casquete `m` | < 3 | Un casquete mucho mayor que el anillo hace que producir el anillo sea marginal frente al gas |
| Distancia a los contactos | Máxima posible | Determina el riesgo de conificación de gas y de agua |
| Movilidad del acuífero de fondo | Baja a moderada | Un acuífero de fondo fuerte compite con la inyección |
| Tipo de pozos disponibles | Horizontales o altamente desviados | Los verticales conifican rápido en anillos delgados |

### 9.2 El conflicto de fondo

En un reservorio con casquete de gas y anillo, **producir el gas primero deprime la presión
y hace migrar el petróleo del anillo al casquete**, donde queda como saturación residual
inalcanzable. Producir el anillo primero preserva el petróleo pero difiere los ingresos del
gas.

Para YPFB esto es especialmente relevante: en un país cuya producción y compromisos
contractuales son fundamentalmente gasíferos, la presión comercial empuja naturalmente a
producir el gas primero. El screening debe **explicitar esa contraposición** en la ficha,
no resolverla — es una decisión de portafolio corporativo, no de ingeniería de reservorios.

### 9.3 Cuándo el anillo no justifica inyección (K2)

- Espesor menor a 3 m: la conificación domina y la eficiencia de barrido vertical colapsa.
- Volumen del anillo menor al 5% del HCPV total: el incremental no paga la infraestructura.
- Solo condensado retrógrado, sin fase líquida móvil en el reservorio: no hay petróleo que
  desplazar. Es el caso de la mayoría de los reservorios gasíferos bolivianos y el motivo
  por el cual **el descarte automático por K2 va a ser el resultado más frecuente del
  screening**. Que sea frecuente no lo hace trivial: documentar por qué un reservorio no es
  candidato tiene valor propio, porque evita que la pregunta se vuelva a abrir cada dos años.

---

## 10. Referencias por criterio

| Criterio | Fuente principal |
|---|---|
| Rangos generales de screening | Taber, Martin & Seright, *EOR Screening Criteria Revisited*, SPE Res. Eng. 12(3), 1997, Partes 1 y 2 |
| Heterogeneidad y recobro | Dykstra & Parsons, *Prediction of Oil Recovery by Waterflood*, JPT 8(11), 1956 |
| Diagnóstico de producción de agua | Chan, *Water Control Diagnostic Plots*, SPE 30775, 1995 |
| Eficiencia de desplazamiento | Buckley & Leverett; ver PetroWiki, *Vertical displacement in a waterflood* |
| Screening en campos maduros | *Screening Criteria for Waterflood Projects in Matured Reservoirs*, SPE Nigeria, 2020 |
| Anillos de petróleo con casquete | *Development strategies of a gas condensate reservoir with a large gas cap, thin oil rim*, Petroleum Science, 2025 |

---

## 11. Pendientes antes de congelar la versión 1.0

1. **Calibrar todos los umbrales** contra la experiencia de Víbora, Sirari y Yapacaní en el
   taller de la Semana 8. Los valores actuales son de literatura internacional.
2. **Construir la tabla de analogías bolivianas** — sin ella el método de estimación
   preferido del §4.1 no se puede aplicar.
3. **Cargar costos unitarios reales** de YPFB en `Supuestos_Económicos`.
4. **Definir el régimen de precios** aplicable (precio interno, incentivos vigentes) para
   el cálculo económico y el escenario de precio bajo.
5. **Validar los pesos** con la prueba ciega descrita en el plan de verificación: si el
   ranking contradice el juicio experto, los pesos están mal, no el experto.
