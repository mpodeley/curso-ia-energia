# Plan de acción, cronograma y presupuesto

**Versión 0.1**

---

## 1. Dónde estamos

El prototipo funcional ya existe. Lo que sigue no es construir la herramienta:
es **calibrarla con datos bolivianos y ponerla en uso**.

| Entregable | Estado |
|---|---|
| Dossier bibliográfico | Borrador completo; **fuentes primarias sin verificar** |
| Manual de criterios | Borrador completo; **umbrales sin calibrar localmente** |
| Checklist de datos | Completo |
| Roadmap de proyecto | Completo |
| Libro A — diagnóstico | **Funcional y verificado numéricamente** |
| Libro B — portafolio | **Funcional y verificado numéricamente** |
| Casos golden | 7 en el Libro A, 9 controles en el Libro B, todos en verde |
| Demo pre-cargado | Disponible |
| Tabla de analogías bolivianas | **No existe** — es el vacío más caro |
| Costos unitarios reales | **No existen** — hay marcadores de posición |
| Prueba en Excel real | **Pendiente** — ver §5 |

El trabajo hecho corresponde, en el cronograma original, a buena parte de F1, F2
y F4. Lo que resta es lo que **no se puede hacer sin YPFB**: datos, calibración y
validación con gente que conoce los campos.

---

## 2. Cronograma

14 semanas. Se acortó respecto de las 18 originales porque la construcción de los
libros ya está hecha.

| Fase | Semanas | Contenido | Entregable |
|---|---|---|---|
| **F1 Verificación de fuentes** | 1–3 | Conseguir los textos originales; verificar cada rango; cerrar el §7 del dossier | Dossier v1.0 |
| **F2 Relevamiento de prueba** | 1–5 | Cargar 2 campos reales en el Libro A; medir qué datos existen de verdad | Informe de disponibilidad de datos |
| **F3 Tabla de analogías** | 3–7 | Documentar Víbora, Sirari y Yapacaní: ΔRF, VRR, tiempo de respuesta, costos reales | Tabla de analogías |
| **F4 Calibración de criterios** | 6–9 | Taller con reservorios; ajustar umbrales y pesos; correr las Pruebas | `Criterios` v1.0 congelada |
| **F5 Economía real** | 7–10 | Costos unitarios de YPFB; régimen de precios e incentivos | `Supuestos_Económicos` v1.0 |
| **F6 Corrida del portafolio** | 9–12 | Cargar todos los reservorios; generar ranking y fichas | Ranking del portafolio |
| **F7 Validación y transferencia** | 11–14 | Prueba ciega, prueba de usabilidad, capacitación | Informe de validación |

### Hitos de decisión

| Semana | Hito | Qué pasa si no se cumple |
|---|---|---|
| **5** | Se sabe qué datos existen realmente | Si ni el Nivel 1 está disponible, **el proyecto se reordena hacia rescate de datos** antes de seguir |
| **7** | Tabla de analogías construida | Sin ella la economía queda con parámetros de literatura y la banda de confianza baja |
| **9** | Criterios calibrados y congelados | No se puede correr el portafolio con umbrales sin calibrar |
| **12** | Ranking del portafolio disponible | — |
| **14** | Validación cerrada | Si el ranking contradice el juicio experto sin explicación, **se recalibra antes de liberar** |

### Camino crítico

```
F2 relevamiento ──► F3 analogías ──► F4 calibración ──► F6 portafolio ──► F7 validación
   (sem 5)            (sem 7)          (sem 9)           (sem 12)          (sem 14)
```

F1 y F5 corren en paralelo y no están en el camino crítico. **El cuello de
botella real es el acceso a los datos históricos de los campos ya inyectados**,
que depende de gerencias distintas a Reservorios.

---

## 3. Equipo

| Rol | Dedicación | Cuándo | Para qué |
|---|---|---|---|
| Ingeniero de reservorios senior | 0,5 FTE | F1–F7 | Calibración, validación, criterio técnico |
| Ingeniero junior / analista | 0,6 FTE | F2–F6 | Relevamiento, carga, corrida del portafolio |
| Geólogo | 0,2 FTE | F2–F4 | Volumetría, contactos, clasificación de reservorios |
| Ingeniero de facilities y agua | 0,2 FTE | F5 | Costos unitarios, fuentes de agua |
| Especialista en Excel | 0,2 FTE | F4–F6 | Ajustes a los libros, soporte |
| Gestión de proyecto | 0,15 FTE | F1–F7 | Coordinación entre gerencias |

**≈ 6,5 FTE-mes.**

> El rol de gestión de proyecto parece menor y no lo es. Buena parte del camino
> crítico consiste en conseguir datos que están en otras gerencias —archivo,
> workover, medio ambiente, facilities—, y eso no se resuelve desde Reservorios.

---

## 4. Presupuesto preliminar

> **Estimación clase 5 (±50%)**, en órdenes de magnitud, para dimensionar la
> decisión. Las tarifas locales de YPFB reemplazan estos valores en la primera
> revisión. **El desglose por partida es la parte útil; los montos son
> referenciales.**

### 4.1 Completar el proyecto (14 semanas)

| Partida | Interno | Con apoyo externo |
|---|---|---|
| Personal técnico (≈ 6,5 FTE-mes) | 50–85 k US$ | 50–85 k US$ |
| Consultoría de calibración y validación | — | 40–90 k US$ |
| Rescate y digitalización de datos | 15–40 k US$ | 15–40 k US$ |
| Talleres, viajes a campo, capacitación | 10–20 k US$ | 10–20 k US$ |
| Licencias Office e infraestructura | 2–5 k US$ | 2–5 k US$ |
| **Total indicativo** | **77–150 k US$** | **117–240 k US$** |

### 4.2 Órdenes de magnitud de lo que viene después

Para decidir el screening sabiendo a qué le abre la puerta:

| Fase | Rango indicativo | Comentario |
|---|---|---|
| F1 Factibilidad, por campo | 150–400 k US$ | Incluye núcleos y PVT, que es donde está el costo |
| F2 Definición / FEED | 0,5–2 MM US$ | Simulación y diseño de facilities |
| F3 Piloto (1–2 patrones) | 5–20 MM US$ | Se justifica salvo analogía directa fuerte |
| F4 Campo completo | 30–150+ MM US$ | Según tamaño y estado de los pozos |

**La relación entre estas cifras es el argumento del proyecto.** Completar el
screening cuesta del orden de 0,1% de lo que cuesta una implementación de campo
completo, y su función es evitar gastar los otros niveles en el campo
equivocado. Con 41 campos en declinación y capital limitado, el costo de ordenar
bien el portafolio es despreciable frente al costo de ordenarlo mal.

---

## 5. Riesgos

| # | Riesgo | Probabilidad | Impacto | Mitigación |
|---|---|---|---|---|
| R1 | **Los datos no existen o están dispersos** | Alta | Alto | F2 arranca en la semana 1 con relevamiento de prueba en 2 campos. Si ni el Nivel 1 aparece, se reordena el proyecto |
| R2 | **No se consigue la información de los campos ya inyectados** | Media | Alto | Sin analogías la economía queda con parámetros genéricos. Escalar temprano por vía de gestión de proyecto |
| R3 | **Los libros fallan en la versión de Excel de YPFB** | Baja | Alto | Ver §5.1 — es la verificación pendiente más importante |
| R4 | El taller de calibración no llega a consenso | Media | Medio | Los umbrales son celdas: se puede correr el ranking con dos juegos y comparar |
| R5 | Buena parte del portafolio muere por K2 | **Alta** | Bajo | Es un resultado válido, no un fracaso. Documentar por qué un reservorio no es candidato tiene valor propio |
| R6 | Cambio de gestión durante el proyecto | Media | Medio | Las compuertas y su evidencia quedan documentadas para que la decisión se audite en vez de reiniciarse |

### 5.1 La verificación pendiente

Los libros fueron verificados en tres capas:

1. **El método recupera respuestas analíticas conocidas** — 7 casos sintéticos.
2. **Los libros abren y calculan** — validación estática: ninguna función
   posterior a Excel 2016, sintaxis correcta, todos los nombres resueltos.
3. **Las fórmulas dan los números correctos** — evaluadas con un motor de Excel:
   `b = 0,50` exacto, `EUR = 2.386,3 Mbbl` contra 2.386,3 analítico,
   `OGIP = 120.000 MMpc` exacto, pendiente de Hall `= 1.000,0` exacta,
   variación del IP `= −62,90%` exacta, las cuatro firmas de Chan bien
   clasificadas, `T = 100,0` y `X = 100,0` exactos en los casos construidos
   para eso.

**Lo que falta: abrirlos en Excel de verdad.** En el entorno de construcción no
había Excel ni LibreOffice, así que la evaluación se hizo con un motor
independiente. Ese motor coincide con Excel en el conjunto de funciones usadas,
pero no es Excel. Quedan sin comprobar:

- Renderizado de los gráficos y ejes logarítmicos
- Comportamiento de las listas desplegables
- Formato condicional
- Protección de hojas
- Tiempo de recálculo con el libro lleno (~103.000 fórmulas en el Libro A)
- Apertura en LibreOffice

**Es la primera tarea de la semana 1**, y usa el archivo demo pre-cargado
(`datos/ejemplos/Libro_A_DEMO_CAMPO_SINTETICO_v0.1.xlsx`): se abre, se comprueba
que el diagnóstico de `SINT_CANALIZACION` diga CANALIZACION, y se recorren los
siete reservorios con la guía que el propio archivo trae en la hoja LÉEME.

---

## 6. Plan de verificación completo

En orden de ejecución:

| # | Prueba | Estado | Cómo se corre |
|---|---|---|---|
| 1 | Casos golden del método | **OK** | `construccion/verificar_todo.sh` |
| 2 | Compatibilidad y sintaxis | **OK** | ídem |
| 3 | Números del Libro A | **OK** | ídem |
| 4 | Números del Libro B | **OK** | ídem |
| 5 | **Apertura en Excel real y en LibreOffice** | **Pendiente** | Abrir el demo; recorrer los 7 reservorios |
| 6 | Datos faltantes | Pendiente | Cargar un campo real solo con Nivel 1 y confirmar que el IAW sale con el % de completitud correcto |
| 7 | **Validación contra Víbora, Sirari o Yapacaní** | Pendiente | La herramienta debería rankearlos alto; si no, los pesos están mal |
| 8 | **Prueba ciega con ingeniero de reservorios** | Pendiente | Un ingeniero ajeno rankea 5 campos; se comparan y se discute cada discrepancia |
| 9 | Usabilidad | Pendiente | Cargar un campo desde cero solo con el manual. Si tarda más de medio día, las hojas de carga necesitan trabajo |

Las pruebas 7 y 8 son las que deciden si la metodología sirve. Las anteriores
solo garantizan que la aritmética está bien, que es una condición necesaria y
claramente insuficiente.

---

## 7. Primeros cinco pasos

1. **Abrir el demo en el Excel que usa YPFB** y confirmar que gráficos,
   desplegables y formato condicional funcionan. Es lo que decide si el diseño
   es viable.
2. **Verificar el alcance del trabajo previo de Beicip-Franlab**, para reutilizar
   en vez de duplicar.
3. **Clasificar todo el portafolio por tipo de reservorio** — un solo dato por
   reservorio. Descarta por K2 lo que no aplica y concentra el esfuerzo de
   recopilación en los candidatos reales. Es la tarea de mejor relación entre
   esfuerzo y decisión de todo el proyecto.
4. **Relevamiento de prueba en 2 campos** para medir qué datos existen.
5. **Empezar la tabla de analogías** con Víbora, Sirari y Yapacaní.

> Los pasos 3 y 5 son los que más mueven la aguja. El 3 evita gastar
> recopilación en reservorios que van a morir por K2; el 5 convierte la economía
> de "parámetros de literatura" a "experiencia boliviana", con datos que ya
> están dentro de la empresa.
