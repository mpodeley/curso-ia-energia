# Dossier de antecedentes bibliográficos

**Versión 0.1**

Base documental de la metodología. Cada criterio del screening apunta acá, y cada
desviación respecto de la literatura queda justificada en el §6.

> **Advertencia de alcance.** Los rangos publicados que se citan son los de uso
> corriente en la industria y se recogen acá como punto de partida. Antes de
> congelar la versión 1.0 hay que **verificar cada valor contra el paper
> original** y sustituir los que no coincidan. El estado actual de esa
> verificación se lleva en el §7.

---

## 1. Criterios de screening publicados

### 1.1 La referencia canónica

**Taber, J.J., Martin, F.D. y Seright, R.S. — *EOR Screening Criteria
Revisited*, SPE Reservoir Engineering 12(3), 1997.** Partes 1 y 2.

Es el trabajo que fijó el formato con el que la industria discute screening: una
tabla de parámetros de reservorio y fluido con rangos de aplicabilidad por
método, construida a partir de proyectos de campo reales y no de teoría.

Tres cosas que conviene tener presentes al usarlo:

1. **Está orientado a recuperación mejorada, no a inyección de agua.** El
   waterflooding aparece como la línea de base contra la cual se comparan los
   demás métodos. Los criterios de waterflooding se derivan por complemento:
   donde el agua funciona, no hace falta nada más.
2. **La Parte 2 incorpora el precio del crudo**, lo que hace explícito algo que
   el screening puramente técnico esconde: un criterio de corte económico no es
   una propiedad del reservorio, es una propiedad del momento.
3. **Los rangos son de aplicabilidad, no de conveniencia.** Que un reservorio
   caiga dentro del rango no lo vuelve buen candidato; solo lo vuelve elegible.
   El ordenamiento por atractivo es una capa aparte, y es la que aporta el IAW.

### 1.2 Clasificación de enfoques de screening

La literatura posterior distingue tres niveles, útiles para ubicar qué estamos
construyendo:

| Enfoque | En qué consiste | Dónde se ubica este proyecto |
|---|---|---|
| **Convencional** | Comparar propiedades promedio contra rangos de validez | El screening del Libro B opera acá |
| **Geológico** | Incorporar heterogeneidad y conectividad detalladas | Corresponde a la Fase 1 de factibilidad |
| **Avanzado** | Minería de datos, aprendizaje automático, mapas multidimensionales | Fuera de alcance; requiere una base de proyectos que Bolivia no tiene todavía |

La decisión de quedarse en el nivel convencional no es una limitación de
ambición: es lo único que los datos disponibles sostienen. Un screening
geológico sobre campos sin modelo estático produce precisión aparente.

### 1.3 Otros criterios recogidos

| Fuente | Aporte |
|---|---|
| *Screening Criteria for Waterflood Projects in Matured Reservoirs: Case Study of a Niger Delta Reservoir*, SPE Nigeria, 2020 | Estructura de compuertas aplicada específicamente a campos maduros, que es el caso boliviano |
| Compilaciones de criterios de EOR del DOE de EE.UU. | Umbrales de referencia y método de puntuación por porcentaje de coincidencia |
| *Enhanced Oil Recovery Screening Criteria: at a Glance*, Int. J. Earth Sci. Knowledge and Applications, 2023 | Tabla comparativa consolidada entre autores |

---

## 2. Ingeniería de waterflooding

### 2.1 La descomposición que ordena todo

El factor de recobro por inyección de agua se descompone en tres eficiencias
multiplicativas:

```
RF_waterflood  =  E_desplazamiento  ×  E_areal  ×  E_vertical
```

Esta descomposición es la que justifica la selección de criterios técnicos del
manual: **si un parámetro no afecta a ninguno de los tres términos, no es
criterio de screening**. Sirve como filtro contra la tentación de agregar
variables porque están disponibles.

| Término | Qué lo gobierna | Criterios del manual |
|---|---|---|
| Desplazamiento | Petróleo móvil (So − Sor), relación de movilidad | T1, T2 |
| Areal | Movilidad, geometría, patrón de pozos | T2, T9 |
| Vertical | Heterogeneidad, continuidad, espesor | T3, T6, T7 |

### 2.2 Relación de movilidad

```
M = (k_rw / μ_w) / (k_ro / μ_o)
```

`M < 1` es favorable: el agua se mueve más lento que el petróleo y el frente
avanza de forma estable. `M > 1` produce digitación viscosa y barrido pobre.

**Limitación importante en la práctica boliviana.** Sin permeabilidades
relativas medidas en núcleo, `M` no se puede calcular. La herramienta usa el
cociente de viscosidades `μ_o / μ_w` como aproximación, lo que **subestima
sistemáticamente el problema** porque ignora el término de permeabilidades
relativas, que casi siempre empeora la relación. Es una aproximación optimista
y está marcada como tal en el manual y en la propia hoja de criterios.

### 2.3 Heterogeneidad

**Dykstra, H. y Parsons, R.L. — *Prediction of Oil Recovery by Waterflood*,
JPT 8(11), 1956.**

Correlación semiempírica que vincula cuatro variables: variación vertical de
permeabilidad `V`, relación de movilidad, saturación inicial de agua y
recuperación fraccional a un WOR dado. Se construyó sobre más de 200 ensayos en
núcleos de reservorios de California, con un modelo de capas lineales sin flujo
cruzado.

Puntos operativos:

- `V` típico entre 0,5 y 0,9 en la mayoría de los reservorios.
- A mayor `V`, menor recuperación, y el efecto es fuerte.
- La correlación se planteó para saturaciones iniciales de petróleo de 45% o más.

**Por qué el criterio T3 está en modo OMITE.** Calcular `V` exige perfiles de
permeabilidad por capa que rara vez existen en campos bolivianos de los años
sesenta. Penalizar su ausencia castigaría a todos los candidatos por igual y no
aportaría capacidad de ordenamiento, que es exactamente lo que el screening
tiene que dar.

### 2.4 Desplazamiento frontal

Buckley-Leverett y la teoría de flujo fraccional sustentan la extrapolación de
`WOR` contra `Np`. La herramienta usa la forma práctica —el tramo recto de
`ln(WOR)` contra `Np`— y no la solución rigurosa, que exige curvas de flujo
fraccional. La solución rigurosa queda explícitamente fuera de alcance (decisión
D-005).

---

## 3. Diagnóstico a partir de datos de producción

### 3.1 Chan — el aporte central

**Chan, K.S. — *Water Control Diagnostic Plots*, SPE 30775, 1995.**

Distingue mecanismos de producción excesiva de agua usando únicamente historia
de producción, graficando `WOR` y su derivada temporal `WOR'` en log-log.

| Firma | Comportamiento del WOR | Comportamiento de WOR' |
|---|---|---|
| Desplazamiento normal | Ascenso gradual y sostenido | Pendiente cercana a cero |
| Canalización | Ascenso abrupto, casi recto | Pendiente **positiva** |
| Conificación | Sube y tiende a una asíntota | Pendiente **negativa** |

**Por qué esto es lo más valioso del Libro A.** La respuesta operativa a cada
firma es opuesta. Ante canalización hay que controlar conformancia —y sobre todo
**no** inyectar más agua, que agravaría el canal—. Ante conificación hay que
revisar completación y caudales, porque el problema es de pozo y no de barrido.
Confundirlas lleva a gastar en la solución equivocada.

**Refinamiento necesario para implementarlo.** El criterio publicado se enuncia
por el signo de la pendiente de `WOR'`, pero el signo por sí solo no discrimina.
Si `WOR ∝ t^m` entonces `WOR' ∝ t^(m-1)`, de modo que la pendiente log-log de la
derivada es simplemente `m − 1`: un pozo que se inunda despacio (`m = 0,8`) da
`−0,2`, negativo y perfectamente sano. La conificación verdadera asintota y su
derivada decae exponencialmente, dando pendientes del orden de `−3`.

**La herramienta discrimina por magnitud, no por signo**, con la banda
`[−1,00 ; +0,25]` para desplazamiento normal. La calibración de esa banda está
documentada en `construccion/referencia_diagnosticos.py` y verificada contra
cuatro firmas sintéticas construidas para ese fin.

### 3.2 Otros diagnósticos implementados

| Método | Referencia | Qué aporta |
|---|---|---|
| Curvas de declinación | Arps, J.J. — *Analysis of Decline Curves*, Trans. AIME 160, 1945 | EUR primaria, reservas remanentes, tiempo al límite económico |
| Gráfico de Hall | Hall, H.N. — *How to Analyze Waterflood Injection Well Performance*, World Oil, 1963 | Salud del inyector: daño contra fractura |
| Balance de materia | Havlena, D. y Odeh, A.S. — *The Material Balance as an Equation of a Straight Line*, JPT, 1963 | OOIP/OGIP independiente del volumétrico; mecanismo de empuje |
| VRR | Práctica corriente de vigilancia | Si el vaciamiento se está reponiendo |

**Sobre Arps y el exponente `b`.** El ajuste hiperbólico exige resolver un
problema no lineal. La herramienta lo resuelve por barrido de `b` en grilla,
evaluando el R² **sobre la escala original de caudal** y no sobre la
transformada. Comparar R² entre distintos `b` sobre escalas transformadas
distintas no es comparar lo mismo, y sesga la selección hacia `b` altos —que a
su vez inflan la EUR—. Es un error frecuente y silencioso.

---

## 4. Gas-condensado con anillo de petróleo

**Fuente principal:** *Development strategies of a gas condensate reservoir with
a large gas cap, thin oil rim, strong bottom water, and natural barriers*,
Petroleum Science, 2025.

Aportes recogidos en la rama metodológica:

- Pozos horizontales o altamente desviados ubicados en el contacto gas-petróleo
  dan mayor rango de control que los verticales, que conifican rápido en anillos
  delgados.
- Conviene desarrollar el anillo a caudales bajos y gradientes de presión
  suaves, y recién después el casquete.
- Los objetivos compiten: prevenir conificación de agua, sostener la presión del
  casquete y maximizar recuperación del anillo no se optimizan juntos.

**El conflicto de fondo, y por qué importa particularmente en Bolivia.**
Producir el gas primero deprime la presión y hace migrar petróleo del anillo al
casquete, donde queda como saturación residual inalcanzable. En un país cuya
producción y cuyos compromisos contractuales son fundamentalmente gasíferos, la
presión comercial empuja de forma natural a producir el gas primero. El
screening **explicita esa contraposición en la ficha pero no la resuelve**: es
una decisión de portafolio corporativo, no de ingeniería de reservorios.

---

## 5. Contexto boliviano

### 5.1 Estado del portafolio

| Dato | Valor | Fuente |
|---|---|---|
| Campos petroleros en operación | 59 | Datos de YPFB citados en prensa especializada, 2019 |
| Campos en declinación | 41 | Ídem |
| Campos con inyección de agua activa | ~6, entre ellos Víbora, Sirari y Yapacaní | Literatura técnica sobre recuperación secundaria en Bolivia |
| Potencial remanente estimado | ~729 MMbbl en al menos 25 campos maduros | Planteo del colegio de ingenieros petroleros recogido en prensa |
| Campos priorizados en el plan de maduros | Camiri, Monteagudo, Tatarenda, Boquerón, Surubí NO | Comunicaciones de YPFB |
| Reservas extraídas en Sararenda (Camiri) | 31% | Prensa especializada |

> Estas cifras provienen de fuentes secundarias y sirven para dimensionar el
> problema, no como base de cálculo. **Deben reemplazarse por los datos oficiales
> de YPFB** antes de usarse en cualquier documento de decisión.

### 5.2 Antecedentes de evaluación

Existe un antecedente de contratación de **Beicip-Franlab** para evaluar campos
con miras a métodos de recuperación mejorada. **Verificar su alcance y sus
entregables es una tarea de la Fase 1 del proyecto**, con dos objetivos: no
duplicar trabajo ya pagado, y reutilizar cualquier caracterización que exista.

### 5.3 Lo que falta y condiciona la calidad del screening

| Vacío | Impacto | Cómo se cierra |
|---|---|---|
| **Tabla de analogías de los campos ya inyectados** | Sin ella, el incremental se estima por correlación genérica en vez de por analogía local, que es el método preferido | Documentar el desempeño de Víbora, Sirari y Yapacaní: ΔRF logrado, VRR, tiempo de respuesta, costos reales |
| Costos unitarios reales | La economía corre con marcadores de posición | Ingeniería de YPFB |
| Régimen de precios e incentivos vigente | Define el corte económico y el escenario bajo | Planificación de YPFB |

**La tabla de analogías es el vacío más caro.** Es el único insumo que
convertiría el módulo económico de "parámetros de literatura" a "experiencia
boliviana", y los datos para construirla ya existen dentro de la empresa.

---

## 6. Rangos adoptados para YPFB

Valores de la versión 0.1 de la hoja `Criterios`, con su justificación.

| Criterio | Rango adoptado (10 → 0 puntos) | Base | Desviación respecto de la literatura |
|---|---|---|---|
| Petróleo móvil (So − Sor) | 0,30 → 0,05 | Práctica corriente | Ninguna |
| Relación de movilidad | 0,8 → 15 | M<1 favorable | **Se usa μo/μw como aproximación** por falta de permeabilidades relativas; es optimista |
| Dykstra-Parsons | 0,45 → 0,90 | Dykstra-Parsons 1956, rango típico 0,5–0,9 | Ninguna |
| Permeabilidad | 200 → 1 mD | Práctica corriente de inyectividad | Ninguna |
| P actual / Pb | 1,00 → 0,35 | Volumen de rellenado | Criterio propio, no estándar en la literatura de screening |
| Net-to-gross | 0,70 → 0,15 | Continuidad de barrido | Criterio propio |
| Espesor neto | 15 → 1,5 m | Práctica corriente | Ninguna |
| Porosidad | 0,20 → 0,06 | Práctica corriente | Ninguna |
| Buzamiento | 12 → 0 grados | Inyección buzamiento abajo | Criterio propio, peso bajo |
| Viscosidad — corte duro K6 | > 200 cP descarta | Límite práctico de movilidad | Se toma el extremo permisivo del rango citado (100–200 cP) para no descartar de más en la primera pasada |
| Anillo de petróleo — K2b | < 3 m descarta | Literatura de anillos delgados | Ninguna |

**Criterios de origen propio.** Cuatro de los nueve criterios técnicos no
provienen de una tabla publicada de screening: estado de presión, net-to-gross,
buzamiento y madurez del conocimiento. Se incorporaron porque afectan
directamente a alguno de los tres términos del factor de recobro, o al costo de
obtenerlo. Están marcados acá para que el taller de calibración los discuta con
atención especial: son los más expuestos a sesgo del autor.

---

## 7. Estado de verificación de fuentes

| Fuente | Citada | Texto original consultado | Rangos verificados |
|---|---|---|---|
| Taber, Martin & Seright 1997, Partes 1 y 2 | Sí | **No** | **No** |
| Dykstra & Parsons 1956 | Sí | **No** | Parcial (rango de V) |
| Chan SPE 30775, 1995 | Sí | **No** | Firmas cualitativas sí; umbrales numéricos son calibración propia |
| Arps 1945 | Sí | No hace falta: formulación estándar | Formulación verificada contra casos analíticos |
| Havlena & Odeh 1963 | Sí | No hace falta: formulación estándar | Verificada contra caso sintético con OGIP conocido |
| Petroleum Science 2025 (anillos) | Sí | **No** | Cualitativo |
| Cifras del portafolio boliviano | Sí | Fuentes secundarias | **No** |

**Tarea pendiente de la Fase 1, semanas 1 a 4:** conseguir los textos originales
de las cinco fuentes marcadas y verificar cada rango. Hasta entonces este dossier
es un mapa de dónde buscar, no una cita verificada. Un umbral que resultó estar
mal transcripto no se nota en el resultado —el ranking sigue saliendo ordenado—
y por eso conviene cerrarlo antes de que alguien tome una decisión con él.

---

## 8. Referencias

1. Taber, J.J., Martin, F.D., Seright, R.S. *EOR Screening Criteria Revisited —
   Part 1: Introduction to Screening Criteria and Enhanced Recovery Field
   Projects.* SPE Reservoir Engineering, 12(3), 189-198, 1997.
2. Taber, J.J., Martin, F.D., Seright, R.S. *EOR Screening Criteria Revisited —
   Part 2: Applications and Impact of Oil Prices.* SPE Reservoir Engineering,
   12(3), 199-205, 1997.
3. Dykstra, H., Parsons, R.L. *Prediction of Oil Recovery by Waterflood — A
   Simplified Graphical Treatment of the Dykstra-Parsons Method.* JPT, 8(11),
   1956.
4. Chan, K.S. *Water Control Diagnostic Plots.* SPE 30775, SPE Annual Technical
   Conference and Exhibition, 1995.
5. Arps, J.J. *Analysis of Decline Curves.* Trans. AIME, 160, 228-247, 1945.
6. Hall, H.N. *How to Analyze Waterflood Injection Well Performance.* World Oil,
   1963.
7. Havlena, D., Odeh, A.S. *The Material Balance as an Equation of a Straight
   Line.* JPT, 1963.
8. *Screening Criteria for Waterflood Projects in Matured Reservoirs: Case Study
   of a Niger Delta Reservoir.* SPE Nigeria Annual International Conference and
   Exhibition, 2020.
9. *Development strategies of a gas condensate reservoir with a large gas cap,
   thin oil rim, strong bottom water, and natural barriers.* Petroleum Science,
   2025.
10. PetroWiki. *Vertical displacement in a waterflood.*
11. AAPG Wiki. *Waterflooding.*
