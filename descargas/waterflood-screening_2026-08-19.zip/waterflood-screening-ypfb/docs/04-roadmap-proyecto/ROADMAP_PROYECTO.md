# De la idea a la implementación: roadmap de un proyecto de waterflooding

**Versión 0.1**

Qué pasa después de que el screening dice "este campo es candidato". Seis fases, cinco
compuertas de decisión, y —lo que más importa— **qué evidencia hace falta en cada compuerta
para poder decir que sí**.

---

## Vista general

| Fase | Nombre | Duración típica | Costo indicativo | Termina en |
|---|---|---|---|---|
| **F0** | Screening de portafolio | 1–3 meses | Parte de este proyecto | ¿Pasa a factibilidad? |
| **F1** | Factibilidad (*Assess*) | 4–8 meses / campo | 150–400 k US$ | **DG1** |
| **F2** | Definición (*Select & Define* / FEED) | 6–12 meses | 0,5–2 MM US$ | **DG2 = FID** |
| **F3** | Piloto | 12–24 meses | 5–20 MM US$ | **DG3** |
| **F4** | Ejecución | 18–36 meses | 30–150+ MM US$ | Puesta en marcha |
| **F5** | Operación y optimización | Continuo | Opex | Revisión anual |

**Tiempo total desde la idea hasta el primer barril incremental: típicamente 4 a 8 años.**
Ese horizonte es en sí mismo un argumento para empezar el screening ahora: en un portafolio
donde 41 de 59 campos están en declinación, cada año de demora en decidir es un año de
declinación adicional que ya no se recupera.

---

## F0 — Screening de portafolio

**Objetivo.** Ordenar el portafolio completo con un criterio único y trazable, y descartar
con motivo registrado lo que no da.

**Entregables.** Ranking con IAW, subíndices T/E/X y completitud de datos; fichas por
reservorio; lista de descartados con motivo; shortlist priorizada.

**Compuerta: ¿pasa a factibilidad?**

| Evidencia requerida | Criterio |
|---|---|
| IAW y subíndices calculados | Completitud de datos ≥ 50% |
| Ningún killing factor duro activo | K1–K6 en verde |
| Posición en la matriz de decisión | Cuadrante *Avanzar* o *Candidato a piloto* |
| Fuente de agua al menos identificada | Aunque sea preliminar |
| Presupuesto de F1 disponible | Aprobación de estudio |

> **Trampa frecuente.** Saltar de F0 directo a F2 porque "el campo es obvio". La factibilidad
> es donde se descubren el Sor real, la incompatibilidad del agua y el estado de los pozos.
> Un FEED construido sobre supuestos de screening produce un capex que se desmorona.

---

## F1 — Factibilidad (*Assess*)

**Objetivo.** Convertir supuestos de screening en datos medidos, y decidir si el proyecto
es real.

**Alcance de trabajo:**

| Área | Actividades |
|---|---|
| Datos | Rescate y digitalización, control de calidad de la historia de producción |
| Geología | Modelo estático, correlación de capas, compartimentación, mapas |
| Reservorios | Balance de materia, OOIP, mecanismo de empuje, estimación de incremental |
| Laboratorio | **PVT, núcleos: permeabilidades relativas, Sor, mojabilidad** |
| Agua | Estudio de fuentes: volumen, calidad, distancia, permisos; compatibilidad agua-roca y agua-agua |
| Pozos | Censo de integridad; candidatos a conversión vs pozos nuevos |
| Concepto | Patrón preliminar, espaciamiento, tasa de inyección de diseño |
| Economía | Capex clase 4 (±30%), VAN, sensibilidades |

**Compuerta DG1**

| Evidencia requerida | Por qué |
|---|---|
| **Sor medido en núcleo**, no correlacionado | Es el número que define el techo de recuperación. Un error acá invalida todo lo demás |
| **Compatibilidad de aguas confirmada en laboratorio** | Una incompatibilidad no detectada tapona la formación y mata el proyecto después de invertir |
| **Fuente de agua con volumen y permisos verificados** | La causa más frecuente de proyectos frenados después de aprobados |
| Modelo estático con incertidumbre acotada | Base para la simulación de F2 |
| Incremental estimado con método declarado | Analogía, balance de materia o correlación — pero explícito |
| Censo de integridad de pozos | Determina si el capex es de conversión o de perforación, que cambia el orden de magnitud |
| Capex clase 4 y VAN positivo en el escenario base | — |

---

## F2 — Definición (*Select & Define* / FEED)

**Objetivo.** Definir el proyecto con precisión suficiente para comprometer capital.

**Alcance de trabajo:**

| Área | Actividades |
|---|---|
| Reservorios | Simulación numérica con ajuste de historia; optimización de patrón, espaciamiento y secuencia |
| Pozos | Programa de perforación y conversión; diseño de completaciones de inyección |
| Facilities | Diseño de planta de inyección, captación, tratamiento de agua de inyección y de agua producida |
| Superficie | Trazado de líneas, energía, automatización |
| Vigilancia | Plan de monitoreo: presiones, trazadores, perfiles de inyección, VRR objetivo |
| HSE | Estudio de impacto ambiental, permisos, relacionamiento comunitario |
| Economía | Capex clase 3 (±15%), plan de ejecución, análisis de riesgos |

**Compuerta DG2 — Decisión Final de Inversión**

| Evidencia requerida | Por qué |
|---|---|
| **Ajuste de historia aceptable** en el modelo dinámico | Un modelo que no reproduce el pasado no predice el futuro |
| Perfil de producción con rango de incertidumbre (P10/P50/P90) | Un número único esconde el riesgo |
| **Capex clase 3 con contingencia explícita** | ±15% es el estándar para FID |
| Permisos ambientales obtenidos o con ruta crítica clara | Los permisos son la ruta crítica más subestimada |
| Contrato o fuente de agua asegurada | — |
| Plan de vigilancia definido **antes** de arrancar | Si se diseña después, no hay línea de base contra la cual medir |
| VAN positivo en escenario de precio bajo | Robustez, no optimismo |

---

## F3 — Piloto

**Objetivo.** Reducir incertidumbre antes de comprometer el capital de campo completo.

**Cuándo se justifica saltarlo.** Solo con **analogía directa fuerte**: mismo reservorio o
formación, en un campo donde YPFB ya inyecta con resultados documentados —el caso de
Víbora, Sirari o Yapacaní. Fuera de eso, el piloto casi siempre paga su costo.

**Configuración típica.** Uno o dos patrones (invertido de cinco puntos es el arranque
habitual), con monitoreo muy por encima del estándar operativo.

**Qué mide el piloto que no se puede saber antes:**

| Incógnita | Cómo se mide |
|---|---|
| Inyectividad real | Prueba de inyectividad, gráfico de Hall |
| Tiempo y volumen de rellenado | Historia de inyección vs respuesta de presión |
| Conectividad inyector-productor | **Trazadores** |
| Existencia de canalización | Trazadores + firma de Chan en los productores |
| Incremento real de recuperación | Producción del patrón vs pronóstico sin inyección |
| Comportamiento del agua producida | Análisis en superficie, incrustación, corrosión |

**Compuerta DG3**

| Evidencia requerida | Criterio |
|---|---|
| Respuesta de presión observada | Consistente con lo simulado |
| Respuesta de producción incremental | Dentro del rango P10–P90 pronosticado |
| Trazadores sin canalización severa | O con conformancia manejable |
| Inyectividad sostenida | Sin declinación por daño en el gráfico de Hall |
| Modelo actualizado con datos del piloto | Y re-pronóstico de campo completo |

> **El error clásico del piloto es diseñarlo demasiado chico o demasiado corto.** Un piloto
> que no alcanza a completar el rellenado y ver respuesta produce un resultado ambiguo,
> gasta el presupuesto y no decide nada. El horizonte debe fijarse por el volumen poral a
> desplazar, no por el año fiscal.

---

## F4 — Ejecución

**Objetivo.** Construir y arrancar.

| Etapa | Contenido |
|---|---|
| Procura | Bombas, tuberías, plantas de tratamiento — plazos de entrega largos, es la ruta crítica |
| Construcción | Planta de inyección, líneas, captación, energía |
| Pozos | Perforación de inyectores nuevos, conversión de productores, completaciones |
| Comisionado | Pruebas de presión, calibración, automatización |
| Arranque | Inicio de inyección, línea de base de vigilancia |

**Riesgos principales:** plazos de procura de equipos importados; calidad del agua de
inyección fuera de especificación al arrancar (produce taponamiento temprano y daño
permanente en la cara de la formación); e integridad de pozos convertidos que resulta peor
que lo relevado.

---

## F5 — Operación y optimización

La inyección de agua **no es una obra que se termina, es una operación que se gestiona**.
El factor de recobro final depende más de la calidad de la vigilancia durante veinte años
que del diseño inicial.

**Vigilancia continua:**

| Indicador | Frecuencia | Qué detecta |
|---|---|---|
| VRR instantáneo y acumulado | Mensual | Si el vaciamiento se está reponiendo |
| Gráfico de Hall por inyector | Mensual | Daño o fractura en el inyector |
| WOR y WOR′ por productor (Chan) | Mensual | Canalización o conificación emergente |
| Perfiles de inyección | Anual | Reparto entre capas; capas ladronas |
| Trazadores | Cada 2–3 años | Cambios de conectividad |
| Balance de aguas | Mensual | Fugas, pérdidas, calidad |
| Ajuste de historia | Cada 2–3 años | Recalibración del pronóstico |

**Optimización:** ajuste de patrón, conversión de pozos adicionales, control de
conformancia en capas ladronas, y evaluación de pasar a recuperación terciaria cuando el
waterflood madura.

---

## Compuertas: resumen de la evidencia crítica

Si hubiera que quedarse con un solo dato por compuerta, sería este:

| Compuerta | El dato que más decide | Si falta |
|---|---|---|
| **F0 → F1** | Clasificación del reservorio y móvil remanente | No se puede rankear |
| **DG1** | **Sor medido en núcleo** | El techo de recuperación es una suposición |
| **DG2** | **Ajuste de historia del modelo dinámico** | El pronóstico no tiene respaldo |
| **DG3** | **Trazadores** | No se sabe si el agua va donde se cree |
| **F4 → F5** | Calidad del agua de inyección al arranque | Se daña la formación de forma irreversible |

---

## Adaptaciones al contexto de YPFB

1. **Clasificar antes que profundizar.** Buena parte del portafolio es gas-condensado sin
   anillo significativo. Correr F0 sobre todo el portafolio y descartar por K2 es barato;
   entrar a F1 sin haber clasificado es caro.

2. **Los campos ya inyectados son el activo más valioso del proyecto.** Víbora, Sirari y
   Yapacaní no son solo casos de validación: son la base de analogía que permite estimar
   incrementales sin simulación, y la única fuente de costos unitarios reales en condiciones
   bolivianas. Documentar su desempeño debería ser una tarea de F0, no de F1.

3. **El horizonte de 4 a 8 años choca con los ciclos de gestión.** Un proyecto que entrega
   su primer barril incremental después de dos cambios de administración necesita que las
   compuertas y su evidencia estén documentadas, para que cada nueva gestión pueda auditar
   la decisión anterior en vez de reiniciar el estudio. Es una de las razones de fondo por
   las que esta metodología existe.

4. **La fuente de agua puede ser el factor limitante regional**, no un problema por campo.
   Conviene evaluarla a nivel de área o de cuenca —Boomerang, Sur— en vez de campo por
   campo, porque una misma infraestructura de captación y tratamiento puede servir a varios
   proyectos y cambiar la economía de todos ellos a la vez.
