# Herramienta de screening de waterflooding — YPFB

Metodología estándar y herramienta en Excel para evaluar, de forma trazable y comparable
entre campos, en qué reservorios del portafolio de YPFB tiene sentido implementar
recuperación secundaria por inyección de agua.

## Para qué sirve

Responde tres preguntas, con el mismo criterio para todos los campos:

1. **¿Dónde tiene sentido inyectar agua?** — ranking de atractivo cuantificado.
2. **¿Dónde definitivamente no?** — factores eliminatorios explícitos, con el motivo registrado.
3. **¿En qué orden gastar el capital?** — matriz de decisión atractivo vs ejecutabilidad.

## Qué hay acá

| Carpeta | Contenido |
|---|---|
| `docs/01-antecedentes/` | Dossier bibliográfico y rangos de criterios adoptados |
| `docs/02-criterios/` | Manual de criterios: killing factors, scoring, IAW |
| `docs/03-checklist-datos/` | Checklist de recopilación por niveles y plan de relevamiento |
| `docs/04-roadmap-proyecto/` | De la idea a la implementación: fases y compuertas de decisión |
| `docs/05-plan-y-presupuesto/` | Cronograma, equipo y presupuesto preliminar |
| `herramienta/` | Los libros Excel (entregable final) |
| `datos/ejemplos/` | Campo sintético de práctica, con el Libro A ya cargado |
| `datos/argentina/` | Libro A de Puesto Guardián, con datos reales de Capítulo IV |
| `construccion/` | Scripts internos que generan los libros — **no se entregan a YPFB** |

## Los dos libros

| | **Libro A — Diagnóstico de campo** | **Libro B — Screening de portafolio** |
|---|---|---|
| Cuántos | Uno por campo | Uno solo, consolidado |
| Entrada | Series mensuales de qo, qw, qg y Pwf por pozo | Una fila por reservorio |
| Salida | Diagnósticos, gráficos y una fila de resumen | Killing factors, IAW, ranking, fichas |

El Libro A produce una **fila de resumen** que se copia y pega en el Libro B. Se copia en
vez de vincular: los enlaces externos de Excel se rompen al mover o renombrar carpetas, y
el resultado es un portafolio con números que nadie sabe si están vigentes.

## Cómo usarlo

No requiere instalar nada. Se abre con Excel y listo.

1. Copiar `herramienta/Libro_A_Diagnostico_vX.xlsx` y renombrarlo con el nombre del campo.
2. Pegar la historia de producción en la hoja `Carga_Producción`.
3. Completar lo que se sepa en `Carga_Estáticos` — lo que falte se marca como desconocido,
   no se inventa.
4. Revisar la hoja `Diagnóstico` y los `Gráficos`.
5. Copiar la fila de la hoja `Resumen` y pegarla en la hoja `Reservorios` del Libro B.

El manual completo está en `docs/` (ver `MANUAL_DE_USO.md`).

## Reglas de construcción

Estas restricciones no son preferencias: definen si la herramienta sobrevive dentro de YPFB.

- **Sin macros ni VBA.** Un `.xlsm` se bloquea por política de seguridad y la herramienta muere ahí.
- **Sin complementos ni Solver.** Todo ajuste iterativo se resuelve con grilla de candidatos
  evaluada por fórmula.
- **Solo funciones compatibles con Excel 2016.** `INDEX`/`MATCH`, no `XLOOKUP`; sin `LET`,
  `LAMBDA` ni matrices dinámicas.
- **Toda fórmula visible y auditable.** Sin hojas ocultas con la lógica real.
- **Rangos con nombre.** Una fórmula debe leerse `Peso_Movilidad`, no `$C$47`.

Los scripts de `construccion/` usan Python solo para *generar* los `.xlsx`. El usuario final
nunca ejecuta Python: recibe un libro Excel común y corriente.

## Versionado

No hay repositorio de código para el entregable, así que la disciplina es manual:

- Archivo versionado: `Libro_B_Screening_v1.3_2026-03-15.xlsx`
- Hoja `LÉEME` con changelog obligatorio: qué cambió, quién, cuándo, por qué
- Copia maestra en solo lectura en carpeta compartida; las de trabajo son personales
- Todo cambio en la hoja `Criterios` exige correr la hoja `Pruebas` y registrar el resultado

## Estado

Prototipo funcional y verificado. **Falta calibrarlo con datos bolivianos.**

| Entregable | Estado |
|---|---|
| Dossier bibliográfico | Borrador; fuentes primarias sin verificar |
| Manual de criterios | Borrador; umbrales sin calibrar localmente |
| Checklist de datos | Completo |
| Roadmap de proyecto | Completo |
| Plan y presupuesto | Completo |
| Manual de uso | Completo |
| Libro A — diagnóstico | Funcional, verificado numéricamente |
| Libro B — portafolio | Funcional, verificado numéricamente |
| Demo pre-cargado | Disponible |
| Libro A con datos reales (Puesto Guardián) | Disponible |
| Tabla de analogías bolivianas | **Falta** — es el vacío más caro |
| Costos unitarios reales | **Falta** — hay marcadores de posición |
| Apertura en planilla real | Verificada en LibreOffice, 2026-08-19 |

### Verificación

Tres capas independientes, todas en verde:

```
construccion/verificar_todo.sh
```

1. **El método recupera respuestas analíticas conocidas** — 8 casos sintéticos
   con solución cerrada (declinación exponencial e hiperbólica, las cuatro
   firmas de Chan, balance de materia con OGIP exacto, e inyección con pendiente
   de Hall conocida).
2. **Los libros abren y calculan** — ninguna función posterior a Excel 2016,
   sintaxis balanceada, todos los nombres resueltos.
3. **Las fórmulas dan los números correctos** — evaluadas con un motor de Excel:
   `b = 0,50` exacto, `EUR = 2.386,3 Mbbl` contra 2.386,3 analítico,
   `OGIP = 120.000 MMpc` exacto, pendiente de Hall `= 1.000,0` exacta,
   variación del IP `= −62,90%` exacta, `T = 100,0` y `X = 100,0` en los casos
   construidos para eso.

**Apertura en planilla real, hecha el 2026-08-19.** El entorno de construcción
original no tenía Excel ni LibreOffice. Los libros se abrieron en LibreOffice
Calc y calculan: el demo sintético y el Libro A de Puesto Guardián resuelven el
grafo completo de fórmulas y emiten el diagnóstico. Falta todavía abrirlos en
Excel de escritorio, que es donde van a vivir dentro de YPFB.

**Datos reales, no solo sintéticos.** `construccion/cargar_capiv.py` carga un
Libro A desde el Capítulo IV de la Secretaría de Energía de Argentina. El
yacimiento de referencia es Puesto Guardián (Salta): 8 pozos, 340 filas, enero
de 2019 a julio de 2025. Sirve de contraste con el campo sintético, porque
muestra qué pasa cuando faltan datos de verdad: el diagnóstico sale, el índice
de atractivo no.

Ver `DECISIONES.md` para la bitácora de decisiones técnicas y
`docs/05-plan-y-presupuesto/` para el cronograma.
