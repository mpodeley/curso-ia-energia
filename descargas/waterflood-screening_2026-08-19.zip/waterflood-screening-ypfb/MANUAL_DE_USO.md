# Manual de uso

**Para el ingeniero de reservorios. No hace falta programar ni instalar nada.**

Versión 0.1

---

## 1. Antes de empezar

Se necesitan dos archivos:

| Archivo | Cuántos | Dónde está |
|---|---|---|
| `Libro_A_Diagnostico_v0.1.xlsx` | Una copia **por campo** | `herramienta/` |
| `Libro_B_Screening_v0.1.xlsx` | Uno solo, compartido | `herramienta/` |

Y conviene abrir primero el demo, para ver la herramienta funcionando antes de
cargar datos propios:

`datos/ejemplos/Libro_A_DEMO_CAMPO_SINTETICO_v0.1.xlsx`

Tiene siete reservorios ficticios, cada uno construido para mostrar una firma
distinta. La hoja `LÉEME` del propio archivo dice qué debería verse en cada uno.
Cambiar el reservorio activo en `Config` y recorrerlos toma diez minutos y ahorra
media jornada de confusión después.

---

## 2. Diagnosticar un campo — Libro A

### Paso 1. Copiar y renombrar

Copiar `Libro_A_Diagnostico_v0.1.xlsx` y renombrarlo con el nombre del campo:

```
Libro_A_CAMIRI_v0.1_2026-09-15.xlsx
```

**Siempre con fecha en el nombre.** Es la única forma de saber después cuál era
la versión vigente.

### Paso 2. Pegar la historia de producción

En la hoja `Carga_Producción`, una fila por pozo y mes:

| Columna | Qué va | Obligatorio |
|---|---|---|
| `Pozo` | Identificador del pozo | Sí |
| `Reservorio` | Nombre del reservorio | Sí |
| `Fecha` | Fecha del mes | Sí |
| `Dias_operados` | Días que produjo | No — si falta se asume 30,44 |
| `Qo_bpd` | Caudal de petróleo, **promedio del mes** | Sí |
| `Qw_bpd` | Caudal de agua, promedio del mes | Sí |
| `Qg_Mpcd` | Caudal de gas, promedio del mes | Sí |
| `Pwf_psi` | Presión de fondo fluyente | No |
| `Winy_bpd`, `Piny_psi` | Inyección, si la hay | No |
| `Evento` | Intervenciones | No, pero conviene |

### Tres reglas que no se pueden violar

**1. Ordenar por Pozo y luego por Fecha.**
Los acumulados por pozo se calculan como suma corrida, que asume ese orden. La
hoja `Diagnóstico` avisa en "Filas fuera de orden": **si no dice 0, los
acumulados están mal.**

**2. Celda vacía significa desconocido. Cero significa cero.**
Un pozo cerrado tiene `Qo = 0`. Un pozo del que se perdió el registro tiene la
celda **vacía**. La herramienta los trata distinto y confundirlos deforma la
declinación y el acumulado.

**3. Cargar los eventos.**
Un cambio de zona sin registrar produce un quiebre en la curva de WOR que el
diagnóstico interpreta como canalización. Es el error que más fácil convierte un
diagnóstico en una conclusión equivocada con apariencia de rigor.

### Paso 3. Completar los datos estáticos

En `Carga_Estáticos`, un reservorio por columna. Los parámetros están marcados
por nivel:

| Nivel | Qué habilita |
|---|---|
| **N1** (verde) | El diagnóstico de este libro |
| **N2** (ámbar) | El IAW del Libro B |
| **N3** (rojo) | Refinamiento; sube la confianza |

**Lo que no se sepa se deja vacío.** No se inventa, no se estima "por si acaso",
no se copia del reservorio vecino. La hoja `Completitud` lleva la cuenta y el
IAW se reporta junto a ese porcentaje. Un dato inventado destruye esa
trazabilidad y no hay forma de detectarlo después.

### Paso 4. Elegir el reservorio activo

En `Config`, celda B5, elegir de la lista desplegable. **Todo el libro
recalcula.**

También en `Config` están todos los parámetros de cálculo: límite económico,
ventana de ajuste de declinación, umbrales del clasificador de Chan. Todo es
editable y todo está explicado en la propia hoja.

### Paso 5. Leer el diagnóstico

La hoja `Diagnóstico` da, de arriba hacia abajo: identificación, datos del
reservorio, producción acumulada, declinación, diagnóstico de agua, balance de
materia, volumetría, VRR e **interpretación automática en texto**.

La hoja `Gráficos` muestra los ocho gráficos del reservorio activo.

#### Cómo leer el diagnóstico de Chan

Es lo más valioso del libro, porque la respuesta operativa a cada firma es
opuesta:

| Clasificación | Qué significa | Qué hacer |
|---|---|---|
| **SIN AGUA** | Todavía no hay agua suficiente para clasificar | Nada; volver más adelante |
| **DESPLAZAMIENTO NORMAL** | El avance del agua es el esperable | Sin patología |
| **CANALIZACIÓN** | El agua toma un camino preferencial | Trazadores y conformancia **antes** de considerar inyección. Inyectar sobre un canal existente lo agrava |
| **CONIFICACIÓN** | Problema de completación y caudal | Revisar intervalos y tasas. **No es un problema de barrido** |
| **INDETERMINADO** | Menos de 18 meses con agua | Datos insuficientes |

> **Antes de creerle a una clasificación de CANALIZACIÓN**, revisar la columna
> `Evento` en los meses del quiebre. Un cambio de zona no registrado produce
> exactamente esa firma.

#### Cómo leer el gráfico de Hall

Solo aplica donde ya hay inyección — hoy, los campos que sirven de analogía. Mide
la **salud del inyector**, y lo que diagnostica es el cambio de pendiente, no su
valor:

| Estado | Qué significa | Qué hacer |
|---|---|---|
| **INYECTIVIDAD ESTABLE** | La pendiente no cambió | Nada |
| **DAÑO CRECIENTE** | La pendiente sube: cuesta cada vez más inyectar | Revisar calidad del agua de inyección y programa de estimulación |
| **POSIBLE FRACTURA** | La pendiente baja: entra agua con menos esfuerzo del esperado | Verificar que la presión de inyección esté bajo la de fractura. Una fractura no controlada canaliza el agua y arruina el barrido |
| **SIN DATOS DE INYECCIÓN** | El reservorio no inyecta | Es lo normal en un candidato |

> Requiere que `Pi_psi` esté cargado en `Carga_Estáticos`: la integral se calcula
> contra la presión de reservorio, y sin ella no hay contra qué integrar.

#### Cómo leer el índice de productividad

Es **aparente**: usa la presión inicial como referencia porque la presión de
reservorio de cada mes rara vez existe. **El valor absoluto no significa nada; lo
que informa es la tendencia.**

Una caída fuerte del IP con la presión sostenida apunta a **daño**. Una caída
junto con la presión apunta a **agotamiento**. Son problemas distintos con
soluciones distintas, y distinguirlos exige mirar las dos curvas juntas.

#### Si el ajuste de declinación sale con R² bajo

Acotar la ventana en `Config` (`Ajuste_Mes_Inicio` y `Ajuste_Mes_Fin`). Es
habitual que la historia completa mezcle períodos con mecanismos de producción
distintos, y ajustar sobre todo produce un resultado que no representa a
ninguno.

### Paso 6. Llevar el resultado al Libro B

En la hoja `Resumen`:

1. Seleccionar **la fila 4 completa**
2. Copiar
3. En el Libro B, hoja `Reservorios`, pegar **como valores** (Pegado especial →
   Valores) a partir de la fila 9

> **Pegar como valores, no como fórmulas.** Pegar con fórmulas crea un vínculo
> externo que se rompe al mover o renombrar el archivo, y el Libro B queda
> mostrando números viejos sin avisar que lo son.

Repetir desde el paso 4 para cada reservorio del campo.

---

## 3. Rankear el portafolio — Libro B

### Cómo se lee

| Hoja | Para qué |
|---|---|
| `Criterios` | **La fuente de verdad.** Umbrales, pesos, killing factors. Editable |
| `Supuestos_Económicos` | Precios, costos unitarios, tasa de descuento. Editable |
| `Reservorios` | Donde se pegan las filas del Libro A |
| `Killing_Factors` | Qué se descartó y **por qué** |
| `Scoring` | Puntajes, subíndices T/E/X, IAW |
| `Ranking` | Orden y matriz de decisión |
| `Ficha` | Una página imprimible por reservorio |
| `Pruebas` | Los casos de verificación |

### Cómo se interpreta el IAW

```
IAW = T^0,40 × E^0,35 × X^0,25
```

**Media geométrica, no aritmética.** Un promedio aritmético dejaría que un
subíndice excelente compense uno pésimo. Un reservorio técnicamente ideal sin
fuente de agua no es un proyecto bueno con un problema: no es un proyecto.

**Los tres subíndices se leen por separado.** El IAW ordena; los subíndices
explican:

- **T alto, X bajo** → hay que **desbloquear** algo (agua, integridad, datos)
- **T y E medios, X medio** → hace falta **mejor información**
- **T bajo** → el reservorio no da, independientemente de todo lo demás

### La completitud manda sobre el IAW

| Completitud | Cómo se usa el ranking |
|---|---|
| ≥ 75% | Es defendible |
| 50–75% | Indicativo; verificar antes de comprometer capital |
| **< 50%** | **No usar para decidir.** Usar para priorizar qué datos salir a buscar |

### La matriz de decisión

| | **X bajo** | **X alto** |
|---|---|---|
| **IAW alto** | DESBLOQUEAR PRIMERO | AVANZAR A FACTIBILIDAD |
| **IAW bajo** | DESCARTAR O DIFERIR | CANDIDATO A PILOTO |

**Cuadrante "candidato a piloto":** un campo modesto pero fácil de ejecutar tiene
un valor que el IAW no captura — generar la experiencia operativa y los datos con
los que se decide el campo grande. En un portafolio con poca inyección activa,
ese valor de aprendizaje es real.

### Un descarte no borra nada

El reservorio queda en `Killing_Factors` con su motivo registrado. Si cambia el
precio, aparece una fuente de agua o se recupera información, se revisa. **El
registro de por qué algo no es candidato tiene valor propio**: evita que la
pregunta se vuelva a abrir cada dos años.

---

## 4. Ajustar la metodología

### Cambiar un umbral o un peso

1. Ir a la hoja `Criterios`
2. Editar la celda amarilla
3. **Ir a la hoja `Pruebas` y verificar que diga TODO OK**
4. Anotar el cambio en el changelog de la hoja `LÉEME`: qué, quién, cuándo, **por
   qué**

Los pesos de cada subíndice deben sumar 100. La propia hoja `Criterios` lo
controla y marca REVISAR en rojo si no.

### Qué significa cada modo de "Si falta"

| Modo | Qué hace | Cuándo se usa |
|---|---|---|
| **BLOQUEA** | El subíndice no se calcula; el reservorio queda *sin evaluar*, no mal evaluado | Datos sin los cuales el screening no tiene sentido |
| **PENALIZA** | Asigna un puntaje bajo fijo | Cuando **desconocer el dato es en sí un riesgo** (fuente de agua, integridad) |
| **OMITE** | Se excluye del promedio y se renormalizan los pesos | Datos de refinamiento que rara vez existen en campos maduros |

La diferencia entre PENALIZA y OMITE es deliberada. No saber si hay agua
disponible **es** una mala noticia, porque el proyecto no avanza sin resolverlo.
No conocer el coeficiente de Dykstra-Parsons es normal en un campo de los años
sesenta, y castigarlo penalizaría a todos por igual sin aportar capacidad de
ordenamiento.

### La hoja Pruebas

Seis casos que corren sobre las **mismas fórmulas** que un reservorio real, más
tres controles de la metodología. Las filas `PRUEBA-*` de la hoja `Reservorios`
son sus datos de entrada y quedan fuera del ranking automáticamente.

**No borrar esas filas.** Sin ellas el libro se queda sin forma de verificarse a
sí mismo.

---

## 5. Versionado

No hay repositorio de código, así que la disciplina es manual:

| Regla | Por qué |
|---|---|
| Nombre con versión y fecha: `Libro_B_Screening_v1.3_2026-03-15.xlsx` | Saber cuál es la vigente |
| Changelog obligatorio en la hoja `LÉEME` | Saber qué cambió y por qué |
| Copia maestra en solo lectura en carpeta compartida | Que nadie trabaje sobre la de otro |
| Toda edición de `Criterios` exige correr `Pruebas` y registrarlo | Que un cambio no rompa la metodología en silencio |

---

## 6. Problemas frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| El diagnóstico sale vacío | El nombre del reservorio en `Config` no coincide **exactamente** con el de `Carga_Producción` | Verificar mayúsculas, tildes y espacios |
| "Filas fuera de orden" mayor que 0 | Datos sin ordenar | Ordenar `Carga_Producción` por Pozo y luego por Fecha |
| El IAW sale vacío | Un criterio en modo BLOQUEA no tiene dato, o el reservorio está descartado | Ver `Killing_Factors` y `Completitud` |
| R² del ajuste bajo | La ventana mezcla períodos con mecanismos distintos | Acotar `Ajuste_Mes_Inicio` y `Ajuste_Mes_Fin` |
| CANALIZACIÓN donde no debería | Intervención no registrada | Revisar la columna `Evento` |
| El libro recalcula lento | Son ~103.000 fórmulas | Fórmulas → Cálculo manual, y F9 cuando haga falta |
| `#¡NOMBRE?` en varias celdas | El archivo se abrió en un programa que no soporta rangos con nombre | Abrir en Excel 2016 o posterior |

---

## 7. Qué NO hace esta herramienta

Declarado a propósito, para que nadie le pida lo que no puede dar:

- **No simula.** No hay modelo numérico, ni Buckley-Leverett multicapa riguroso,
  ni análisis de conectividad inyector-productor tipo CRM.
- **No hace Monte Carlo.** Las sensibilidades son determinísticas.
- **No reemplaza un estudio de factibilidad.** Un IAW alto significa "vale la
  pena gastar 150–400 k US$ en estudiarlo", no "hagámoslo".
- **No decide.** Ordena y deja registrado por qué. La decisión sigue siendo de
  quien firma.

Todo eso corresponde a la Fase 1 del roadmap y está fuera de alcance **por
decisión**, no por olvido: Excel puede aproximar esos cálculos mal, y es
preferible declararlos fuera que entregar un número en el que nadie debería
confiar.
