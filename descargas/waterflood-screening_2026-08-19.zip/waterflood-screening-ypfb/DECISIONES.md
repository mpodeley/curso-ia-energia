# Bitácora de decisiones técnicas

Cada decisión registra el contexto, la opción elegida y —lo más importante— **qué se
descartó y por qué**. Sirve para no re-litigar lo ya resuelto y para que quien herede el
proyecto entienda las restricciones antes de "mejorarlo".

---

## D-001 — Plataforma: Excel puro, sin macros

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** El usuario final es un ingeniero de reservorios de YPFB que no programa ni
usa agentes. La herramienta tiene que funcionar en su máquina, sin pedirle nada a IT.

**Decisión.** Un `.xlsx` sin macros, sin complementos y sin dependencias externas.

**Descartado:**

- *App web (Streamlit u otra).* Requiere servidor interno o permisos de instalación.
  Mejor capacidad analítica, pero una herramienta que necesita gestión de IT para abrirse
  no se usa.
- *Excel con VBA.* Un `.xlsm` se abre en modo protegido o directamente se bloquea bajo
  políticas de seguridad corporativas típicas. Además el código VBA es una caja negra para
  el ingeniero, que es exactamente lo contrario de lo que se busca.
- *Excel + motor Python que lo genera desde YAML.* Era la arquitectura prevista cuando
  había dos plataformas que mantener sincronizadas. Con una sola plataforma, obligaría a
  saber Python para cambiar un peso — contradice el objetivo.

**Consecuencia.** Los criterios viven en una hoja `Criterios` dentro del libro. Cambiar un
umbral es editar una celda. Todo cálculo que no se pueda expresar en fórmulas nativas queda
fuera del screening y se difiere a la Fase 1 de factibilidad (ver D-005).

---

## D-002 — Dos libros en vez de uno

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** El diagnóstico necesita miles de filas de producción mensual por campo; el
screening de portafolio necesita decenas de filas, una por reservorio. Mezclarlos produce
un archivo pesado y frágil que además no permite trabajo en paralelo.

**Decisión.** **Libro A** (diagnóstico, uno por campo) y **Libro B** (portafolio, uno solo).
El A produce una fila de resumen normalizada que se **copia y pega** en el B.

**Descartado:**

- *Un libro único.* Tamaño y fragilidad; y un solo analista a la vez.
- *Vincular libros con referencias externas.* Los enlaces se rompen al mover archivos o
  renombrar carpetas. El modo de falla es silencioso: el portafolio muestra números viejos
  sin avisar que lo son. Copiar es manual pero honesto, y la fila lleva fecha y versión de
  origen.

---

## D-003 — Killing factors en dos categorías: duros y mitigables

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** Una lista única de factores eliminatorios descarta campos que en realidad
solo necesitan un estudio adicional.

**Decisión.** **Duros** (K1–K6) descartan sin apelación. **Mitigables** (M1–M8) no
descartan: penalizan el score y disparan un estudio específico documentado.

**Consecuencia.** Todo descarte queda con su motivo registrado en una columna. Un campo
descartado no desaparece: queda en la lista con la razón, lo que permite revisarlo si
cambian las condiciones (precio, disponibilidad de agua, nueva información).

---

## D-004 — El IAW se reporta con el % de completitud de datos

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** La disponibilidad de datos varía fuertemente entre campos y no se conoce de
antemano. Un índice calculado con información parcial se ve idéntico a uno bien sustentado.

**Decisión.** El Índice de Atractivo de Waterflooding se reporta **siempre** junto al
porcentaje de datos que lo respalda, y se descomponen tres subíndices —Técnico, Económico,
Ejecutabilidad— además del compuesto.

**Descartado:** rellenar datos faltantes con valores por defecto silenciosos. Produce un
número que parece sólido y no lo es, que es peor que no tener número.

**Consecuencia.** Cada criterio declara explícitamente su regla de dato faltante: si
penaliza, si se omite del promedio ponderado, o si bloquea el cálculo.

---

## D-005 — Alcance analítico deliberadamente recortado

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** Excel puede aproximar mal ciertos cálculos. La tentación es implementarlos
igual "para que esté".

**Decisión.** Quedan **fuera** del screening y se difieren a la Fase 1 de factibilidad:
simulación numérica, Buckley-Leverett multicapa riguroso, análisis de conectividad
inyector-productor tipo CRM, y Monte Carlo. Las sensibilidades se cubren con tablas de
datos determinísticas.

**Razón.** Es preferible declarar algo fuera de alcance que entregar un número en el que
nadie debería confiar. Un screening que se sabe aproximado y lo dice es útil; uno que
aparenta precisión que no tiene, es peligroso.

---

## D-006 — Los tests corren dentro del libro

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** Sin herramientas de programación, no hay forma de correr una suite de tests
externa. Pero cualquier cambio en los pesos puede romper la metodología en silencio.

**Decisión.** Hoja `Pruebas` con casos golden de respuesta analítica conocida, valor
esperado, tolerancia y columna PASS/FAIL calculada por fórmula. El ingeniero abre la hoja y
ve verde o rojo.

**Consecuencia.** Todo cambio en la hoja `Criterios` obliga a revisar `Pruebas` y registrar
el resultado en el changelog.

---

## D-007 — Ajuste de declinación hiperbólica sin Solver

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** El ajuste de Arps hiperbólico es iterativo. Solver es un complemento que
puede no estar habilitado, y depende de que el usuario apriete un botón — con lo cual el
resultado deja de recalcularse solo.

**Decisión.** Grilla de exponentes `b` de 0 a 1 en pasos de 0,05, cada uno con su R²
calculado por fórmula, y selección del mejor con `INDEX`/`MATCH` sobre el máximo.

**Ventaja adicional sobre Solver:** es determinístico y se recalcula solo al cambiar los
datos. Con Solver, un libro reabierto muestra el resultado del ajuste anterior sin avisar
que los datos cambiaron.

---

## D-008 — Python solo como herramienta de autoría

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** Construir a mano un libro con cientos de fórmulas, rangos con nombre y
gráficos es lento y propenso a errores.

**Decisión.** Los `.xlsx` se generan con scripts Python (openpyxl) que viven en
`construccion/`. Esos scripts **no forman parte del entregable**.

**Distinción importante:** el archivo resultante es un Excel de fórmulas nativas, sin
macros ni rastro de Python. El ingeniero de YPFB nunca ejecuta ni ve código. Python acá
cumple el mismo rol que un editor de texto: es la herramienta con la que se escribe, no
una dependencia de lo escrito.

**Consecuencia.** Si el equipo de YPFB quiere modificar la estructura del libro (no solo
los pesos), puede hacerlo directamente en Excel. Los scripts sirven para regenerarlo desde
cero de forma reproducible, pero no son obligatorios para mantenerlo.

---

## D-009 — Discriminar la firma de Chan por magnitud, no por signo

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** El criterio de Chan se enuncia habitualmente por el signo de la
pendiente log-log de `WOR'`: positiva es canalización, negativa es conificación.
Implementado así, el caso de control de desplazamiento normal se clasificó como
conificación.

**Diagnóstico.** Si `WOR ∝ t^m` entonces `WOR' ∝ t^(m-1)`, de modo que la
pendiente log-log de la derivada es exactamente `m − 1`. Un pozo que se inunda
despacio (`m = 0,8`) da `−0,2`: negativo y perfectamente sano. La conificación
verdadera es otra cosa — el WOR tiende a una asíntota y su derivada decae
**exponencialmente**, dando pendientes del orden de `−3`.

**Decisión.** Discriminar por magnitud con la banda `[−1,00 ; +0,25]` para
desplazamiento normal.

**Calibración verificada:**

| Caso | Pendiente de WOR' | Clasificación |
|---|---|---|
| Conificación asintótica | −3,37 | CONIFICACIÓN |
| Normal lento (`m = 0,8`) | −0,28 | DESPLAZAMIENTO NORMAL |
| Normal canónico (`m = 1,0`) | +0,00 | DESPLAZAMIENTO NORMAL |
| Canalización (`m = 1,8`) | +1,37 | CANALIZACIÓN |

**Consecuencia.** Se agregó el caso `SINT_NORMAL_LENTO` al conjunto golden,
específicamente para fijar el borde inferior de la banda. Sin él, un umbral
cercano a cero volvería a pasar todas las pruebas y la herramienta recomendaría
control de conificación en pozos sanos.

---

## D-010 — Tres capas de verificación, no una

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** Que un generador produzca un `.xlsx` sin error no dice nada sobre
si el libro calcula bien. Entre "el método es correcto" y "las fórmulas
implementan ese método" hay un error de transcripción posible por celda.

**Decisión.** Tres capas independientes, todas automatizadas en
`construccion/verificar_todo.sh`:

1. **El método recupera respuestas analíticas conocidas** —
   `referencia_diagnosticos.py` implementa los diagnósticos en Python elemental y
   los contrasta contra 7 casos sintéticos de respuesta cerrada.
2. **Los libros abren y calculan** — `verificar_libros.py` verifica que no haya
   funciones posteriores a Excel 2016, que la sintaxis esté balanceada y que todo
   nombre referenciado exista.
3. **Las fórmulas dan los números correctos** — `verificar_numerico*.py` evalúa
   los libros con un motor de fórmulas de Excel y compara contra las respuestas
   analíticas.

**Qué encontró cada capa.** La capa 1 encontró el error de clasificación de
Chan (D-009). La capa 2 encontró un paréntesis sobrante, un uso de `MINIFS`
—que no existe en Excel 2016 perpetuo— y que el comparador `"=TEXTO"` se
convertía en fórmula al escribirse en una celda. La capa 3 encontró que todo el
Libro B leía la columna equivocada (D-011). Ninguna de las tres habría
encontrado sola los problemas de las otras.

**Lo que ninguna capa cubre.** El motor de fórmulas no es Excel. Quedan sin
verificar los gráficos, las listas desplegables, el formato condicional, la
protección de hojas y el tiempo de recálculo. Está anotado como la primera tarea
del plan y se hace abriendo el archivo demo.

---

## D-011 — La columna que identifica al reservorio no se asume

**Fecha:** 2026-08-17
**Estado:** Vigente

**Contexto.** El esquema de la fila de resumen pone `Campo` en la primera columna
y `Reservorio` en la segunda. El generador del Libro B daba por sentado que la
primera columna era el identificador.

**Cómo se manifestó.** El libro no daba ningún error. Los killing factors
funcionaban, el ranking se armaba, los subíndices salían con valores plausibles
— solo que los criterios que dependían de la hoja `Derivadas` se computaban como
"sin dato" y quedaban penalizados. `T = 82,3` en un caso construido para dar
exactamente 100.

**Decisión.** La columna identificadora se resuelve por nombre
(`C_NOM = COL_RES["Reservorio"]`) y nunca se escribe literal.

**Por qué queda registrado.** Es el modo de falla que el proyecto más teme y la
razón de ser del contrato compartido de `esquema_resumen.py`: una columna
desalineada no produce un error, produce un número creíble en el lugar
equivocado. Solo se detectó porque había un caso cuyo resultado exacto se conocía
de antemano.
